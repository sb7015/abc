"""
Teams Bot Message Handler for Agentic KM Solution
===================================================
This is the "translation layer" between Microsoft Teams and your AWS Lambda backend.

WHAT THIS DOES:
- Receives messages from Teams users (via Azure Bot Service → Kong)
- Extracts the user's question text
- Calls your existing /chat Lambda endpoint (via Kong API Gateway)
- Formats the response (answer + citations) back into a Teams message
- Sends it back to the user in Teams

WHAT THIS DOES NOT DO:
- No AI processing (that's your Lambda + Strands Agent)
- No document retrieval (that's your SharePoint OBO integration)
- No authentication logic (Kong handles that)

HOSTING:
- Client deploys this wherever they prefer (Azure App Service, AWS Lambda, Docker, etc.)
- It just needs to be a publicly accessible HTTPS endpoint
- Azure Bot Service's "messaging endpoint" points to: https://<host>/api/messages

DEPENDENCIES:
    pip install microsoft-agents-hosting-core microsoft-agents-hosting-aiohttp microsoft-agents-activity aiohttp requests

ENVIRONMENT VARIABLES:
    KONG_API_URL        = https://<kong-gateway-url>/chat       (your Lambda /chat via Kong)
    KONG_FEEDBACK_URL   = https://<kong-gateway-url>/feedback   (your Lambda /feedback via Kong)
    MicrosoftAppId      = <Azure Bot Registration App ID>
    MicrosoftAppPassword = <Azure Bot Registration App Secret>
    PORT                = 3978 (default)
"""

import os
import json
import uuid
import logging
import aiohttp as aiohttp_client
from datetime import datetime

from microsoft_agents.activity import Activity, ActivityTypes
from microsoft_agents.hosting.core import TurnContext, MemoryStorage, CardFactory
from microsoft_agents.hosting.aiohttp import AgentApplication, CloudAdapter, start_server, TurnState

# ============================================================
# CONFIGURATION
# Reads environment variables for API endpoints and server port.
# KONG_API_URL: The Kong API Gateway URL that routes to your
#               AWS Lambda /chat endpoint. This is the primary
#               backend integration point for all user queries.
# KONG_FEEDBACK_URL: The Kong API Gateway URL that routes to your
#                    AWS Lambda /feedback endpoint. Used to send
#                    user feedback (thumbs up/down) for analytics.
# PORT: The port number the bot's HTTP server listens on.
#       Default is 3978 (Microsoft Bot Framework convention).
# ============================================================
KONG_API_URL = os.environ.get("KONG_API_URL", "https://your-kong-gateway.com/chat")
KONG_FEEDBACK_URL = os.environ.get("KONG_FEEDBACK_URL", "https://your-kong-gateway.com/feedback")
PORT = int(os.environ.get("PORT", 3978))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("km-bot")

# ============================================================
# AGENT APPLICATION SETUP
# Creates the main bot application instance using Microsoft's
# Agents SDK. This is the central object that all event handlers
# (welcome message, incoming messages) are registered on.
#
# - MemoryStorage(): Stores conversation state in-memory (RAM).
#   Note: State is lost when the bot process restarts. For
#   production use with persistent state, replace with a
#   database-backed storage (e.g., CosmosDB, Redis).
# - CloudAdapter(): Handles communication with Azure Bot Service,
#   including authentication, message serialization, and
#   channel-specific formatting.
# ============================================================
AGENT_APP = AgentApplication[TurnState](
    storage=MemoryStorage(),
    adapter=CloudAdapter()
)


# ============================================================
# HELPER FUNCTION: call_km_agent()
# Sends the user's question to the AWS Lambda /chat endpoint
# via Kong API Gateway. This is the single integration point
# between the Teams bot and the backend AI system.
#
# Flow:
#   1. Packages the question and session_id into a JSON payload
#   2. Sends an async HTTP POST request to KONG_API_URL
#   3. Waits up to 60 seconds for Lambda to process (AI inference
#      + document retrieval can take time)
#   4. On success (HTTP 200): returns the parsed JSON response
#   5. On failure: logs the error and returns a user-friendly
#      error message so the bot never crashes
#
# The session_id allows Lambda to maintain conversation context
# across multiple questions in the same Teams chat thread.
# ============================================================
async def call_km_agent(question: str, session_id: str = None) -> dict:
    """
    Calls your existing AWS Lambda /chat endpoint via Kong API Gateway.
    
    This is the ONLY integration point — your Lambda does all the AI work.
    The bot just passes the question and gets back a structured response.
    
    Request:  { "question": "...", "session_id": "..." }
    Response: { "answer": "...", "citations": "...", "intent": "...", 
                "sources": [...], "correlation_id": "...", "metadata": {...} }
    """
    payload = {
        "question": question,
        "session_id": session_id or str(uuid.uuid4())
    }
    
    try:
        async with aiohttp_client.ClientSession() as session:
            async with session.post(
                KONG_API_URL,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=aiohttp_client.ClientTimeout(total=60)  # Lambda can take up to 60s
            ) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error_text = await response.text()
                    logger.error(f"Lambda returned {response.status}: {error_text}")
                    return {
                        "answer": f"I encountered an error processing your question. Please try again.",
                        "citations": "",
                        "intent": "error",
                        "sources": [],
                        "correlation_id": str(uuid.uuid4())
                    }
    except Exception as e:
        logger.error(f"Error calling KM Agent: {e}")
        return {
            "answer": "I'm having trouble connecting to the knowledge base. Please try again in a moment.",
            "citations": "",
            "intent": "error",
            "sources": [],
            "correlation_id": str(uuid.uuid4())
        }


# ============================================================
# HELPER FUNCTION: send_feedback()
# Sends user feedback (thumbs up/down) to the AWS Lambda
# /feedback endpoint via Kong API Gateway.
#
# Parameters:
#   - correlation_id: Links this feedback to a specific bot
#     response so the backend can track which answers were
#     helpful and which were not.
#   - feedback_type: "thumbs_up" or "thumbs_down"
#   - comment: Optional text feedback from the user
#
# Note: This function is currently defined but not called
# anywhere in the bot. It is pre-built for future use when
# feedback buttons (e.g., Adaptive Cards with thumbs up/down)
# are added to the bot's response messages.
#
# Timeout is set to 10 seconds (vs 60 for chat) because
# feedback submissions should be fast, lightweight operations.
# ============================================================
async def send_feedback(correlation_id: str, feedback_type: str, comment: str = "") -> dict:
    """Sends thumbs up/down feedback to your Lambda /feedback endpoint."""
    payload = {
        "correlation_id": correlation_id,
        "feedback_type": feedback_type,
        "comment": comment
    }
    
    try:
        async with aiohttp_client.ClientSession() as session:
            async with session.post(
                KONG_FEEDBACK_URL,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=aiohttp_client.ClientTimeout(total=10)
            ) as response:
                if response.status == 200:
                    return await response.json()
    except Exception as e:
        logger.error(f"Error sending feedback: {e}")
    return {}


# ============================================================
# HELPER FUNCTION: format_teams_response()
# Converts the raw JSON response from Lambda into a
# human-readable, well-formatted Teams message.
#
# The Lambda response contains structured data:
#   - answer: The AI-generated answer text
#   - citations: Reference text (e.g., "[1] SOP-Claims.pdf")
#   - sources: List of source documents with title, URL, snippet
#   - intent: The classified query category (e.g., "SOP", "Policy")
#   - correlation_id: Unique ID for tracking this response
#
# This function assembles these parts into a single message
# with sections for the answer, clickable source links, and
# a category tag. Teams supports Markdown formatting, so links
# are rendered as clickable using [title](url) syntax.
# ============================================================
def format_teams_response(km_response: dict) -> str:
    """
    Takes the JSON response from your Lambda and formats it 
    into a readable Teams message with citations.
    """
    answer = km_response.get("answer", "No answer available.")
    citations = km_response.get("citations", "")
    intent = km_response.get("intent", "")
    sources = km_response.get("sources", [])
    correlation_id = km_response.get("correlation_id", "")
    
    # Build the message
    message_parts = []
    
    # Main answer
    message_parts.append(answer)
    
    # Add citations if present
    if citations:
        message_parts.append(f"\n\n📎 **Sources:**\n{citations}")
    
    # Add source links if present
    if sources:
        links = []
        for i, src in enumerate(sources, 1):
            title = src.get("title", f"Document {i}")
            url = src.get("url", "")
            if url:
                links.append(f"[{i}] [{title}]({url})")
            else:
                links.append(f"[{i}] {title}")
        if links:
            message_parts.append("\n\n📄 **Document Links:**\n" + "\n".join(links))
    
    # Add intent tag (subtle, for debugging)
    if intent and intent != "error":
        message_parts.append(f"\n\n_Category: {intent}_")
    
    return "\n".join(message_parts)


# ============================================================
# EVENT HANDLER: Welcome message for new users
# Triggered automatically when a user opens a chat with this
# bot for the first time, or when the bot is added to a team
# or group chat. Sends a greeting message with example
# questions to help the user get started.
#
# The @conversation_update("membersAdded") decorator registers
# this function to run whenever the "membersAdded" event fires.
# This is a Teams-specific lifecycle event, not triggered by
# user messages.
# ============================================================
@AGENT_APP.conversation_update("membersAdded")
async def on_members_added(context: TurnContext, _state: TurnState):
    await context.send_activity(
        "👋 **Welcome to the KM Agent!**\n\n"
        "I can help you find information from SOPs, policies, and Salesforce knowledge base.\n\n"
        "**Try asking:**\n"
        "- What is the SOP for claims appeal?\n"
        "- What is our policy on pre-authorization?\n"
        "- How do I process a contestable claim?\n\n"
        "Just type your question and I'll search our knowledge base for you."
    )


# ============================================================
# MESSAGE HANDLER: Primary handler for all incoming user messages
# ============================================================
# This handler is triggered every time a user sends a text message
# to the bot. It performs the following sequence:
#   1. Extracts the user's question from the incoming Teams activity
#   2. Validates the input (rejects empty messages)
#   3. Sends a typing indicator so the user knows the bot is working
#   4. Forwards the question to the AWS Lambda backend via Kong API Gateway
#   5. Receives the structured JSON response (answer, citations, sources)
#   6. Formats the response into a readable Teams message
#   7. Sends the formatted response back to the user in Teams
# ============================================================
@AGENT_APP.activity("message")
async def on_message(context: TurnContext, _state: TurnState):
    """
    Primary message handler for all incoming user messages.
    
    Receives the user's question text from the Teams activity context,
    validates the input, forwards it to the Lambda backend via Kong,
    and returns the formatted response to the user.
    
    The conversation.id from Teams is passed as session_id to Lambda,
    enabling the backend to maintain context across multiple messages
    in the same chat thread.
    """
    user_question = context.activity.text
    
    if not user_question or not user_question.strip():
        await context.send_activity("Please type a question and I'll search our knowledge base.")
        return
    
    # Strip bot mention (in group chats, Teams prepends @BotName to the message text)
    user_question = user_question.strip()
    
    # Send a typing indicator to the Teams chat so the user sees
    # "Bot is typing..." while waiting for the Lambda response
    await context.send_activity(Activity(type=ActivityTypes.typing))
    
    # Log the first 100 characters of the question for debugging
    # (truncated to avoid excessively long log entries)
    logger.info(f"Processing question: {user_question[:100]}...")
    
    # Forward the user's question to the Lambda /chat endpoint via Kong.
    # The Teams conversation.id is used as the session_id so Lambda can
    # track multi-turn conversations within the same chat thread.
    km_response = await call_km_agent(
        question=user_question,
        session_id=context.activity.conversation.id
    )
    
    # Log the response metadata for debugging and monitoring
    logger.info(f"Got response - intent: {km_response.get('intent')}, "
                f"correlation_id: {km_response.get('correlation_id')}")
    
    # Convert the raw Lambda JSON response into a formatted Teams message
    # with answer text, citation references, and clickable source links
    formatted_message = format_teams_response(km_response)
    await context.send_activity(formatted_message)


# ============================================================
# SERVER STARTUP
# Entry point when running this file directly (python bot_handler.py).
# Starts an aiohttp web server that listens for incoming HTTP POST
# requests from Azure Bot Service at the /api/messages endpoint.
#
# The if __name__ == "__main__" guard ensures this block only runs
# when the file is executed directly, not when it is imported as
# a module by another Python file.
#
# If the server fails to start (e.g., port already in use, missing
# dependencies), the error is logged and re-raised so the process
# exits with a non-zero status code (useful for container health checks).
# ============================================================
if __name__ == "__main__":
    logger.info(f"Starting KM Agent Bot on port {PORT}")
    logger.info(f"Kong API URL: {KONG_API_URL}")
    logger.info(f"Messaging endpoint: http://localhost:{PORT}/api/messages")
    
    try:
        start_server(AGENT_APP, None, port=PORT)
    except Exception as error:
        logger.error(f"Bot failed to start: {error}")
        raise error
