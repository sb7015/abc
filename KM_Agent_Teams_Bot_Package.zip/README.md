# KM Agent — Standalone Teams Bot

## Overview
This is a standalone Microsoft Teams bot for the Agentic Knowledge Management solution. 
It acts as a thin translation layer between Teams and your AWS Lambda backend.

## Architecture
```
Teams User types question
       ↓
Azure Bot Service (free routing — CLIENT registers)
       ↓
Kong API Gateway (CLIENT owns — auth + rate limiting)
       ↓
Bot Handler (this code — translates Teams ↔ Lambda JSON)
       ↓
AWS Lambda /chat endpoint (YOUR existing Strands Agent)
  ├─► Tool 1: Intent Classification (Bedrock Claude)
  ├─► Tool 2: Query Enhancement (Bedrock Claude)  
  ├─► Tool 3: Document Search (SharePoint via OBO)
  └─► Answer Synthesis with Citations (Bedrock Claude)
       ↓
Response JSON (answer + citations + sources)
       ↓
Bot formats as Teams message → sent back to user
```

## What's In This Package

| File | Purpose |
|---|---|
| `bot_handler.py` | Main bot code — receives Teams messages, calls Lambda, returns response |
| `requirements.txt` | Python dependencies (M365 Agents SDK) |
| `.env.template` | Environment variables template |
| `appPackage/manifest.json` | Teams app manifest (CLIENT fills in placeholders) |
| `appPackage/color.png` | 192x192 app icon |
| `appPackage/outline.png` | 32x32 outline icon |

## Placeholders to Replace

| Placeholder | Who Provides | Where |
|---|---|---|
| `{{APP_ID}}` | Client (generate GUID) | manifest.json |
| `{{AZURE_BOT_ID}}` | Client (Azure Bot Registration App ID) | manifest.json |
| `{{BOT_HOSTING_DOMAIN}}` | Client (domain where bot is hosted) | manifest.json |
| `KONG_API_URL` | Client (Kong gateway URL) | .env |
| `MicrosoftAppId` | Client (Azure Bot App ID) | .env |
| `MicrosoftAppPassword` | Client (Azure Bot App Secret) | .env |

## How to Run Locally (Testing)

### Step 1: Install dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Copy environment template
```bash
cp .env.template .env
# Edit .env — set KONG_API_URL to your Lambda endpoint
```

### Step 3: Run the bot
```bash
python bot_handler.py
```
Bot starts on http://localhost:3978

### Step 4: Test with Agents Playground
```bash
# In another terminal:
npm install -g @microsoft/agents-playground
agentsplayground
```
Opens a Teams-like UI at http://localhost:4000 — chat with your bot!

## How to Deploy (Client's Responsibility)

### Step 1: Register Azure Bot
1. Go to https://portal.azure.com
2. Create resource → "Azure Bot"
3. Set Messaging Endpoint to: `https://<your-host>/api/messages`
4. Copy App ID and App Password

### Step 2: Host the Bot
Deploy `bot_handler.py` to any platform:
- Azure App Service (recommended for Microsoft ecosystem)
- AWS Lambda + API Gateway
- Docker container
- Any Python web server with HTTPS

### Step 3: Deploy Teams App
1. Replace placeholders in `appPackage/manifest.json`
2. Zip the appPackage folder: `cd appPackage && zip -r ../km-bot.zip *`
3. Upload via Teams Admin Center → Teams apps → Upload new app

## API Contract

### What the bot sends to Lambda (via Kong):
```json
POST /chat
{
    "question": "What is the SOP for claims appeal?",
    "session_id": "teams-conversation-id"
}
```

### What Lambda returns:
```json
{
    "answer": "Based on the source documents...",
    "citations": "[1] SOP-Claims-Appeal-v3.2.pdf - https://...",
    "intent": "SOP",
    "correlation_id": "uuid",
    "session_id": "uuid",
    "sources": [
        {
            "title": "SOP-Claims-Appeal-v3.2.pdf",
            "url": "https://sharepoint.example.com/...",
            "snippet": "Claims Appeal Standard Operating..."
        }
    ],
    "metadata": {
        "enhanced_queries": ["query1", "query2", "query3"],
        "documents_found": 2,
        "model": "claude-3-5-sonnet-v2"
    }
}
```

The bot formats this into a readable Teams message with clickable source links.
