"""
S3 Storage Manager
==================
Thin abstraction over boto3 S3 operations for the knowledge base layer.
All other modules use this instead of calling boto3 directly — keeps
swap-out clean if production wants to move to Azure Blob, GCS, etc.

Usage:
    from storage.s3_manager import S3Manager
    s3 = S3Manager()
    s3.upload_markdown("hr", "# HR Knowledge Base\n...")
    content = s3.download_markdown("hr")
    exists = s3.exists("hr")
"""
import io
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import boto3
from botocore.exceptions import ClientError

from config.settings import settings

logger = logging.getLogger(__name__)


class S3StorageError(Exception):
    """Raised when S3 operations fail."""
    pass


class S3Manager:
    """Manages S3 operations for the knowledge base."""

    def __init__(
        self,
        bucket_name: Optional[str] = None,
        region: Optional[str] = None,
        kb_prefix: Optional[str] = None,
    ):
        self.bucket_name = bucket_name or settings.s3_bucket_name
        self.region = region or settings.aws_region
        self.kb_prefix = kb_prefix or settings.s3_kb_prefix

        if not self.bucket_name:
            raise S3StorageError(
                "S3_BUCKET_NAME not configured — run setup_aws.py first"
            )

        self._client = boto3.client("s3", region_name=self.region)
        logger.info(
            f"S3Manager initialized | bucket={self.bucket_name} "
            f"prefix={self.kb_prefix}"
        )

    # ============================================================
    # Path helpers
    # ============================================================
    def _kb_key(self, department: str) -> str:
        """S3 key for a department's consolidated .md file."""
        return f"{self.kb_prefix}{department.lower()}.md"

    def _raw_pdf_key(self, department: str, filename: str) -> str:
        """S3 key for raw uploaded PDFs (used by BDA as input)."""
        return f"{self.kb_prefix}_raw/{department.lower()}/{filename}"

    def _bda_output_prefix(self, department: str, job_id: str) -> str:
        """S3 prefix for BDA job outputs."""
        return f"{self.kb_prefix}_bda_output/{department.lower()}/{job_id}/"

    # ============================================================
    # Markdown knowledge base operations
    # ============================================================
    def upload_markdown(
        self, department: str, content: str, metadata: Optional[Dict[str, str]] = None
    ) -> str:
        """
        Upload consolidated markdown for a department.
        Returns the S3 URI.
        """
        key = self._kb_key(department)
        body = content.encode("utf-8")

        meta = {
            "department": department.lower(),
            "size_bytes": str(len(body)),
            "uploaded_at": datetime.utcnow().isoformat() + "Z",
        }
        if metadata:
            meta.update(metadata)

        try:
            self._client.put_object(
                Bucket=self.bucket_name,
                Key=key,
                Body=body,
                ContentType="text/markdown; charset=utf-8",
                Metadata=meta,
            )
            uri = f"s3://{self.bucket_name}/{key}"
            logger.info(
                f"Uploaded markdown | department={department} "
                f"uri={uri} size_bytes={len(body)}"
            )
            return uri
        except ClientError as e:
            raise S3StorageError(
                f"Failed to upload markdown for {department}: {e.response['Error']['Message']}"
            ) from e

    def download_markdown(self, department: str) -> str:
        """Download consolidated markdown for a department. Returns content as string."""
        key = self._kb_key(department)
        try:
            response = self._client.get_object(Bucket=self.bucket_name, Key=key)
            content = response["Body"].read().decode("utf-8")
            logger.info(
                f"Downloaded markdown | department={department} "
                f"size_bytes={len(content)}"
            )
            return content
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code in ("NoSuchKey", "404"):
                raise S3StorageError(
                    f"No knowledge base found for '{department}'. "
                    f"Run: python -m ingestion.cli --dept {department} --pdf-folder <path>"
                ) from e
            raise S3StorageError(
                f"Failed to download markdown for {department}: {e.response['Error']['Message']}"
            ) from e

    def exists(self, department: str) -> bool:
        """Check whether a department's markdown KB exists."""
        key = self._kb_key(department)
        try:
            self._client.head_object(Bucket=self.bucket_name, Key=key)
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] in ("404", "NoSuchKey"):
                return False
            raise S3StorageError(
                f"Failed to check existence for {department}: {e.response['Error']['Message']}"
            ) from e

    def get_metadata(self, department: str) -> Dict[str, Any]:
        """Get metadata for a department's KB (size, last modified, etc.)."""
        key = self._kb_key(department)
        try:
            response = self._client.head_object(Bucket=self.bucket_name, Key=key)
            return {
                "department": department,
                "key": key,
                "size_bytes": response.get("ContentLength", 0),
                "last_modified": response.get("LastModified").isoformat() if response.get("LastModified") else None,
                "etag": response.get("ETag", "").strip('"'),
                "content_type": response.get("ContentType"),
                "metadata": response.get("Metadata", {}),
            }
        except ClientError as e:
            raise S3StorageError(
                f"Failed to get metadata for {department}: {e.response['Error']['Message']}"
            ) from e

    def list_departments(self) -> List[Dict[str, Any]]:
        """List all departments with knowledge bases in S3."""
        try:
            response = self._client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=self.kb_prefix,
                Delimiter="/",
            )
            departments = []
            for obj in response.get("Contents", []):
                key = obj["Key"]
                # Skip BDA outputs and raw folders
                if "_bda_output" in key or "_raw" in key:
                    continue
                if key.endswith(".md"):
                    dept_name = key.replace(self.kb_prefix, "").replace(".md", "")
                    departments.append({
                        "department": dept_name,
                        "size_bytes": obj["Size"],
                        "last_modified": obj["LastModified"].isoformat(),
                        "etag": obj["ETag"].strip('"'),
                    })
            return departments
        except ClientError as e:
            raise S3StorageError(
                f"Failed to list departments: {e.response['Error']['Message']}"
            ) from e

    # ============================================================
    # Raw PDF operations (used by ingestion pipeline for BDA)
    # ============================================================
    def upload_raw_pdf(self, department: str, filename: str, file_path: str) -> str:
        """Upload a raw PDF for BDA processing. Returns S3 URI."""
        key = self._raw_pdf_key(department, filename)
        try:
            self._client.upload_file(
                Filename=file_path,
                Bucket=self.bucket_name,
                Key=key,
                ExtraArgs={"ContentType": "application/pdf"},
            )
            uri = f"s3://{self.bucket_name}/{key}"
            logger.info(
                f"Uploaded raw PDF | department={department} "
                f"file={filename} uri={uri}"
            )
            return uri
        except ClientError as e:
            raise S3StorageError(
                f"Failed to upload PDF {filename}: {e.response['Error']['Message']}"
            ) from e

    def get_bda_output_uri(self, department: str, job_id: str) -> str:
        """Get the S3 URI prefix where BDA writes its output for a given job."""
        return f"s3://{self.bucket_name}/{self._bda_output_prefix(department, job_id)}"

    def list_bda_outputs(self, department: str, job_id: str) -> List[str]:
        """List all output files from a BDA job."""
        prefix = self._bda_output_prefix(department, job_id)
        try:
            response = self._client.list_objects_v2(
                Bucket=self.bucket_name, Prefix=prefix
            )
            return [obj["Key"] for obj in response.get("Contents", [])]
        except ClientError as e:
            raise S3StorageError(
                f"Failed to list BDA outputs: {e.response['Error']['Message']}"
            ) from e

    def download_object(self, key: str) -> bytes:
        """Download raw bytes for any object by key."""
        try:
            response = self._client.get_object(Bucket=self.bucket_name, Key=key)
            return response["Body"].read()
        except ClientError as e:
            raise S3StorageError(
                f"Failed to download object {key}: {e.response['Error']['Message']}"
            ) from e

    def download_text(self, key: str, encoding: str = "utf-8") -> str:
        """Download object and decode as text."""
        return self.download_object(key).decode(encoding)

    def get_object_uri(self, key: str) -> str:
        """Build S3 URI for a key in this bucket."""
        return f"s3://{self.bucket_name}/{key}"


# ============================================================
# CLI test harness
# ============================================================
if __name__ == "__main__":
    import sys

    print("=" * 60)
    print("S3Manager — Smoke Test")
    print("=" * 60)

    s3 = S3Manager()
    print(f"Bucket:       {s3.bucket_name}")
    print(f"Region:       {s3.region}")
    print(f"KB Prefix:    {s3.kb_prefix}")

    # Test write
    test_dept = "_smoketest"
    test_content = "# Smoke Test\n\nThis is a test markdown file.\n"
    print(f"\n1. Uploading test markdown for '{test_dept}'...")
    uri = s3.upload_markdown(test_dept, test_content)
    print(f"   Uploaded: {uri}")

    # Test exists
    print(f"\n2. Checking existence...")
    print(f"   exists('{test_dept}'): {s3.exists(test_dept)}")
    print(f"   exists('nonexistent'): {s3.exists('nonexistent')}")

    # Test metadata
    print(f"\n3. Fetching metadata...")
    meta = s3.get_metadata(test_dept)
    for k, v in meta.items():
        print(f"   {k}: {v}")

    # Test download
    print(f"\n4. Downloading markdown...")
    content = s3.download_markdown(test_dept)
    print(f"   Content matches: {content == test_content}")

    # Test list
    print(f"\n5. Listing all departments...")
    depts = s3.list_departments()
    for d in depts:
        print(f"   - {d['department']} ({d['size_bytes']} bytes, modified {d['last_modified']})")

    # Cleanup
    print(f"\n6. Cleaning up test data...")
    s3._client.delete_object(Bucket=s3.bucket_name, Key=s3._kb_key(test_dept))
    print(f"   Deleted test object")

    print("\n" + "=" * 60)
    print("✅ All S3Manager operations working")
    print("=" * 60)