"""
Central configuration for the Low-Code RAG pipeline.
All settings loaded from environment variables (.env file).
Type-safe via Pydantic Settings.
"""
from pathlib import Path
from typing import List
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ============================================================
    # AWS Configuration
    # ============================================================
    aws_region: str = Field(default="us-east-1")
    aws_account_id: str = Field(default="")

    # ============================================================
    # S3 Configuration
    # ============================================================
    s3_bucket_name: str = Field(default="")
    s3_kb_prefix: str = Field(default="knowledge_base/")

    # ============================================================
    # Bedrock Models (cross-region inference profiles)
    # ============================================================
    bedrock_haiku_model_id: str = Field(
        default="us.anthropic.claude-haiku-4-5-20251001-v1:0"
    )
    bedrock_sonnet_model_id: str = Field(
        default="us.anthropic.claude-sonnet-4-20250514-v1:0"
    )

    # ============================================================
    # Bedrock Data Automation
    # ============================================================
    bda_project_arn: str = Field(default="")

    # ============================================================
    # AgentCore Code Interpreter
    # ============================================================
    agentcore_sandbox_timeout_seconds: int = Field(default=30)
    agentcore_max_output_tokens: int = Field(default=2000)

    # ============================================================
    # Pipeline Configuration
    # ============================================================
    grep_top_n_chunks: int = Field(default=5)
    grep_chunk_context_lines: int = Field(default=8)
    grep_max_chunk_tokens: int = Field(default=400)
    synonym_expansion_enabled: bool = Field(default=True)
    prompt_caching_enabled: bool = Field(default=True)

    # ============================================================
    # API Configuration
    # ============================================================
    api_host: str = Field(default="0.0.0.0")
    api_port: int = Field(default=8000)
    api_log_level: str = Field(default="INFO")
    api_cors_origins: str = Field(default="*")

    # ============================================================
    # Cost Tracking (USD per 1M tokens) — for observability
    # ============================================================
    haiku_input_cost_per_1m: float = Field(default=1.00)
    haiku_output_cost_per_1m: float = Field(default=5.00)
    haiku_cached_input_cost_per_1m: float = Field(default=0.10)
    sonnet_input_cost_per_1m: float = Field(default=3.00)
    sonnet_output_cost_per_1m: float = Field(default=15.00)
    sonnet_cached_input_cost_per_1m: float = Field(default=0.30)

    # ============================================================
    # Derived paths
    # ============================================================
    @property
    def project_root(self) -> Path:
        return Path(__file__).parent.parent

    @property
    def skills_dir(self) -> Path:
        return self.project_root / "config" / "skills"

    @property
    def cors_origins_list(self) -> List[str]:
        if self.api_cors_origins == "*":
            return ["*"]
        return [origin.strip() for origin in self.api_cors_origins.split(",")]

    def s3_kb_key(self, department: str) -> str:
        """S3 key for a department's consolidated .md file."""
        return f"{self.s3_kb_prefix}{department.lower()}.md"

    def skills_path(self, department: str) -> Path:
        """Local path to a department's skills.md config."""
        return self.skills_dir / f"{department.lower()}.skills.md"


# Singleton instance — import this everywhere
settings = Settings()


if __name__ == "__main__":
    # Quick verification when run directly
    print("=" * 60)
    print("Loaded Settings")
    print("=" * 60)
    print(f"AWS Region:           {settings.aws_region}")
    print(f"AWS Account ID:       {settings.aws_account_id}")
    print(f"S3 Bucket:            {settings.s3_bucket_name or '(not set — run setup_aws.py)'}")
    print(f"Haiku Model:          {settings.bedrock_haiku_model_id}")
    print(f"Sonnet Model:         {settings.bedrock_sonnet_model_id}")
    print(f"BDA Project ARN:      {settings.bda_project_arn or '(not set — run setup_aws.py)'}")
    print(f"Prompt Caching:       {settings.prompt_caching_enabled}")
    print(f"Grep Top-N Chunks:    {settings.grep_top_n_chunks}")
    print(f"Skills Directory:     {settings.skills_dir}")
    print(f"HR Skills Path:       {settings.skills_path('hr')}")
    print(f"HR S3 Key:            {settings.s3_kb_key('hr')}")
    print("=" * 60)