"""Query endpoints — /v1/query and /v1/query/stream."""
import logging
from typing import Dict
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

from api.schemas import QueryRequest, QueryResponse, MetricsBlock, ErrorResponse
from core.pipeline import RAGPipeline, QueryPipelineError

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/v1", tags=["query"])

# Pipeline cache per department (initialized lazily, reused for prompt caching benefit)
_pipelines: Dict[str, RAGPipeline] = {}


def _get_pipeline(department: str) -> RAGPipeline:
    dept = department.lower().strip()
    if dept not in _pipelines:
        logger.info(f"Initializing pipeline for dept={dept}")
        _pipelines[dept] = RAGPipeline(department=dept)
    return _pipelines[dept]


@router.post(
    "/query",
    response_model=QueryResponse,
    responses={
        400: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
async def query(req: QueryRequest) -> QueryResponse:
    """Run the full RAG pipeline and return a cited answer."""
    try:
        pipeline = _get_pipeline(req.department)
    except QueryPipelineError as e:
        logger.error(f"Pipeline init failed: {e}")
        raise HTTPException(
            status_code=400,
            detail={"error": "pipeline_init_failed", "detail": str(e), "stage": "init"},
        )

    history = [t.model_dump() for t in req.history] if req.history else []

    try:
        result = pipeline.ask(req.question, history=history)
    except QueryPipelineError as e:
        logger.error(f"Pipeline ask failed: {e}")
        msg = str(e)
        stage = "unknown"
        if "Step 2" in msg:
            stage = "rewrite"
        elif "Step 3" in msg:
            stage = "grep"
        elif "Step 5" in msg:
            stage = "synthesize"
        raise HTTPException(
            status_code=500,
            detail={"error": "pipeline_failed", "detail": msg, "stage": stage},
        )

    return QueryResponse(
        answer=result.answer,
        intent=result.intent,
        rewritten_query=result.rewritten_query,
        sources_cited=result.sources_cited,
        matches_used=result.matches_used,
        session_id=req.session_id,
        metrics=MetricsBlock(**result.metrics.__dict__),
    )