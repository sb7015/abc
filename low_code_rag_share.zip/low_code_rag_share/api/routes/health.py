"""Health and department listing endpoints."""
import logging
from fastapi import APIRouter, HTTPException

from api.schemas import HealthResponse, DepartmentsResponse, DepartmentInfo
from storage.s3_manager import S3Manager, S3StorageError

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/v1", tags=["meta"])

_s3 = S3Manager()


@router.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    """Health check. Lists available departments (those with .md in S3)."""
    try:
        depts = _s3.list_departments()
        dept_names = [d["department"] for d in depts]
    except S3StorageError as e:
        raise HTTPException(status_code=503, detail=str(e))
    return HealthResponse(
        status="ok",
        service="low-code-rag",
        version="1.0.0",
        departments_available=dept_names,
    )


@router.get("/departments", response_model=DepartmentsResponse)
async def departments() -> DepartmentsResponse:
    """List all departments with a consolidated KB."""
    try:
        raw = _s3.list_departments()
    except S3StorageError as e:
        raise HTTPException(status_code=503, detail=str(e))
    return DepartmentsResponse(
        departments=[
            DepartmentInfo(
                department=d["department"],
                size_bytes=d["size_bytes"],
                last_modified=d["last_modified"],
                etag=d["etag"],
            )
            for d in raw
        ]
    )