"""Pydantic request/response models for the RAG API."""
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class ChatTurn(BaseModel):
    role: str = Field(..., description="'user' or 'assistant'")
    content: str


class QueryRequest(BaseModel):
    department: str = Field(..., description="Department (e.g., 'hr')")
    question: str = Field(..., min_length=1, max_length=2000)
    history: Optional[List[ChatTurn]] = Field(default=None, description="Prior chat turns")
    session_id: Optional[str] = Field(default=None, description="Client-generated session id")


class MetricsBlock(BaseModel):
    rewrite_time_seconds: float
    grep_time_seconds: float
    synthesis_time_seconds: float
    total_time_seconds: float
    haiku_input_tokens: int
    haiku_output_tokens: int
    haiku_cached_tokens: int
    haiku_cache_write_tokens: int
    sonnet_input_tokens: int
    sonnet_output_tokens: int
    sonnet_cached_tokens: int
    sonnet_cache_write_tokens: int
    grep_total_matches: int
    grep_returned_chunks: int
    grep_output_tokens_estimate: int
    estimated_cost_usd: float


class QueryResponse(BaseModel):
    answer: str
    intent: str
    rewritten_query: str
    sources_cited: List[str]
    matches_used: int
    session_id: Optional[str]
    metrics: MetricsBlock


class DepartmentInfo(BaseModel):
    department: str
    size_bytes: int
    last_modified: str
    etag: str


class DepartmentsResponse(BaseModel):
    departments: List[DepartmentInfo]


class HealthResponse(BaseModel):
    status: str
    service: str
    version: str
    departments_available: List[str]


class ErrorResponse(BaseModel):
    error: str
    detail: Optional[str] = None
    stage: Optional[str] = Field(default=None, description="Which pipeline step failed")