"""FastAPI app entrypoint."""
import sys
import logging
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

sys.path.insert(0, str(Path(__file__).parent.parent))

from config.settings import settings
from api.routes.query import router as query_router
from api.routes.health import router as health_router

logging.basicConfig(
    level=settings.api_log_level,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Low-Code RAG API",
    description="Departmental Q&A using BDA + AgentCore grep + Haiku/Sonnet.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health_router)
app.include_router(query_router)


@app.on_event("startup")
async def _startup() -> None:
    logger.info(
        f"Low-Code RAG API starting | region={settings.aws_region} "
        f"bucket={settings.s3_bucket_name} "
        f"haiku={settings.bedrock_haiku_model_id} "
        f"sonnet={settings.bedrock_sonnet_model_id}"
    )


@app.get("/")
async def root() -> dict:
    return {"service": "low-code-rag", "docs": "/docs"}