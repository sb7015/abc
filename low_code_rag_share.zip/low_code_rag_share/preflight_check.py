"""
Pre-flight AWS Access Validation
=================================
Validates that all AWS services required by the Low-Code RAG pipeline
are accessible with the current credentials BEFORE we write any application code.

Run: python preflight_check.py

Checks performed:
  1. AWS credentials valid (STS)
  2. Bedrock Runtime — Haiku 4.5 model invocation
  3. Bedrock Runtime — Sonnet 4 model invocation
  4. Bedrock — Prompt caching support
  5. Bedrock Data Automation (BDA) — list/create permission
  6. Bedrock AgentCore — code interpreter availability
  7. S3 — create bucket permission
  8. S3 — read/write/delete object permission
  9. IAM — get caller identity + check role permissions
"""
import os
import sys
import json
import time
import uuid
import boto3
from botocore.exceptions import ClientError, NoCredentialsError

# ANSI colors for terminal output
class C:
    OK = '\033[92m'
    WARN = '\033[93m'
    FAIL = '\033[91m'
    INFO = '\033[94m'
    BOLD = '\033[1m'
    END = '\033[0m'

REGION = "us-east-1"
HAIKU_MODEL_ID = "us.anthropic.claude-haiku-4-5-20251001-v1:0"
SONNET_MODEL_ID = "us.anthropic.claude-sonnet-4-20250514-v1:0"

results = []

def log_pass(check, detail=""):
    msg = f"{C.OK}[PASS]{C.END} {check}"
    if detail:
        msg += f" — {C.INFO}{detail}{C.END}"
    print(msg)
    results.append(("PASS", check, detail))

def log_fail(check, detail=""):
    msg = f"{C.FAIL}[FAIL]{C.END} {check}"
    if detail:
        msg += f" — {detail}"
    print(msg)
    results.append(("FAIL", check, detail))

def log_warn(check, detail=""):
    msg = f"{C.WARN}[WARN]{C.END} {check}"
    if detail:
        msg += f" — {detail}"
    print(msg)
    results.append(("WARN", check, detail))

def section(title):
    print(f"\n{C.BOLD}{'=' * 65}{C.END}")
    print(f"{C.BOLD}{title}{C.END}")
    print(f"{C.BOLD}{'=' * 65}{C.END}")


# ============================================================
# CHECK 1: AWS Credentials
# ============================================================
def check_credentials():
    section("1. AWS Credentials & Identity")
    try:
        sts = boto3.client("sts", region_name=REGION)
        identity = sts.get_caller_identity()
        log_pass("AWS credentials valid", f"Account: {identity['Account']}")
        log_pass("IAM identity", f"ARN: {identity['Arn']}")
        return identity
    except NoCredentialsError:
        log_fail("AWS credentials not found",
                 "Run 'aws configure' or set AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY")
        sys.exit(1)
    except ClientError as e:
        log_fail("STS get_caller_identity", str(e))
        sys.exit(1)


# ============================================================
# CHECK 2 & 3: Bedrock Model Invocation (Haiku + Sonnet)
# ============================================================
def check_bedrock_runtime():
    section("2. Bedrock Runtime — Model Invocation")
    try:
        runtime = boto3.client("bedrock-runtime", region_name=REGION)
    except Exception as e:
        log_fail("Bedrock Runtime client init", str(e))
        return False

    # Test Haiku
    try:
        response = runtime.invoke_model(
            modelId=HAIKU_MODEL_ID,
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 50,
                "messages": [{"role": "user", "content": "Say 'OK' in one word."}]
            })
        )
        body = json.loads(response['body'].read())
        text = body['content'][0]['text'].strip()
        usage = body.get('usage', {})
        log_pass("Haiku 4.5 invocation",
                 f"Response: '{text}' | Input tokens: {usage.get('input_tokens')}, "
                 f"Output: {usage.get('output_tokens')}")
    except ClientError as e:
        log_fail("Haiku 4.5 invocation", f"{e.response['Error']['Code']}: {e.response['Error']['Message']}")
        return False

    # Test Sonnet
    try:
        response = runtime.invoke_model(
            modelId=SONNET_MODEL_ID,
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 50,
                "messages": [{"role": "user", "content": "Say 'OK' in one word."}]
            })
        )
        body = json.loads(response['body'].read())
        text = body['content'][0]['text'].strip()
        usage = body.get('usage', {})
        log_pass("Sonnet 4 invocation",
                 f"Response: '{text}' | Input tokens: {usage.get('input_tokens')}, "
                 f"Output: {usage.get('output_tokens')}")
    except ClientError as e:
        log_fail("Sonnet 4 invocation", f"{e.response['Error']['Code']}: {e.response['Error']['Message']}")
        return False

    return True


# ============================================================
# CHECK 4: Prompt Caching Support
# ============================================================
def check_prompt_caching():
    section("3. Bedrock — Prompt Caching")
    try:
        runtime = boto3.client("bedrock-runtime", region_name=REGION)

        # Build a prompt large enough to trigger caching (>1024 tokens for Haiku)
        large_context = "This is a system context. " * 300  # ~1500 tokens

        response = runtime.invoke_model(
            modelId=HAIKU_MODEL_ID,
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 50,
                "system": [
                    {
                        "type": "text",
                        "text": large_context,
                        "cache_control": {"type": "ephemeral"}
                    }
                ],
                "messages": [{"role": "user", "content": "Respond with 'OK'."}]
            })
        )
        body = json.loads(response['body'].read())
        usage = body.get('usage', {})

        cache_write = usage.get('cache_creation_input_tokens', 0)
        cache_read = usage.get('cache_read_input_tokens', 0)

        if cache_write > 0 or cache_read > 0:
            log_pass("Prompt caching supported",
                     f"Cache write: {cache_write} tokens, Cache read: {cache_read} tokens")
        else:
            log_warn("Prompt caching",
                     "API call succeeded but no cache tokens reported (may need larger prompt)")
        return True
    except ClientError as e:
        log_warn("Prompt caching", f"{e.response['Error']['Code']}: {e.response['Error']['Message']}")
        return False


# ============================================================
# CHECK 5: Bedrock Data Automation (BDA)
# ============================================================
def check_bda():
    section("4. Bedrock Data Automation (BDA)")
    try:
        bda = boto3.client("bedrock-data-automation", region_name=REGION)
        projects = bda.list_data_automation_projects()
        log_pass("BDA list_data_automation_projects",
                 f"{len(projects.get('projects', []))} project(s) found")

        # Check create permission via dry-run logic (we don't actually create)
        try:
            bda.list_blueprints(resourceOwner="SERVICE")
            log_pass("BDA list_blueprints (system blueprints)")
        except ClientError as e:
            log_warn("BDA list_blueprints", e.response['Error']['Message'])

        return True
    except ClientError as e:
        code = e.response['Error']['Code']
        if code == 'AccessDeniedException':
            log_fail("BDA access", "AccessDeniedException — IAM permissions needed for bedrock-data-automation:*")
        else:
            log_fail("BDA access", f"{code}: {e.response['Error']['Message']}")
        return False
    except Exception as e:
        log_fail("BDA client", str(e))
        return False


# ============================================================
# CHECK 6: AgentCore Code Interpreter
# ============================================================
def check_agentcore():
    section("5. Bedrock AgentCore — Code Interpreter")
    try:
        # AgentCore code interpreter is accessed via bedrock-agentcore client
        agentcore = boto3.client("bedrock-agentcore-control", region_name=REGION)
        try:
            sandboxes = agentcore.list_code_interpreters()
            log_pass("AgentCore code interpreter access",
                     f"{len(sandboxes.get('codeInterpreterSummaries', []))} interpreter(s) listed")
            return True
        except ClientError as e:
            code = e.response['Error']['Code']
            if 'AccessDenied' in code or 'NotAuthorized' in code:
                log_fail("AgentCore code interpreter", "AccessDenied — needs bedrock-agentcore:* permissions")
            else:
                log_warn("AgentCore code interpreter", f"{code}: {e.response['Error']['Message']}")
            return False
    except Exception as e:
        # Service might not be enabled in this region or SDK version
        log_warn("AgentCore client",
                 f"Service client unavailable: {str(e)[:100]} — may need newer boto3 or different endpoint")
        return False


# ============================================================
# CHECK 7 & 8: S3 Bucket + Object Operations
# ============================================================
def check_s3(account_id):
    section("6. S3 — Bucket & Object Operations")
    try:
        s3 = boto3.client("s3", region_name=REGION)
    except Exception as e:
        log_fail("S3 client init", str(e))
        return False

    # List buckets
    try:
        buckets = s3.list_buckets()
        log_pass("S3 list_buckets", f"{len(buckets.get('Buckets', []))} bucket(s) accessible")
    except ClientError as e:
        log_fail("S3 list_buckets", e.response['Error']['Message'])
        return False

    # Test create + write + read + delete with a temporary bucket
    test_bucket = f"low-code-rag-preflight-{account_id}-{int(time.time())}"
    test_key = "preflight/test.txt"
    test_content = b"Pre-flight check: write/read/delete validation."

    try:
        s3.create_bucket(Bucket=test_bucket)
        log_pass("S3 create_bucket", test_bucket)
    except ClientError as e:
        log_fail("S3 create_bucket", f"{e.response['Error']['Code']}: {e.response['Error']['Message']}")
        return False

    try:
        s3.put_object(Bucket=test_bucket, Key=test_key, Body=test_content)
        log_pass("S3 put_object")
    except ClientError as e:
        log_fail("S3 put_object", e.response['Error']['Message'])

    try:
        obj = s3.get_object(Bucket=test_bucket, Key=test_key)
        content = obj['Body'].read()
        if content == test_content:
            log_pass("S3 get_object", "round-trip content match")
        else:
            log_fail("S3 get_object", "content mismatch")
    except ClientError as e:
        log_fail("S3 get_object", e.response['Error']['Message'])

    try:
        s3.delete_object(Bucket=test_bucket, Key=test_key)
        log_pass("S3 delete_object")
    except ClientError as e:
        log_warn("S3 delete_object", e.response['Error']['Message'])

    try:
        s3.delete_bucket(Bucket=test_bucket)
        log_pass("S3 delete_bucket", "test bucket cleaned up")
    except ClientError as e:
        log_warn("S3 delete_bucket",
                 f"could not delete test bucket {test_bucket} — please remove manually")

    return True


# ============================================================
# CHECK 9: Region & Quota Sanity
# ============================================================
def check_region_quota():
    section("7. Region Configuration")
    session = boto3.session.Session()
    configured_region = session.region_name or os.environ.get("AWS_DEFAULT_REGION")
    if configured_region == REGION:
        log_pass("Region configured", configured_region)
    else:
        log_warn("Region mismatch",
                 f"Configured: {configured_region}, Expected: {REGION}")


# ============================================================
# Summary
# ============================================================
def print_summary():
    section("PRE-FLIGHT SUMMARY")
    passed = sum(1 for r in results if r[0] == "PASS")
    failed = sum(1 for r in results if r[0] == "FAIL")
    warned = sum(1 for r in results if r[0] == "WARN")
    total = len(results)

    print(f"  {C.OK}Passed:{C.END}  {passed}/{total}")
    print(f"  {C.WARN}Warnings:{C.END} {warned}/{total}")
    print(f"  {C.FAIL}Failed:{C.END}  {failed}/{total}")

    if failed > 0:
        print(f"\n{C.FAIL}{C.BOLD}BLOCKERS — must be fixed before proceeding:{C.END}")
        for status, check, detail in results:
            if status == "FAIL":
                print(f"  - {check}: {detail}")
        sys.exit(1)
    elif warned > 0:
        print(f"\n{C.WARN}Warnings (non-blocking, proceed with caution):{C.END}")
        for status, check, detail in results:
            if status == "WARN":
                print(f"  - {check}: {detail}")
        print(f"\n{C.OK}{C.BOLD}Pre-flight passed with warnings. Safe to proceed.{C.END}")
    else:
        print(f"\n{C.OK}{C.BOLD}All checks passed. Ready to build!{C.END}")


# ============================================================
# Main
# ============================================================
if __name__ == "__main__":
    print(f"{C.BOLD}Low-Code RAG — AWS Pre-flight Check{C.END}")
    print(f"Region: {REGION}\n")

    identity = check_credentials()
    account_id = identity['Account']

    check_bedrock_runtime()
    check_prompt_caching()
    check_bda()
    check_agentcore()
    check_s3(account_id)
    check_region_quota()

    print_summary()