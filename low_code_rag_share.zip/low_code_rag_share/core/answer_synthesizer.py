"""
Answer Synthesizer (Sonnet)
============================
Takes user question + grep matches + skills.md, produces final cited answer.

Strict mode: failure raises. No fallback.
"""
import sys
import json
import logging
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass

sys.path.insert(0, str(Path(__file__).parent.parent))

import boto3
from botocore.exceptions import ClientError

from config.settings import settings
from core.grep_engine import GrepMatch

logger = logging.getLogger(__name__)


@dataclass
class SynthesisResult:
    answer: str
    input_tokens: int
    output_tokens: int
    cached_input_tokens: int
    cache_creation_tokens: int
    sources_cited: List[str]


class AnswerSynthesisError(Exception):
    """Raised when Sonnet synthesis fails. Never caught for fallback."""
    pass


class AnswerSynthesizer:
    """Uses Sonnet + prompt caching to synthesize cited answers from grep chunks."""

    SYSTEM_PROMPT_TEMPLATE = """You are the HR assistant for Acme Corporation.
You answer employee questions using ONLY the matched chunks provided below.
Follow the department's skills configuration EXACTLY.

=== DEPARTMENT SKILLS CONFIG ===
{skills_md}
=== END CONFIG ===

CRITICAL RULES:
1. Cite EVERY factual claim using the format [Section X.Y] or [Line N] from the chunks.
2. NEVER invent information not present in the chunks.
3. If the chunks do not contain the answer, use the formal refusal pattern from Section 5.4.
4. Match response length to intent (Section 5.3): LOOKUP=1-3 sentences, EXPLAIN=1-2 paragraphs, etc.
5. Apply mandatory disclaimers from Section 5.5 when relevant.
6. Use second-person ("you", "your") and professional tone.

OUTPUT: plain text answer only. No JSON, no preamble, no meta-commentary."""

    USER_PROMPT_TEMPLATE = """User question: {question}
Rewritten query: {rewritten_query}
Intent: {intent}

Conversation history (most recent last):
{history}

=== MATCHED CHUNKS FROM hr.md ===
{chunks_block}
=== END CHUNKS ===

Total matches found in KB: {total_found}
Chunks returned: {chunks_returned}

Now write the answer for the user, following all rules. If no chunks were returned or they don't answer the question, use the formal refusal pattern."""

    def __init__(
        self,
        department: str,
        region: Optional[str] = None,
        model_id: Optional[str] = None,
    ):
        self.department = department.lower()
        self.region = region or settings.aws_region
        self.model_id = model_id or settings.bedrock_sonnet_model_id
        self._runtime = boto3.client("bedrock-runtime", region_name=self.region)

        # Load skills.md once at init - prompt-cached
        skills_path = settings.skills_path(self.department)
        if not skills_path.exists():
            raise AnswerSynthesisError(f"Skills config not found: {skills_path}")
        self.skills_md = skills_path.read_text(encoding="utf-8")
        self.system_prompt = self.SYSTEM_PROMPT_TEMPLATE.format(
            skills_md=self.skills_md
        )

        logger.info(
            f"AnswerSynthesizer initialized | dept={self.department} "
            f"model={self.model_id} skills_chars={len(self.skills_md)}"
        )

    def synthesize(
        self,
        question: str,
        rewritten_query: str,
        intent: str,
        matches: List[GrepMatch],
        total_found: int,
        history: Optional[List[Dict[str, str]]] = None,
        max_tokens: int = 800,
    ) -> SynthesisResult:
        """Generate cited answer. Raises on failure."""
        chunks_block = self._format_chunks(matches)
        history_str = self._format_history(history or [])

        user_content = self.USER_PROMPT_TEMPLATE.format(
            question=question,
            rewritten_query=rewritten_query,
            intent=intent,
            history=history_str,
            chunks_block=chunks_block,
            total_found=total_found,
            chunks_returned=len(matches),
        )

        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "temperature": 0.2,
            "system": [
                {
                    "type": "text",
                    "text": self.system_prompt,
                    "cache_control": {"type": "ephemeral"},
                }
            ],
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": user_content,
                        }
                    ],
                }
            ],
        }

        try:
            response = self._runtime.invoke_model(
                modelId=self.model_id, body=json.dumps(body)
            )
        except ClientError as e:
            raise AnswerSynthesisError(
                f"Bedrock invoke_model failed: {e.response['Error']['Message']}"
            ) from e

        payload = json.loads(response["body"].read())
        answer_text = payload["content"][0]["text"].strip()
        usage = payload.get("usage", {})

        # Extract cited sources for observability
        sources = sorted(set(
            m.source_doc for m in matches if m.source_doc
        ))

        return SynthesisResult(
            answer=answer_text,
            input_tokens=usage.get("input_tokens", 0),
            output_tokens=usage.get("output_tokens", 0),
            cached_input_tokens=usage.get("cache_read_input_tokens", 0),
            cache_creation_tokens=usage.get("cache_creation_input_tokens", 0),
            sources_cited=sources,
        )

    @staticmethod
    def _format_chunks(matches: List[GrepMatch]) -> str:
        if not matches:
            return "(NO MATCHES FOUND IN KNOWLEDGE BASE)"
        parts = []
        for i, m in enumerate(matches, 1):
            parts.append(
                f"--- Chunk {i} ---\n"
                f"Source: {m.source_doc or 'unknown'}\n"
                f"Section: {m.section or 'unknown'}\n"
                f"Line: {m.line_number}\n"
                f"Content:\n{m.chunk}\n"
            )
        return "\n".join(parts)

    @staticmethod
    def _format_history(history: List[Dict[str, str]]) -> str:
        if not history:
            return "(no previous turns)"
        lines = []
        for turn in history[-6:]:
            role = turn.get("role", "user")
            content = turn.get("content", "")
            lines.append(f"[{role}] {content}")
        return "\n".join(lines)


# ============================================================
# CLI smoke test
# ============================================================
if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )

    # Build a fake match for testing
    fake_match = GrepMatch(
        line_number=104,
        chunk=(
            "| L5-L6   | Manager / Senior Manager      | 24 | 12 | 7 |\n"
            "| L7+     | Director and above            | 30 | 12 | 7 |\n"
            "Note: Managers (L5 and above) get an additional 3 days of vacation "
            "compared to senior associates."
        ),
        matched_terms=["vacation", "manager", "L5", "L6"],
        section="2.1 Entitlement Table",
        source_doc="leave_policy.pdf",
    )

    synth = AnswerSynthesizer(department="hr")
    result = synth.synthesize(
        question="How many vacation days for managers?",
        rewritten_query="How many vacation days for managers (L5-L6)?",
        intent="LOOKUP",
        matches=[fake_match],
        total_found=2,
    )

    print("\n=== ANSWER ===")
    print(result.answer)
    print(f"\n=== TOKENS ===")
    print(f"input={result.input_tokens} output={result.output_tokens} "
          f"cached={result.cached_input_tokens} cache_write={result.cache_creation_tokens}")
    print(f"Sources cited: {result.sources_cited}")