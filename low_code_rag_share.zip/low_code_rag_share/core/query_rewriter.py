"""
Query Rewriter (Haiku)
======================
Takes user question + hr.skills.md, produces:
  - Rewritten self-contained query
  - Synonym-expanded regex pattern for grep
  - Query intent classification

Strict mode: if Haiku fails or returns invalid JSON, raise. No fallback.
"""
import sys
import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass

sys.path.insert(0, str(Path(__file__).parent.parent))

import boto3
from botocore.exceptions import ClientError

from config.settings import settings

logger = logging.getLogger(__name__)


@dataclass
class RewriteResult:
    """Output of query rewriting step."""
    original_query: str
    rewritten_query: str
    regex_pattern: str
    intent: str  # LOOKUP / EXPLAIN / PROCESS / ELIGIBILITY / OUT_OF_SCOPE
    synonyms_used: List[str]
    input_tokens: int
    output_tokens: int
    cached_input_tokens: int
    cache_creation_tokens: int


class QueryRewriteError(Exception):
    """Raised when Haiku rewriting fails. Never caught for fallback."""
    pass


class QueryRewriter:
    """Uses Haiku + prompt caching to rewrite queries and generate regex patterns."""

    SYSTEM_PROMPT_TEMPLATE = """You are a query rewriter for a departmental RAG system.

Your job: transform a user question into:
  1. A self-contained rewritten query (resolve pronouns, follow-ups)
  2. A case-insensitive regex pattern with synonym alternation for grep
  3. An intent classification

Follow the department's skills configuration below EXACTLY.

=== DEPARTMENT SKILLS CONFIG ===
{skills_md}
=== END CONFIG ===

OUTPUT FORMAT (strict JSON, no markdown fences, no prose):
{{
  "rewritten_query": "<self-contained version of the question>",
  "regex_pattern": "<Python regex with alternation, word boundaries, case-insensitive intent>",
  "intent": "LOOKUP|EXPLAIN|PROCESS|ELIGIBILITY|OUT_OF_SCOPE",
  "synonyms_used": ["term1", "term2", ...]
}}

REGEX RULES:
- Use \\b word boundaries around terms
- Combine synonyms with | alternation
- Do NOT include the (?i) flag - caller applies IGNORECASE
- Escape special regex chars in user-provided strings
- Keep pattern focused - no overly broad terms like "the|and|is"

EXAMPLE:
User: "How many vacation days for managers?"
Output:
{{
  "rewritten_query": "How many vacation days for managers?",
  "regex_pattern": "\\\\b(vacation|leave|PTO|paid time off|annual leave)\\\\b.*\\\\b(manager|supervisor|L5|L6)\\\\b|\\\\b(manager|supervisor|L5|L6)\\\\b.*\\\\b(vacation|leave|PTO|paid time off|annual leave)\\\\b",
  "intent": "LOOKUP",
  "synonyms_used": ["vacation", "leave", "PTO", "paid time off", "annual leave", "manager", "supervisor", "L5", "L6"]
}}

Respond with ONLY the JSON object. No other text."""

    USER_PROMPT_TEMPLATE = """Conversation history (most recent last):
{history}

Current user question: {question}

Produce the JSON now."""

    def __init__(
        self,
        department: str,
        region: Optional[str] = None,
        model_id: Optional[str] = None,
    ):
        self.department = department.lower()
        self.region = region or settings.aws_region
        self.model_id = model_id or settings.bedrock_haiku_model_id
        self._runtime = boto3.client("bedrock-runtime", region_name=self.region)

        # Load skills.md once at init - will be prompt-cached
        skills_path = settings.skills_path(self.department)
        if not skills_path.exists():
            raise QueryRewriteError(f"Skills config not found: {skills_path}")
        self.skills_md = skills_path.read_text(encoding="utf-8")
        self.system_prompt = self.SYSTEM_PROMPT_TEMPLATE.format(
            skills_md=self.skills_md
        )

        logger.info(
            f"QueryRewriter initialized | dept={self.department} "
            f"model={self.model_id} skills_chars={len(self.skills_md)}"
        )

    def rewrite(
        self,
        question: str,
        history: Optional[List[Dict[str, str]]] = None,
    ) -> RewriteResult:
        """Rewrite question. Raises QueryRewriteError on failure."""
        history_str = self._format_history(history or [])
        user_content = self.USER_PROMPT_TEMPLATE.format(
            history=history_str, question=question
        )

        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 600,
            "temperature": 0,
            "system": [
                {
                    "type": "text",
                    "text": self.system_prompt,
                    "cache_control": {"type": "ephemeral"},
                }
            ],
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": user_content,
                        }
                    ],
                }
            ],
        }

        try:
            response = self._runtime.invoke_model(
                modelId=self.model_id, body=json.dumps(body)
            )
        except ClientError as e:
            raise QueryRewriteError(
                f"Bedrock invoke_model failed: {e.response['Error']['Message']}"
            ) from e

        payload = json.loads(response["body"].read())
        raw_text = payload["content"][0]["text"].strip()
        usage = payload.get("usage", {})

        # Strip any accidental code fences
        if raw_text.startswith("```"):
            raw_text = raw_text.split("```")[1]
            if raw_text.startswith("json"):
                raw_text = raw_text[4:]
            raw_text = raw_text.strip()

        try:
            parsed = json.loads(raw_text)
        except json.JSONDecodeError as e:
            raise QueryRewriteError(
                f"Haiku returned invalid JSON: {e} | raw: {raw_text[:300]}"
            )

        required = {"rewritten_query", "regex_pattern", "intent", "synonyms_used"}
        missing = required - set(parsed.keys())
        if missing:
            raise QueryRewriteError(
                f"Haiku response missing required keys: {missing} | raw: {raw_text[:300]}"
            )

        valid_intents = {"LOOKUP", "EXPLAIN", "PROCESS", "ELIGIBILITY", "OUT_OF_SCOPE"}
        if parsed["intent"] not in valid_intents:
            raise QueryRewriteError(
                f"Invalid intent '{parsed['intent']}' | valid: {valid_intents}"
            )

        return RewriteResult(
            original_query=question,
            rewritten_query=parsed["rewritten_query"],
            regex_pattern=parsed["regex_pattern"],
            intent=parsed["intent"],
            synonyms_used=parsed["synonyms_used"],
            input_tokens=usage.get("input_tokens", 0),
            output_tokens=usage.get("output_tokens", 0),
            cached_input_tokens=usage.get("cache_read_input_tokens", 0),
            cache_creation_tokens=usage.get("cache_creation_input_tokens", 0),
        )

    @staticmethod
    def _format_history(history: List[Dict[str, str]]) -> str:
        if not history:
            return "(no previous turns)"
        lines = []
        for turn in history[-6:]:  # last 6 turns only
            role = turn.get("role", "user")
            content = turn.get("content", "")
            lines.append(f"[{role}] {content}")
        return "\n".join(lines)


# ============================================================
# CLI smoke test
# ============================================================
if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )

    rewriter = QueryRewriter(department="hr")

    test_queries = [
        "How many vacation days for managers?",
        "What is the maternity leave duration?",
        "What is the notice period for L5 employees?",
        "Can I work from home on Tuesdays?",
    ]

    for q in test_queries:
        print(f"\n{'=' * 60}")
        print(f"Q: {q}")
        print("=" * 60)
        result = rewriter.rewrite(q)
        print(f"Intent:     {result.intent}")
        print(f"Rewritten:  {result.rewritten_query}")
        print(f"Pattern:    {result.regex_pattern}")
        print(f"Synonyms:   {result.synonyms_used}")
        print(f"Tokens:     input={result.input_tokens} output={result.output_tokens} "
              f"cached={result.cached_input_tokens} cache_write={result.cache_creation_tokens}")