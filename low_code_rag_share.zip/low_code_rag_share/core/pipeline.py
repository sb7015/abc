"""
RAG Pipeline Orchestrator
==========================
Wires: Haiku (rewrite) -> AgentCore (grep) -> Sonnet (synthesize)
This is the runtime entry point for every user query.

Strict mode: any step failure raises QueryPipelineError.
"""
import sys
import time
import logging
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))

from config.settings import settings
from core.query_rewriter import QueryRewriter, QueryRewriteError, RewriteResult
from core.grep_engine import GrepEngine, GrepEngineError, GrepResult
from core.answer_synthesizer import AnswerSynthesizer, AnswerSynthesisError, SynthesisResult

logger = logging.getLogger(__name__)


@dataclass
class PipelineMetrics:
    """End-to-end metrics for one query."""
    rewrite_time_seconds: float = 0.0
    grep_time_seconds: float = 0.0
    synthesis_time_seconds: float = 0.0
    total_time_seconds: float = 0.0

    haiku_input_tokens: int = 0
    haiku_output_tokens: int = 0
    haiku_cached_tokens: int = 0
    haiku_cache_write_tokens: int = 0

    sonnet_input_tokens: int = 0
    sonnet_output_tokens: int = 0
    sonnet_cached_tokens: int = 0
    sonnet_cache_write_tokens: int = 0

    grep_total_matches: int = 0
    grep_returned_chunks: int = 0
    grep_output_tokens_estimate: int = 0

    estimated_cost_usd: float = 0.0


@dataclass
class PipelineResult:
    """Full result of one query."""
    answer: str
    intent: str
    rewritten_query: str
    sources_cited: List[str] = field(default_factory=list)
    matches_used: int = 0
    metrics: PipelineMetrics = field(default_factory=PipelineMetrics)


class QueryPipelineError(Exception):
    """Raised on any pipeline failure. Never caught for fallback."""
    pass


class RAGPipeline:
    """
    The runtime pipeline. Initialize once per department, call ask() per query.
    Components are reused across calls so prompt caching is effective.
    """

    def __init__(self, department: str):
        self.department = department.lower()
        try:
            self.rewriter = QueryRewriter(department=self.department)
            self.grep = GrepEngine(department=self.department)
            self.synthesizer = AnswerSynthesizer(department=self.department)
        except (QueryRewriteError, GrepEngineError, AnswerSynthesisError) as e:
            raise QueryPipelineError(
                f"Pipeline initialization failed: {e}"
            ) from e

        logger.info(f"RAGPipeline initialized for dept={self.department}")

    def ask(
        self,
        question: str,
        history: Optional[List[Dict[str, str]]] = None,
    ) -> PipelineResult:
        """
        Run the 6-step pipeline for a single query.
        Raises QueryPipelineError on any failure.
        """
        if not question or not question.strip():
            raise QueryPipelineError("Empty question")

        history = history or []
        metrics = PipelineMetrics()
        t_start = time.time()

        # Step 1+2: Haiku rewrites query + generates regex
        try:
            t0 = time.time()
            rewrite = self.rewriter.rewrite(question, history=history)
            metrics.rewrite_time_seconds = time.time() - t0
            metrics.haiku_input_tokens = rewrite.input_tokens
            metrics.haiku_output_tokens = rewrite.output_tokens
            metrics.haiku_cached_tokens = rewrite.cached_input_tokens
            metrics.haiku_cache_write_tokens = rewrite.cache_creation_tokens
        except QueryRewriteError as e:
            raise QueryPipelineError(f"Step 2 (Haiku rewrite) failed: {e}") from e

        logger.info(
            f"[1/3] Rewrite done | intent={rewrite.intent} "
            f"time={metrics.rewrite_time_seconds:.2f}s "
            f"tokens(in/out/cached/write)="
            f"{metrics.haiku_input_tokens}/{metrics.haiku_output_tokens}/"
            f"{metrics.haiku_cached_tokens}/{metrics.haiku_cache_write_tokens}"
        )

        # Step 3+4: AgentCore sandbox grep
        try:
            t0 = time.time()
            grep_result = self.grep.search(rewrite.regex_pattern)
            metrics.grep_time_seconds = time.time() - t0
            metrics.grep_total_matches = grep_result.total_matches_found
            metrics.grep_returned_chunks = grep_result.matches_returned
            metrics.grep_output_tokens_estimate = grep_result.total_output_tokens_estimate
        except GrepEngineError as e:
            raise QueryPipelineError(f"Step 3 (Grep sandbox) failed: {e}") from e

        logger.info(
            f"[2/3] Grep done | total={metrics.grep_total_matches} "
            f"returned={metrics.grep_returned_chunks} "
            f"output_tokens~={metrics.grep_output_tokens_estimate} "
            f"time={metrics.grep_time_seconds:.2f}s"
        )

        # Step 5: Sonnet synthesizes answer
        try:
            t0 = time.time()
            synth = self.synthesizer.synthesize(
                question=question,
                rewritten_query=rewrite.rewritten_query,
                intent=rewrite.intent,
                matches=grep_result.matches,
                total_found=grep_result.total_matches_found,
                history=history,
            )
            metrics.synthesis_time_seconds = time.time() - t0
            metrics.sonnet_input_tokens = synth.input_tokens
            metrics.sonnet_output_tokens = synth.output_tokens
            metrics.sonnet_cached_tokens = synth.cached_input_tokens
            metrics.sonnet_cache_write_tokens = synth.cache_creation_tokens
        except AnswerSynthesisError as e:
            raise QueryPipelineError(f"Step 5 (Sonnet synthesize) failed: {e}") from e

        metrics.total_time_seconds = time.time() - t_start
        metrics.estimated_cost_usd = self._estimate_cost(metrics)

        logger.info(
            f"[3/3] Synthesis done | output_tokens={metrics.sonnet_output_tokens} "
            f"cached={metrics.sonnet_cached_tokens} "
            f"write={metrics.sonnet_cache_write_tokens} "
            f"time={metrics.synthesis_time_seconds:.2f}s"
        )
        logger.info(
            f"PIPELINE DONE | total_time={metrics.total_time_seconds:.2f}s "
            f"cost~=${metrics.estimated_cost_usd:.5f}"
        )

        return PipelineResult(
            answer=synth.answer,
            intent=rewrite.intent,
            rewritten_query=rewrite.rewritten_query,
            sources_cited=synth.sources_cited,
            matches_used=metrics.grep_returned_chunks,
            metrics=metrics,
        )

    @staticmethod
    def _estimate_cost(m: PipelineMetrics) -> float:
        """Estimate USD cost using settings prices (per 1M tokens)."""
        s = settings
        haiku_cost = (
            (m.haiku_input_tokens / 1_000_000) * s.haiku_input_cost_per_1m
            + (m.haiku_output_tokens / 1_000_000) * s.haiku_output_cost_per_1m
            + (m.haiku_cached_tokens / 1_000_000) * s.haiku_cached_input_cost_per_1m
            + (m.haiku_cache_write_tokens / 1_000_000) * s.haiku_input_cost_per_1m * 1.25
        )
        sonnet_cost = (
            (m.sonnet_input_tokens / 1_000_000) * s.sonnet_input_cost_per_1m
            + (m.sonnet_output_tokens / 1_000_000) * s.sonnet_output_cost_per_1m
            + (m.sonnet_cached_tokens / 1_000_000) * s.sonnet_cached_input_cost_per_1m
            + (m.sonnet_cache_write_tokens / 1_000_000) * s.sonnet_input_cost_per_1m * 1.25
        )
        return round(haiku_cost + sonnet_cost, 6)


# ============================================================
# CLI smoke test
# ============================================================
if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )

    pipeline = RAGPipeline(department="hr")

    test_queries = [
        "How many vacation days for managers?",
        "What is the maternity leave duration?",
        "Can I work from home on Tuesdays?",
    ]

    for q in test_queries:
        print(f"\n{'=' * 70}")
        print(f"Q: {q}")
        print("=" * 70)
        result = pipeline.ask(q)
        print(f"\nINTENT: {result.intent}")
        print(f"REWRITTEN: {result.rewritten_query}")
        print(f"\nANSWER:\n{result.answer}")
        print(f"\nSources: {result.sources_cited} | Matches used: {result.matches_used}")
        m = result.metrics
        print(f"Latency: rewrite={m.rewrite_time_seconds:.2f}s "
              f"grep={m.grep_time_seconds:.2f}s "
              f"synth={m.synthesis_time_seconds:.2f}s "
              f"TOTAL={m.total_time_seconds:.2f}s")
        print(f"Cost: ~${m.estimated_cost_usd:.5f}")