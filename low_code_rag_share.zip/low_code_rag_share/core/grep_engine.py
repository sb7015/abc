"""
Grep Engine (AgentCore Code Interpreter)
=========================================
Loads hr.md from S3 into AgentCore sandbox, runs Python regex from Haiku,
returns matched chunks (~2K tokens max).

Strict mode: any failure raises. No fallback.
"""
import sys
import json
import logging
import re
from pathlib import Path
from typing import List, Optional
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))

import boto3
from botocore.exceptions import ClientError

from config.settings import settings
from storage.s3_manager import S3Manager

logger = logging.getLogger(__name__)


@dataclass
class GrepMatch:
    line_number: int
    chunk: str
    matched_terms: List[str]
    section: str = ""
    source_doc: str = ""


@dataclass
class GrepResult:
    matches: List[GrepMatch] = field(default_factory=list)
    total_matches_found: int = 0
    matches_returned: int = 0
    query_pattern: str = ""
    total_output_tokens_estimate: int = 0
    execution_time_seconds: float = 0.0


class GrepEngineError(Exception):
    """Raised when grep execution fails. Never caught for fallback."""
    pass


class GrepEngine:
    """
    Runs regex search on department .md inside AWS Bedrock AgentCore code interpreter.
    The .md file stays inside the sandbox (Lever 1).
    Only matched chunks (~2K tokens) leave the sandbox.
    """

    GREP_CODE_TEMPLATE = '''
import re
import json

# Read the knowledge base file (already loaded into sandbox at /tmp/kb.md)
with open("kb.md", "r", encoding="utf-8") as f:
    lines = f.readlines()

pattern = re.compile(r"""{pattern}""", re.IGNORECASE | re.MULTILINE)

# Find all matching line numbers
matches_raw = []
for i, line in enumerate(lines):
    if pattern.search(line):
        matches_raw.append(i)

total_found = len(matches_raw)

# Extract chunks: context_lines before/after, dedupe overlapping windows
context = {context_lines}
top_n = {top_n}
max_chunk_chars = {max_chunk_chars}

# Greedy chunk merging: combine matches within 2*context lines of each other
chunks = []
i = 0
while i < len(matches_raw):
    start = max(0, matches_raw[i] - context)
    end = min(len(lines), matches_raw[i] + context + 1)
    primary_line = matches_raw[i]
    # Merge subsequent matches into same chunk if within range
    j = i + 1
    while j < len(matches_raw) and matches_raw[j] < end:
        end = min(len(lines), matches_raw[j] + context + 1)
        j += 1
    chunk_text = "".join(lines[start:end])[:max_chunk_chars]

    # Find which terms in the pattern actually matched in this chunk
    matched_terms = sorted(set(m.group(0) for m in pattern.finditer(chunk_text)))

    # Find section header above (most recent ## or # line)
    section = ""
    for k in range(start, -1, -1):
        s = lines[k].strip()
        if s.startswith("#"):
            section = s.lstrip("#").strip()
            break

    # Find source doc marker (most recent <!-- source: ... -->)
    source = ""
    for k in range(start, -1, -1):
        s = lines[k].strip()
        if s.startswith("<!-- source:"):
            try:
                source = s.split("source:")[1].split("|")[0].strip()
            except Exception:
                pass
            break

    chunks.append({{
        "line_number": primary_line + 1,  # 1-indexed
        "chunk": chunk_text,
        "matched_terms": matched_terms,
        "section": section,
        "source_doc": source,
    }})
    i = j

# Cap to top_n
returned = chunks[:top_n]

result = {{
    "matches": returned,
    "total_matches_found": total_found,
    "matches_returned": len(returned),
    "query_pattern": r"""{pattern}"""
}}

print("__GREP_RESULT_START__")
print(json.dumps(result))
print("__GREP_RESULT_END__")
'''

    def __init__(
        self,
        department: str,
        region: Optional[str] = None,
        s3_manager: Optional[S3Manager] = None,
    ):
        self.department = department.lower()
        self.region = region or settings.aws_region
        self.s3 = s3_manager or S3Manager()
        self.sandbox_timeout = settings.agentcore_sandbox_timeout_seconds
        self._max_output_tokens = settings.agentcore_max_output_tokens

        # AgentCore runtime client
        self._agentcore = boto3.client("bedrock-agentcore", region_name=self.region)

        # Cache the kb content in memory across calls (re-read on every search to stay fresh)
        # Note: file is loaded INTO sandbox each call - this is the architectural contract
        logger.info(
            f"GrepEngine initialized | dept={self.department} region={self.region}"
        )

    def search(self, regex_pattern: str) -> GrepResult:
        """
        Run regex against hr.md inside AgentCore sandbox.
        Returns matched chunks (~2K tokens max).
        """
        import time
        start_time = time.time()

        if not regex_pattern or not regex_pattern.strip():
            # Empty pattern (e.g., OUT_OF_SCOPE intent) - return empty result, do not call sandbox
            logger.info("Empty regex pattern - skipping grep, returning empty result")
            return GrepResult(
                matches=[],
                total_matches_found=0,
                matches_returned=0,
                query_pattern="",
                execution_time_seconds=time.time() - start_time,
            )

        # Validate the pattern compiles in Python first (fail fast)
        try:
            re.compile(regex_pattern)
        except re.error as e:
            raise GrepEngineError(
                f"Invalid regex pattern from rewriter: {e} | pattern: {regex_pattern}"
            )

        # Download hr.md from S3 (sandbox needs the file uploaded)
        kb_content = self.s3.download_markdown(self.department)

        # Embed pattern directly inside r""" raw triple-quoted string in template.
        # Only escape `"""` if it appears literally in the pattern (rare).
        safe_pattern = regex_pattern.replace('"""', '\"\"\"')
        code = self.GREP_CODE_TEMPLATE.format(
            pattern=safe_pattern,
            context_lines=settings.grep_chunk_context_lines,
            top_n=settings.grep_top_n_chunks,
            max_chunk_chars=settings.grep_max_chunk_tokens * 4,  # ~4 chars/token
        )

        # Invoke AgentCore code interpreter
        try:
            output_text = self._invoke_sandbox(code, kb_content)
        except ClientError as e:
            raise GrepEngineError(
                f"AgentCore invocation failed: "
                f"{e.response['Error']['Code']}: {e.response['Error']['Message']}"
            ) from e

        # Parse the result from sandbox stdout
        result = self._parse_sandbox_output(output_text, regex_pattern)
        result.execution_time_seconds = time.time() - start_time
        result.total_output_tokens_estimate = sum(
            len(m.chunk) // 4 for m in result.matches
        )

        logger.info(
            f"Grep done | pattern_len={len(regex_pattern)} "
            f"total_found={result.total_matches_found} "
            f"returned={result.matches_returned} "
            f"output_tokens~={result.total_output_tokens_estimate} "
            f"time={result.execution_time_seconds:.2f}s"
        )
        return result

    def _invoke_sandbox(self, code: str, kb_content: str) -> str:
        """
        Invoke AgentCore code interpreter sandbox.
        Uploads kb_content as /tmp/kb.md, executes Python code, returns stdout.
        """
        # Start a code interpreter session
        session = self._agentcore.start_code_interpreter_session(
            codeInterpreterIdentifier="aws.codeinterpreter.v1",
            sessionTimeoutSeconds=self.sandbox_timeout,
        )
        session_id = session["sessionId"]

        try:
            # Upload kb.md to sandbox
            self._agentcore.invoke_code_interpreter(
                codeInterpreterIdentifier="aws.codeinterpreter.v1",
                sessionId=session_id,
                name="writeFiles",
                arguments={
                    "content": [
                        {
                            "path": "kb.md",
                            "text": kb_content,
                        }
                    ]
                },
            )

            # Execute the grep code
            response = self._agentcore.invoke_code_interpreter(
                codeInterpreterIdentifier="aws.codeinterpreter.v1",
                sessionId=session_id,
                name="executeCode",
                arguments={
                    "language": "python",
                    "code": code,
                },
            )

            # Drain the response stream
            output_chunks = []
            for event in response.get("stream", []):
                if "result" in event:
                    result = event["result"]
                    if "structuredContent" in result:
                        sc = result["structuredContent"]
                        if "stdout" in sc:
                            output_chunks.append(sc["stdout"])
                    if "content" in result:
                        for c in result["content"]:
                            if c.get("type") == "text":
                                output_chunks.append(c.get("text", ""))

            return "\n".join(output_chunks)
        finally:
            # Clean up session
            try:
                self._agentcore.stop_code_interpreter_session(
                    codeInterpreterIdentifier="aws.codeinterpreter.v1",
                    sessionId=session_id,
                )
            except Exception as e:
                logger.warning(f"Failed to stop sandbox session {session_id}: {e}")

    def _parse_sandbox_output(self, output: str, pattern: str) -> GrepResult:
        """Extract JSON result between markers in sandbox stdout."""
        START = "__GREP_RESULT_START__"
        END = "__GREP_RESULT_END__"
        if START not in output or END not in output:
            raise GrepEngineError(
                f"Sandbox did not produce result markers. Output: {output[:500]}"
            )
        json_str = output.split(START, 1)[1].split(END, 1)[0].strip()

        try:
            data = json.loads(json_str)
        except json.JSONDecodeError as e:
            raise GrepEngineError(
                f"Sandbox output JSON invalid: {e} | raw: {json_str[:300]}"
            )

        matches = [
            GrepMatch(
                line_number=m["line_number"],
                chunk=m["chunk"],
                matched_terms=m.get("matched_terms", []),
                section=m.get("section", ""),
                source_doc=m.get("source_doc", ""),
            )
            for m in data.get("matches", [])
        ]
        return GrepResult(
            matches=matches,
            total_matches_found=data.get("total_matches_found", 0),
            matches_returned=data.get("matches_returned", 0),
            query_pattern=pattern,
        )


# ============================================================
# CLI smoke test
# ============================================================
if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )

    engine = GrepEngine(department="hr")

    test_patterns = [
        # Vacation for managers
        r"\b(vacation|leave|PTO|annual leave)\b.*\b(manager|L5|L6)\b|\b(manager|L5|L6)\b.*\b(vacation|leave|PTO|annual leave)\b",
        # Maternity duration
        r"\b(maternity|pregnancy)\b.*\b(weeks|months|duration)\b|\b(weeks|months|duration)\b.*\b(maternity|pregnancy)\b",
    ]

    for pattern in test_patterns:
        print(f"\n{'=' * 60}")
        print(f"Pattern: {pattern[:80]}...")
        print("=" * 60)
        result = engine.search(pattern)
        print(f"Total found: {result.total_matches_found}")
        print(f"Returned:    {result.matches_returned}")
        print(f"Output tokens (est): {result.total_output_tokens_estimate}")
        print(f"Time: {result.execution_time_seconds:.2f}s")
        for i, m in enumerate(result.matches, 1):
            print(f"\n--- Match {i} (line {m.line_number}, section: {m.section}) ---")
            print(f"Terms: {m.matched_terms}")
            print(f"Chunk preview: {m.chunk[:300]}...")