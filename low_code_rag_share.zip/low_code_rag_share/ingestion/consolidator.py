"""
Consolidator
============
Merges ExtractionResults from multiple PDFs into one .md per department,
uploads to S3 as the canonical knowledge base.

Strict mode: any failure in input -> raise. No partial consolidation.
"""
import sys
import logging
from pathlib import Path
from typing import List
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).parent.parent))

from config.settings import settings
from storage.s3_manager import S3Manager
from ingestion.bda_extractor import ExtractionResult

logger = logging.getLogger(__name__)


class ConsolidationError(Exception):
    """Raised when consolidation fails. Never caught for fallback."""
    pass


class Consolidator:
    """Merges per-PDF extractions into one departmental .md and uploads to S3."""

    def __init__(self, s3_manager: S3Manager = None):
        self.s3 = s3_manager or S3Manager()

    def consolidate(
        self,
        department: str,
        results: List[ExtractionResult],
    ) -> str:
        """
        Merge results -> single markdown -> upload to S3.
        Returns S3 URI of the uploaded .md.
        """
        if not results:
            raise ConsolidationError(
                f"No extraction results provided for '{department}'"
            )

        # Validate all extractions succeeded - no partial KB
        failed = [r for r in results if r.status not in ("SUCCESS", "CACHED")]
        if failed:
            names = ", ".join(r.pdf_filename for r in failed)
            raise ConsolidationError(
                f"Cannot consolidate - {len(failed)} extraction(s) not successful: "
                f"{names}"
            )

        # Build the consolidated document
        doc = self._build_markdown(department, results)

        # Upload to S3
        metadata = {
            "department": department.lower(),
            "source_pdf_count": str(len(results)),
            "total_pages": str(sum(r.page_count for r in results)),
            "consolidation_timestamp": datetime.now(timezone.utc).isoformat(),
        }
        uri = self.s3.upload_markdown(department, doc, metadata=metadata)
        logger.info(
            f"Consolidated KB uploaded | dept={department} "
            f"sources={len(results)} chars={len(doc)} uri={uri}"
        )
        return uri

    def _build_markdown(
        self, department: str, results: List[ExtractionResult]
    ) -> str:
        """Assemble the final hr.md with header + per-PDF sections."""
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        total_pages = sum(r.page_count for r in results)

        # Document header / table of contents
        parts = [
            f"# {department.upper()} Department Knowledge Base",
            "",
            f"**Generated:** {ts}",
            f"**Source PDFs:** {len(results)}",
            f"**Total Pages:** {total_pages}",
            "",
            "## Source Documents",
            "",
        ]
        for i, r in enumerate(results, 1):
            parts.append(
                f"{i}. **{r.pdf_filename}** "
                f"(SHA256: `{r.pdf_sha256[:16]}...`, {r.page_count} pages)"
            )
        parts.extend(["", "---", ""])

        # Per-PDF content with clear separators for citation
        for i, r in enumerate(results, 1):
            parts.extend([
                f"# [DOC {i}] {r.pdf_filename}",
                "",
                f"<!-- source: {r.pdf_filename} | sha256: {r.pdf_sha256} -->",
                "",
                r.markdown_content.strip(),
                "",
                "---",
                "",
            ])

        return "\n".join(parts)


# ============================================================
# CLI smoke test
# ============================================================
if __name__ == "__main__":
    import sys
    from ingestion.bda_extractor import BDAExtractor

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )

    if len(sys.argv) < 3:
        print("Usage: python ingestion/consolidator.py <dept> <pdf1> [pdf2] ...")
        sys.exit(1)

    dept = sys.argv[1]
    pdfs = sys.argv[2:]

    print(f"Extracting {len(pdfs)} PDFs for '{dept}' in parallel...")
    extractor = BDAExtractor()
    results = extractor.extract_pdfs_parallel(pdfs, dept)

    print(f"\nConsolidating into {dept}.md...")
    consolidator = Consolidator()
    uri = consolidator.consolidate(dept, results)

    print(f"\n[DONE] {uri}")