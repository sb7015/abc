"""
Bedrock Data Automation (BDA) Extractor
========================================
Handles PDF -> markdown extraction using AWS Bedrock Data Automation.

Key features:
  - Parallel async invocation (multiple PDFs processed simultaneously)
  - Hash-based caching (skip re-extraction if PDF unchanged)
  - Strict failure mode (NO fallback - errors propagate up)
  - Audit trail (raw BDA outputs persisted in S3)

Flow per PDF:
  1. Compute SHA256 of PDF
  2. Check cache (S3) - if hit, download cached .md and return
  3. Upload PDF to S3
  4. Invoke BDA InvokeDataAutomationAsync
  5. Poll for completion
  6. Download BDA output, parse markdown
  7. Cache the result for future runs
  8. Return ExtractionResult

This module is called once per PDF during ingestion (offline, batch).
At runtime it is NOT used - only the consolidated .md in S3 is read.
"""
import sys
import time
import uuid
import json
import hashlib
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, str(Path(__file__).parent.parent))

import boto3
from botocore.exceptions import ClientError

from config.settings import settings
from storage.s3_manager import S3Manager

logger = logging.getLogger(__name__)


# ============================================================
# Data classes
# ============================================================
@dataclass
class ExtractionResult:
    """Result of a single PDF extraction via BDA."""
    pdf_filename: str
    pdf_sha256: str
    pdf_s3_uri: str
    bda_job_id: str
    bda_invocation_arn: Optional[str]
    status: str  # SUCCESS / CACHED / FAILED / TIMEOUT
    markdown_content: str = ""
    page_count: int = 0
    extraction_time_seconds: float = 0.0
    cache_hit: bool = False
    error_message: Optional[str] = None
    raw_output_keys: List[str] = field(default_factory=list)


class BDAExtractionError(Exception):
    """Raised when BDA extraction fails. NEVER caught for fallback."""
    pass


# ============================================================
# BDA Extractor
# ============================================================
class BDAExtractor:
    """
    Extracts text + tables + structure from PDFs using Bedrock Data Automation.

    No fallback mechanisms. If BDA fails, the exception propagates.
    Production team must investigate root cause - silent degradation is forbidden.
    """

    def __init__(
        self,
        project_arn: Optional[str] = None,
        region: Optional[str] = None,
        s3_manager: Optional[S3Manager] = None,
        poll_interval_seconds: int = 5,
        timeout_seconds: int = 300,
        cache_enabled: bool = True,
    ):
        self.project_arn = project_arn or settings.bda_project_arn
        self.region = region or settings.aws_region
        self.s3 = s3_manager or S3Manager()
        self.poll_interval = poll_interval_seconds
        self.timeout = timeout_seconds
        self.cache_enabled = cache_enabled

        if not self.project_arn:
            raise BDAExtractionError(
                "BDA_PROJECT_ARN not configured - run setup_aws.py first"
            )

        self._runtime_client = boto3.client(
            "bedrock-data-automation-runtime", region_name=self.region
        )
        self._account_id = settings.aws_account_id

        logger.info(
            f"BDAExtractor initialized | project_arn={self.project_arn} "
            f"region={self.region} cache_enabled={cache_enabled}"
        )

    # ============================================================
    # Cache helpers
    # ============================================================
    @staticmethod
    def _compute_sha256(file_path: Path) -> str:
        """Compute SHA256 hash of a file."""
        sha = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha.update(chunk)
        return sha.hexdigest()

    def _cache_key(self, department: str, pdf_sha256: str) -> str:
        """S3 key for cached extraction result."""
        return (
            f"{self.s3.kb_prefix}_cache/{department.lower()}/"
            f"{pdf_sha256}.md"
        )

    def _check_cache(self, department: str, pdf_sha256: str) -> Optional[str]:
        """Check if extraction is cached. Return cached markdown or None."""
        if not self.cache_enabled:
            return None
        cache_key = self._cache_key(department, pdf_sha256)
        try:
            content = self.s3.download_text(cache_key)
            logger.info(f"  Cache HIT: {cache_key}")
            return content
        except Exception:
            logger.info(f"  Cache MISS: {cache_key}")
            return None

    def _write_cache(
        self, department: str, pdf_sha256: str, markdown: str
    ) -> None:
        """Write extracted markdown to cache."""
        if not self.cache_enabled:
            return
        cache_key = self._cache_key(department, pdf_sha256)
        try:
            self.s3._client.put_object(
                Bucket=self.s3.bucket_name,
                Key=cache_key,
                Body=markdown.encode("utf-8"),
                ContentType="text/markdown; charset=utf-8",
            )
            logger.info(f"  Cache WRITE: {cache_key}")
        except Exception as e:
            # Cache write failure is non-fatal but logged loudly
            logger.error(f"  Cache WRITE FAILED (non-fatal): {e}")

    # ============================================================
    # Public API: single PDF
    # ============================================================
    def extract_pdf(self, pdf_path: str, department: str) -> ExtractionResult:
        """
        Extract markdown from a single PDF. Strict failure mode - no fallback.
        Raises BDAExtractionError on any failure.
        """
        pdf_path_obj = Path(pdf_path)
        if not pdf_path_obj.exists():
            raise BDAExtractionError(f"PDF not found: {pdf_path}")
        if pdf_path_obj.suffix.lower() != ".pdf":
            raise BDAExtractionError(f"Not a PDF file: {pdf_path}")

        filename = pdf_path_obj.name
        start_time = time.time()

        # Step 1: Hash the PDF
        pdf_sha256 = self._compute_sha256(pdf_path_obj)
        logger.info(f"Extracting: {filename} (sha256={pdf_sha256[:12]}...)")

        # Step 2: Check cache
        cached_md = self._check_cache(department, pdf_sha256)
        if cached_md is not None:
            return ExtractionResult(
                pdf_filename=filename,
                pdf_sha256=pdf_sha256,
                pdf_s3_uri="(cached)",
                bda_job_id="(cached)",
                bda_invocation_arn=None,
                status="CACHED",
                markdown_content=cached_md,
                page_count=cached_md.count("\f") + 1,  # rough page count
                extraction_time_seconds=time.time() - start_time,
                cache_hit=True,
            )

        # Step 3: Upload PDF to S3
        pdf_s3_uri = self.s3.upload_raw_pdf(department, filename, str(pdf_path_obj))
        logger.info(f"  PDF uploaded: {pdf_s3_uri}")

        # Step 4: Invoke BDA async
        job_id = f"job-{uuid.uuid4().hex[:12]}"
        output_uri = self.s3.get_bda_output_uri(department, job_id)
        invocation_arn = self._invoke_bda(pdf_s3_uri, output_uri)
        logger.info(f"  BDA invoked: {invocation_arn}")

        # Step 5: Poll for completion (raises on timeout/failure)
        self._poll_until_done(invocation_arn)

        # Step 6: Download BDA output and parse markdown
        markdown, page_count, output_keys = self._read_bda_output(
            department, job_id
        )

        # Step 7: Cache the result
        self._write_cache(department, pdf_sha256, markdown)

        return ExtractionResult(
            pdf_filename=filename,
            pdf_sha256=pdf_sha256,
            pdf_s3_uri=pdf_s3_uri,
            bda_job_id=job_id,
            bda_invocation_arn=invocation_arn,
            status="SUCCESS",
            markdown_content=markdown,
            page_count=page_count,
            extraction_time_seconds=time.time() - start_time,
            cache_hit=False,
            raw_output_keys=output_keys,
        )

    # ============================================================
    # Public API: parallel batch
    # ============================================================
    def extract_pdfs_parallel(
        self,
        pdf_paths: List[str],
        department: str,
        max_workers: int = 5,
    ) -> List[ExtractionResult]:
        """
        Extract multiple PDFs in parallel using ThreadPoolExecutor.
        BDA's regional concurrency limit is 25 in us-east-1.
        Strict mode: if ANY PDF fails, raise the first exception encountered.
        """
        if not pdf_paths:
            return []

        logger.info(
            f"Starting parallel extraction of {len(pdf_paths)} PDF(s) "
            f"with {max_workers} workers"
        )

        results: List[ExtractionResult] = []
        errors: List[tuple] = []

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_pdf = {
                executor.submit(self.extract_pdf, pdf, department): pdf
                for pdf in pdf_paths
            }
            for future in as_completed(future_to_pdf):
                pdf = future_to_pdf[future]
                try:
                    result = future.result()
                    results.append(result)
                    cache_str = " (CACHED)" if result.cache_hit else ""
                    logger.info(
                        f"  [DONE] {result.pdf_filename}{cache_str} "
                        f"- {result.page_count} pages, "
                        f"{result.extraction_time_seconds:.1f}s"
                    )
                except Exception as e:
                    logger.error(f"  [FAIL] {pdf}: {e}")
                    errors.append((pdf, e))

        # Strict mode: if any failed, raise immediately - no partial success
        if errors:
            failed_files = ", ".join(Path(p).name for p, _ in errors)
            first_error = errors[0][1]
            raise BDAExtractionError(
                f"BDA extraction failed for {len(errors)}/{len(pdf_paths)} PDFs: "
                f"{failed_files}. First error: {first_error}"
            )

        # Sort results to keep deterministic order (alphabetical by filename)
        results.sort(key=lambda r: r.pdf_filename)
        return results

    # ============================================================
    # Internal: BDA invocation
    # ============================================================
    def _invoke_bda(self, input_s3_uri: str, output_s3_uri: str) -> str:
        """Invoke BDA async job. Returns invocation ARN. Raises on failure."""
        try:
            response = self._runtime_client.invoke_data_automation_async(
                inputConfiguration={"s3Uri": input_s3_uri},
                outputConfiguration={"s3Uri": output_s3_uri},
                dataAutomationConfiguration={
                    "dataAutomationProjectArn": self.project_arn,
                    "stage": "LIVE",
                },
                dataAutomationProfileArn=(
                    f"arn:aws:bedrock:{self.region}:{self._account_id}:"
                    f"data-automation-profile/us.data-automation-v1"
                ),
            )
            return response["invocationArn"]
        except ClientError as e:
            raise BDAExtractionError(
                f"BDA invocation failed: {e.response['Error']['Code']}: "
                f"{e.response['Error']['Message']}"
            ) from e

    def _poll_until_done(self, invocation_arn: str) -> None:
        """Poll BDA job status until terminal state. Raises on failure or timeout."""
        elapsed = 0
        while elapsed < self.timeout:
            try:
                response = self._runtime_client.get_data_automation_status(
                    invocationArn=invocation_arn
                )
                status = response.get("status", "Unknown")
                logger.debug(f"  BDA status: {status} (elapsed: {elapsed}s)")

                if status == "Success":
                    return
                if status in ("ServiceError", "ClientError"):
                    err_msg = response.get("errorMessage", f"BDA returned {status}")
                    raise BDAExtractionError(
                        f"BDA job {invocation_arn} failed with status "
                        f"'{status}': {err_msg}"
                    )
                # Otherwise: InProgress / Created - keep polling
            except ClientError as e:
                # Status-poll error is fatal - no silent retry
                raise BDAExtractionError(
                    f"BDA status poll error: {e.response['Error']['Message']}"
                ) from e

            time.sleep(self.poll_interval)
            elapsed += self.poll_interval

        raise BDAExtractionError(
            f"BDA job {invocation_arn} did not complete within {self.timeout}s"
        )

    # ============================================================
    # Internal: Read BDA output from S3 and assemble markdown
    # ============================================================
    def _read_bda_output(
        self, department: str, job_id: str
    ) -> tuple[str, int, list]:
        """
        Read BDA's standard_output JSON from S3 and extract markdown.
        BDA writes to: <output_uri>/<asset_id>/standard_output/0/result.json
        """
        keys = self.s3.list_bda_outputs(department, job_id)
        if not keys:
            raise BDAExtractionError(
                f"No BDA output files found for job {job_id} - "
                f"check BDA permissions and output S3 prefix"
            )

        logger.info(f"  Found {len(keys)} BDA output file(s)")

        # Locate result.json files (one per asset/document)
        result_keys = sorted([k for k in keys if k.endswith("result.json")])
        if not result_keys:
            raise BDAExtractionError(
                f"BDA produced output but no result.json found. "
                f"Keys: {keys[:5]}"
            )

        markdown_parts = []
        total_pages = 0

        for result_key in result_keys:
            raw = self.s3.download_text(result_key)
            data = json.loads(raw)

            # Document-level markdown (preferred)
            doc = data.get("document", {})
            rep = doc.get("representation", {})
            md = rep.get("markdown", "") or rep.get("text", "")

            pages = data.get("pages", [])
            total_pages += len(pages)

            if md:
                markdown_parts.append(md)
            elif pages:
                # Build from page-level markdown
                page_mds = []
                for page in pages:
                    page_rep = page.get("representation", {})
                    page_md = (
                        page_rep.get("markdown", "")
                        or page_rep.get("text", "")
                    )
                    if page_md:
                        page_mds.append(page_md)
                if not page_mds:
                    raise BDAExtractionError(
                        f"BDA result.json {result_key} contained no extractable "
                        f"markdown or page text"
                    )
                markdown_parts.append("\n\n".join(page_mds))
            else:
                raise BDAExtractionError(
                    f"BDA result.json {result_key} has no document or page content"
                )

        if not markdown_parts:
            raise BDAExtractionError(
                f"BDA output parsed but assembled markdown is empty"
            )

        combined = "\n\n".join(markdown_parts)
        logger.info(
            f"  Extracted {len(combined)} chars from {total_pages} page(s)"
        )
        return combined, total_pages, keys


# ============================================================
# CLI test harness
# ============================================================
if __name__ == "__main__":
    import sys

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )

    if len(sys.argv) < 3:
        print("Usage:")
        print("  Single PDF:    python ingestion/bda_extractor.py <pdf_path> <dept>")
        print("  Multiple PDFs: python ingestion/bda_extractor.py --parallel <dept> <pdf1> <pdf2> ...")
        sys.exit(1)

    extractor = BDAExtractor()

    if sys.argv[1] == "--parallel":
        department = sys.argv[2]
        pdf_paths = sys.argv[3:]
        print(f"Parallel extraction of {len(pdf_paths)} PDFs for dept '{department}'")
        results = extractor.extract_pdfs_parallel(pdf_paths, department)
        print("\n--- Results ---")
        for r in results:
            print(f"  {r.pdf_filename}: {r.status} | {r.page_count} pages | "
                  f"{r.extraction_time_seconds:.1f}s | "
                  f"{len(r.markdown_content)} chars | cached={r.cache_hit}")
    else:
        pdf_path = sys.argv[1]
        department = sys.argv[2]
        print(f"Single PDF extraction: {pdf_path} (dept={department})")
        result = extractor.extract_pdf(pdf_path, department)
        print(f"\n--- Result ---")
        print(f"Status:           {result.status}")
        print(f"Cache hit:        {result.cache_hit}")
        print(f"PDF SHA256:       {result.pdf_sha256[:16]}...")
        print(f"Pages extracted:  {result.page_count}")
        print(f"Markdown chars:   {len(result.markdown_content)}")
        print(f"Time taken:       {result.extraction_time_seconds:.1f}s")
        print(f"\n--- First 1500 chars ---")
        print(result.markdown_content[:1500])
        if len(result.markdown_content) > 1500:
            print(f"\n... ({len(result.markdown_content) - 1500} more chars)")