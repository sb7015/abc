"""
Ingestion CLI
=============
python -m ingestion.cli --dept hr --pdf-folder ./sample_pdfs/hr/
"""
import sys
import logging
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from ingestion.bda_extractor import BDAExtractor
from ingestion.consolidator import Consolidator


def main():
    parser = argparse.ArgumentParser(description="Ingest PDFs into departmental KB")
    parser.add_argument("--dept", required=True, help="Department (e.g., hr)")
    parser.add_argument("--pdf-folder", required=True, help="Folder containing PDFs")
    parser.add_argument("--no-cache", action="store_true", help="Disable extraction cache")
    parser.add_argument("--workers", type=int, default=5, help="Parallel workers (max 25)")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )

    folder = Path(args.pdf_folder)
    if not folder.exists() or not folder.is_dir():
        print(f"ERROR: folder not found: {folder}")
        sys.exit(1)

    pdfs = sorted(folder.glob("*.pdf"))
    if not pdfs:
        print(f"ERROR: no .pdf files in {folder}")
        sys.exit(1)

    print(f"Department: {args.dept}")
    print(f"PDFs found: {len(pdfs)}")
    for p in pdfs:
        print(f"  - {p.name}")

    extractor = BDAExtractor(cache_enabled=not args.no_cache)
    results = extractor.extract_pdfs_parallel(
        [str(p) for p in pdfs], args.dept, max_workers=args.workers
    )

    consolidator = Consolidator()
    uri = consolidator.consolidate(args.dept, results)

    total_pages = sum(r.page_count for r in results)
    total_chars = sum(len(r.markdown_content) for r in results)
    cached = sum(1 for r in results if r.cache_hit)

    print("\n" + "=" * 60)
    print("INGESTION COMPLETE")
    print("=" * 60)
    print(f"PDFs processed:  {len(results)} ({cached} from cache)")
    print(f"Total pages:     {total_pages}")
    print(f"Total chars:     {total_chars}")
    print(f"KB uploaded to:  {uri}")


if __name__ == "__main__":
    main()