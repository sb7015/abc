# Low-Code RAG — HR Department PoC

A lightweight RAG implementation for low-complexity, factual Q&A on departmental PDFs.
No vector DB. No embeddings. No agent orchestration.

Architecture: PDF → BDA → consolidated .md → S3 → AgentCore Code Interpreter (grep) → Haiku (rewrite) + Sonnet (synthesis).

## Architecture Overview

ONE-TIME INGESTION (per department):
HR PDFs → Bedrock BDA → hr.md → S3

RUNTIME QUERY FLOW (per user question):
Question → Haiku (rewrite + grep code) → AgentCore Code Interpreter (grep on hr.md) → Matched chunks (~2K tokens) → Sonnet (synthesize cited answer) → Response

## Cost Optimization Levers

1. Grep output only — .md stays inside sandbox; only matched chunks (~2K tokens) reach LLM
2. Prompt caching — system prompts + skills.md cached after first call (~10% rate)
3. Haiku + Sonnet split — Haiku (12x cheaper) for query rewriting; Sonnet only for final synthesis

Net impact: ~$3.75 to ~$0.005 per query (99.9% reduction).

## Quick Start

### 1. Setup environment

    python -m venv venv
    venv\Scripts\activate
    pip install -r requirements.txt
    copy .env.template .env

Then edit .env with your AWS details.

### 2. Bootstrap AWS resources (one-time)

    python setup_aws.py

### 3. Ingest HR PDFs (one-time per department)

    python -m ingestion.cli --dept hr --pdf-folder .\sample_pdfs\hr\

### 4. Start the API

    uvicorn api.main:app --host 0.0.0.0 --port 8000 --reload

### 5. Query the API

    curl -X POST http://localhost:8000/v1/query -H "Content-Type: application/json" -d "{\"department\":\"hr\",\"question\":\"How many vacation days for managers?\"}"

## API Endpoints

| Method | Endpoint           | Purpose                                |
|--------|--------------------|----------------------------------------|
| POST   | /v1/query          | Submit a question, get cited answer    |
| POST   | /v1/query/stream   | SSE streaming version for chat UIs     |
| GET    | /v1/departments    | List available departments             |
| GET    | /v1/health         | Health check (for load balancers)      |
| GET    | /v1/metrics        | Prometheus metrics (for load tests)    |

Full OpenAPI docs available at: http://localhost:8000/docs

## Project Structure

    low_code_rag/
    ├── setup_aws.py              # Bootstrap S3 + BDA
    ├── ingestion/                # One-time PDF to .md to S3 pipeline
    ├── api/                      # FastAPI runtime (REST endpoints)
    ├── core/                     # Business logic (rewrite, grep, synthesize)
    ├── config/                   # Settings + skills.md per department
    ├── storage/                  # S3 wrapper
    ├── observability/            # Logging + metrics
    ├── tests/                    # Unit, integration, load tests
    └── docs/                     # Architecture, API, deployment docs

## Use-Case Gating (When NOT to Use This)

This setup is suitable ONLY for:

- Factual Q&A (not analytical or generative)
- Single-department queries (no cross-document synthesis)
- Small corpus (<10 MB per department .md file)
- Low-complexity retrieval (no semantic mismatch concerns)

For semantic search, multi-step reasoning, or cross-department queries, route to full RAG with embeddings.

## Technology Stack

- AWS Bedrock — Claude Haiku 4.5 + Claude Sonnet 4
- AWS Bedrock Data Automation (BDA) — PDF text/table extraction
- AWS Bedrock AgentCore — Sandboxed code interpreter for grep
- Amazon S3 — Markdown knowledge base storage
- FastAPI — REST API runtime
- Pydantic — Configuration and request/response validation
- Structlog — Structured JSON logging
- Prometheus — Metrics for load testing
- Locust — Load testing framework

## License

Internal PoC — Not for distribution.