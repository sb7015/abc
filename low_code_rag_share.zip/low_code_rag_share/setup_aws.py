"""
AWS Infrastructure Bootstrap
============================
One-time setup script that provisions all AWS resources required by the
Low-Code RAG pipeline. Idempotent — safe to re-run.

Resources created:
  1. S3 bucket for knowledge base storage
  2. Bedrock Data Automation (BDA) project for PDF extraction
  3. Updates .env file with resource ARNs

Run: python setup_aws.py

The production team can use this script as a reference to translate into
Terraform, CloudFormation, or CDK in their preferred IaC style.
"""
import os
import sys
import json
import time
from pathlib import Path
import boto3
from botocore.exceptions import ClientError

# Add project root to path so we can import config
sys.path.insert(0, str(Path(__file__).parent))
from config.settings import settings


# ANSI colors
class C:
    OK = '\033[92m'
    WARN = '\033[93m'
    FAIL = '\033[91m'
    INFO = '\033[94m'
    BOLD = '\033[1m'
    END = '\033[0m'


def log_info(msg):
    print(f"{C.INFO}[INFO]{C.END} {msg}")


def log_ok(msg):
    print(f"{C.OK}[ OK ]{C.END} {msg}")


def log_warn(msg):
    print(f"{C.WARN}[WARN]{C.END} {msg}")


def log_fail(msg):
    print(f"{C.FAIL}[FAIL]{C.END} {msg}")


def section(title):
    print(f"\n{C.BOLD}{'=' * 65}{C.END}")
    print(f"{C.BOLD}{title}{C.END}")
    print(f"{C.BOLD}{'=' * 65}{C.END}")


# ============================================================
# Step 1: Create S3 Bucket
# ============================================================
def create_s3_bucket(bucket_name: str, region: str) -> bool:
    """Create S3 bucket idempotently. Returns True if created or already exists."""
    section("Step 1: S3 Bucket")
    s3 = boto3.client("s3", region_name=region)

    # Check if bucket already exists
    try:
        s3.head_bucket(Bucket=bucket_name)
        log_ok(f"S3 bucket already exists: {bucket_name}")
        return True
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == '404':
            log_info(f"Bucket does not exist, creating: {bucket_name}")
        elif error_code == '403':
            log_fail(f"Bucket exists but you don't have access: {bucket_name}")
            log_warn("Choose a different bucket name in .env (S3_BUCKET_NAME)")
            return False
        else:
            log_fail(f"Unexpected error checking bucket: {error_code}")
            return False

    # Create the bucket
    try:
        if region == "us-east-1":
            # us-east-1 doesn't accept LocationConstraint
            s3.create_bucket(Bucket=bucket_name)
        else:
            s3.create_bucket(
                Bucket=bucket_name,
                CreateBucketConfiguration={'LocationConstraint': region}
            )
        log_ok(f"Created S3 bucket: {bucket_name}")

        # Enable versioning (best practice for knowledge base)
        s3.put_bucket_versioning(
            Bucket=bucket_name,
            VersioningConfiguration={'Status': 'Enabled'}
        )
        log_ok("Enabled versioning on bucket")

        # Block public access (security best practice)
        s3.put_public_access_block(
            Bucket=bucket_name,
            PublicAccessBlockConfiguration={
                'BlockPublicAcls': True,
                'IgnorePublicAcls': True,
                'BlockPublicPolicy': True,
                'RestrictPublicBuckets': True
            }
        )
        log_ok("Blocked public access on bucket")

        # Enable default encryption (AES256)
        s3.put_bucket_encryption(
            Bucket=bucket_name,
            ServerSideEncryptionConfiguration={
                'Rules': [{
                    'ApplyServerSideEncryptionByDefault': {
                        'SSEAlgorithm': 'AES256'
                    }
                }]
            }
        )
        log_ok("Enabled AES256 encryption on bucket")

        return True
    except ClientError as e:
        log_fail(f"Failed to create bucket: {e.response['Error']['Message']}")
        return False


# ============================================================
# Step 2: Create BDA Project
# ============================================================
def create_bda_project(project_name: str, region: str) -> str | None:
    """Create BDA project idempotently. Returns project ARN."""
    section("Step 2: Bedrock Data Automation (BDA) Project")
    try:
        bda = boto3.client("bedrock-data-automation", region_name=region)
    except Exception as e:
        log_fail(f"Cannot create BDA client: {e}")
        log_warn("Upgrade boto3: pip install --upgrade boto3")
        return None

    # Check if project already exists
    try:
        existing = bda.list_data_automation_projects()
        for proj in existing.get('projects', []):
            if proj.get('projectName') == project_name:
                arn = proj.get('projectArn')
                log_ok(f"BDA project already exists: {project_name}")
                log_info(f"  ARN: {arn}")
                return arn
    except ClientError as e:
        log_warn(f"Could not list existing projects: {e.response['Error']['Message']}")

    # Create the project
    try:
        log_info(f"Creating BDA project: {project_name}")
        response = bda.create_data_automation_project(
            projectName=project_name,
            projectDescription="Low-Code RAG - Document extraction for departmental PDFs",
            projectStage="LIVE",
            standardOutputConfiguration={
                'document': {
                    'extraction': {
                        'granularity': {
                            'types': ['DOCUMENT', 'PAGE', 'ELEMENT']
                        },
                        'boundingBox': {
                            'state': 'ENABLED'
                        }
                    },
                    'generativeField': {
                        'state': 'DISABLED'  # We don't need AI summaries; we want raw text
                    },
                    'outputFormat': {
                        'textFormat': {
                            'types': ['MARKDOWN']  # Markdown is what our pipeline needs
                        },
                        'additionalFileFormat': {
                            'state': 'DISABLED'
                        }
                    }
                }
            }
        )
        arn = response.get('projectArn')
        log_ok(f"Created BDA project: {project_name}")
        log_info(f"  ARN: {arn}")

        # Wait briefly for project to become ACTIVE
        log_info("Waiting for project to become ACTIVE...")
        for attempt in range(10):
            time.sleep(3)
            try:
                proj_detail = bda.get_data_automation_project(projectArn=arn)
                status = proj_detail.get('project', {}).get('status', 'UNKNOWN')
                if status == 'COMPLETED' or status == 'ACTIVE':
                    log_ok(f"Project status: {status}")
                    break
                log_info(f"  Status: {status} (attempt {attempt + 1}/10)")
            except ClientError as e:
                log_warn(f"Status check failed: {e.response['Error']['Message']}")
                break

        return arn
    except ClientError as e:
        log_fail(f"Failed to create BDA project: {e.response['Error']['Code']}: {e.response['Error']['Message']}")
        return None


# ============================================================
# Step 3: Update .env file with resource ARNs
# ============================================================
def update_env_file(bucket_name: str, bda_arn: str | None) -> bool:
    """Update .env file with newly created resource identifiers."""
    section("Step 3: Update .env File")
    env_path = Path(".env")
    if not env_path.exists():
        log_fail(".env file not found — copy .env.template first")
        return False

    lines = env_path.read_text(encoding="utf-8").splitlines()
    updated_lines = []
    bucket_set = False
    bda_set = False

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("S3_BUCKET_NAME="):
            updated_lines.append(f"S3_BUCKET_NAME={bucket_name}")
            bucket_set = True
        elif stripped.startswith("BDA_PROJECT_ARN="):
            if bda_arn:
                updated_lines.append(f"BDA_PROJECT_ARN={bda_arn}")
                bda_set = True
            else:
                updated_lines.append(line)  # Keep as-is if BDA failed
        else:
            updated_lines.append(line)

    # Append if missing
    if not bucket_set:
        updated_lines.append(f"S3_BUCKET_NAME={bucket_name}")
    if not bda_set and bda_arn:
        updated_lines.append(f"BDA_PROJECT_ARN={bda_arn}")

    env_path.write_text("\n".join(updated_lines) + "\n", encoding="utf-8")
    log_ok(f"Updated .env: S3_BUCKET_NAME={bucket_name}")
    if bda_arn:
        log_ok(f"Updated .env: BDA_PROJECT_ARN={bda_arn}")
    return True


# ============================================================
# Step 4: Verify resources end-to-end
# ============================================================
def verify_setup(bucket_name: str, region: str) -> bool:
    """Verify the bootstrap by performing a write/read round-trip on S3."""
    section("Step 4: Verify Setup")
    s3 = boto3.client("s3", region_name=region)
    test_key = f"{settings.s3_kb_prefix}.bootstrap_check"
    test_content = b"Bootstrap verification - safe to delete."

    try:
        s3.put_object(Bucket=bucket_name, Key=test_key, Body=test_content)
        log_ok(f"S3 write verified: s3://{bucket_name}/{test_key}")

        obj = s3.get_object(Bucket=bucket_name, Key=test_key)
        if obj['Body'].read() == test_content:
            log_ok("S3 read verified — content matches")
        else:
            log_fail("S3 content mismatch")
            return False

        s3.delete_object(Bucket=bucket_name, Key=test_key)
        log_ok("S3 delete verified — cleanup complete")
        return True
    except ClientError as e:
        log_fail(f"Verification failed: {e.response['Error']['Message']}")
        return False


# ============================================================
# Main
# ============================================================
def main():
    print(f"{C.BOLD}Low-Code RAG — AWS Infrastructure Bootstrap{C.END}")
    print(f"Region: {settings.aws_region}")
    print(f"Account: {settings.aws_account_id}")

    # Validate prerequisites
    if not settings.aws_account_id:
        log_fail("AWS_ACCOUNT_ID not set in .env")
        sys.exit(1)
    if not settings.s3_bucket_name:
        log_fail("S3_BUCKET_NAME not set in .env")
        sys.exit(1)

    # Step 1: S3
    bucket_ok = create_s3_bucket(settings.s3_bucket_name, settings.aws_region)
    if not bucket_ok:
        log_fail("S3 setup failed — aborting")
        sys.exit(1)

    # Step 2: BDA
    bda_project_name = f"low-code-rag-bda-{settings.aws_account_id}"
    bda_arn = create_bda_project(bda_project_name, settings.aws_region)
    if not bda_arn:
        log_warn("BDA project creation failed — ingestion pipeline will need fallback")
        log_warn("You can re-run this script after fixing IAM permissions")

    # Step 3: Update .env
    update_env_file(settings.s3_bucket_name, bda_arn)

    # Step 4: Verify
    verify_setup(settings.s3_bucket_name, settings.aws_region)

    # Summary
    section("BOOTSTRAP COMPLETE")
    print(f"  {C.OK}S3 Bucket:{C.END}        s3://{settings.s3_bucket_name}/")
    print(f"  {C.OK}KB Prefix:{C.END}        {settings.s3_kb_prefix}")
    if bda_arn:
        print(f"  {C.OK}BDA Project:{C.END}      {bda_arn}")
    else:
        print(f"  {C.WARN}BDA Project:{C.END}      NOT CREATED (see warnings above)")
    print(f"\n{C.OK}{C.BOLD}Next step:{C.END} python -m ingestion.cli --dept hr --pdf-folder ./sample_pdfs/hr/")


if __name__ == "__main__":
    main()