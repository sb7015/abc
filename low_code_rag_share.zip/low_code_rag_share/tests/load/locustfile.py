"""
Locust load test for Low-Code RAG API.

Usage:
  # Start the API first:
  #   uvicorn api.main:app --host 0.0.0.0 --port 8000

  # Then run Locust:
  #   locust -f tests/load/locustfile.py --host http://localhost:8000

  # Open http://localhost:8089 to drive the test (users, spawn rate, duration).

  # Or headless, e.g. 10 users for 60s:
  #   locust -f tests/load/locustfile.py --host http://localhost:8000 \
  #          --users 10 --spawn-rate 2 --run-time 60s --headless
"""
import random
from locust import HttpUser, task, between, events


# Realistic query mix (matches what users actually ask)
QUERY_POOL = [
    "How many vacation days for managers?",
    "What is the maternity leave duration?",
    "What is the notice period for L5 employees?",
    "Can I work from home on Tuesdays?",
    "What is the sick leave policy?",
    "How much is the health insurance coverage?",
    "What is the PF contribution percentage?",
    "What are the working hours at Acme?",
    "How do I apply for sabbatical leave?",
    "What is the bereavement leave duration?",
    "What is the carry forward limit for annual leave?",
    "What are the performance rating levels?",
    "How is travel booking done?",
    "What is the notice period for senior managers?",
    "How many paternity leave days are allowed?",
]


class RAGUser(HttpUser):
    """Simulates an employee asking HR questions."""

    # Think time between requests (1-4 seconds — realistic user cadence)
    wait_time = between(1, 4)

    @task(10)  # 10x weight — primary endpoint
    def query_hr(self):
        question = random.choice(QUERY_POOL)
        with self.client.post(
            "/v1/query",
            json={"department": "hr", "question": question},
            name="/v1/query",
            catch_response=True,
            timeout=60,
        ) as resp:
            if resp.status_code != 200:
                resp.failure(f"HTTP {resp.status_code}: {resp.text[:200]}")
                return
            try:
                data = resp.json()
            except Exception as e:
                resp.failure(f"JSON parse error: {e}")
                return

            if not data.get("answer"):
                resp.failure("Empty answer")
                return

            # Track useful metrics as custom events
            m = data.get("metrics", {})
            events.request.fire(
                request_type="METRIC",
                name="cost_usd",
                response_time=m.get("estimated_cost_usd", 0) * 1_000_000,  # trick to log as int
                response_length=0,
            )
            events.request.fire(
                request_type="METRIC",
                name="cache_hit_haiku",
                response_time=m.get("haiku_cached_tokens", 0),
                response_length=0,
            )
            events.request.fire(
                request_type="METRIC",
                name="cache_hit_sonnet",
                response_time=m.get("sonnet_cached_tokens", 0),
                response_length=0,
            )
            resp.success()

    @task(1)  # Low weight — occasional health check
    def health(self):
        self.client.get("/v1/health", name="/v1/health")

    @task(1)
    def departments(self):
        self.client.get("/v1/departments", name="/v1/departments")