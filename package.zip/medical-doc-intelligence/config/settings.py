# ============================================================================
# SETTINGS.PY - Application Configuration Settings
# ============================================================================
# Purpose: Central configuration for the Medical Document Intelligence system
# Author: Medical Doc Intelligence Team
# ============================================================================

import os
from dataclasses import dataclass
from typing import Optional

# ============================================================================
# SECTION 1: APPLICATION SETTINGS
# ============================================================================
# General application configuration parameters

@dataclass
class AppSettings:
    """Application-wide settings"""
    APP_NAME: str = "Medical Document Intelligence"
    APP_VERSION: str = "1.0.0"
    DEBUG_MODE: bool = False
    
    # Session settings
    SESSION_TIMEOUT_MINUTES: int = 60
    MAX_UPLOAD_SIZE_MB: int = 100
    ALLOWED_FILE_TYPES: tuple = (".pdf",)


# ============================================================================
# SECTION 2: PROCESSING SETTINGS
# ============================================================================
# Configuration for document processing

@dataclass
class ProcessingSettings:
    """Document processing configuration"""
    
    # OCR Settings
    OCR_PARALLEL_MAX_WORKERS: int = 5  # Max concurrent OCR operations
    OCR_TIMEOUT_SECONDS: int = 300      # Timeout per PDF
    
    # Chunking Settings (for GPT summarization)
    CHUNK_SIZE_TOKENS: int = 50000      # 50K tokens per chunk
    CHUNK_OVERLAP_TOKENS: int = 500     # Overlap between chunks
    
    # RAG Settings
    RAG_CHUNK_SIZE_TOKENS: int = 800    # Smaller chunks for RAG
    RAG_CHUNK_OVERLAP_TOKENS: int = 100
    RAG_TOP_K_RESULTS: int = 5          # Top K results for retrieval


# ============================================================================
# SECTION 3: BLOB STORAGE PATHS
# ============================================================================
# Azure Blob Storage folder structure

@dataclass
class BlobPaths:
    """Blob storage path templates"""
    
    # Base paths (session_id will be injected)
    MEDICAL_RECORDS: str = "{session_id}/medical_records/"
    OCR_OUTPUT: str = "{session_id}/ocr_output/"
    SUMMARIES: str = "{session_id}/summaries/"
    APPLICATION: str = "{session_id}/application/"
    ANALYSIS: str = "{session_id}/analysis/"
    RAG: str = "{session_id}/rag/"
    QA: str = "{session_id}/qa/"
    STATS: str = "{session_id}/stats/"
    RULES: str = "{session_id}/rules/"
    
    @staticmethod
    def get_path(template: str, session_id: str) -> str:
        """Generate actual path from template"""
        return template.format(session_id=session_id)


# ============================================================================
# SECTION 4: LLM SETTINGS
# ============================================================================
# Azure OpenAI configuration for summarization and Q&A

@dataclass
class LLMSettings:
    """LLM (GPT-5) configuration"""
    
    # Model settings
    SUMMARIZATION_MODEL: str = "gpt-5"
    QA_MODEL: str = "gpt-5"
    EXTRACTION_MODEL: str = "gpt-4o"
    EMBEDDING_MODEL: str = "text-embedding-3-large"
    
    # Prompt caching
    ENABLE_PROMPT_CACHING: bool = True
    
    # Temperature settings
    SUMMARIZATION_TEMPERATURE: float = 0.3
    QA_TEMPERATURE: float = 0.2
    EXTRACTION_TEMPERATURE: float = 0.1
    
    # Token limits
    MAX_OUTPUT_TOKENS: int = 4096


# ============================================================================
# SECTION 5: STATISTICS TRACKING
# ============================================================================
# Settings for cost and performance tracking

@dataclass
class StatsSettings:
    """Statistics and cost tracking configuration"""
    
    # Cost per 1K tokens (example rates)
    GPT5_INPUT_COST_PER_1K: float = 0.01
    GPT5_OUTPUT_COST_PER_1K: float = 0.03
    GPT5_CACHED_INPUT_COST_PER_1K: float = 0.0025  # 75% discount for cached
    
    EMBEDDING_COST_PER_1K: float = 0.0001
    OCR_COST_PER_PAGE: float = 0.01


# ============================================================================
# SECTION 6: GLOBAL SETTINGS INSTANCE
# ============================================================================
# Singleton instances for easy import

app_settings = AppSettings()
processing_settings = ProcessingSettings()
blob_paths = BlobPaths()
llm_settings = LLMSettings()
stats_settings = StatsSettings()
