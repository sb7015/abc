# ============================================================================
# AZURE_CONFIG.PY - Azure Services Configuration
# ============================================================================
# Purpose: Configuration for Azure services (Blob, Doc Intelligence, OpenAI)
# Author: Medical Doc Intelligence Team
# ============================================================================

import os
from dataclasses import dataclass
from typing import Optional

# ============================================================================
# SECTION 1: AZURE BLOB STORAGE CONFIGURATION
# ============================================================================
# Configuration for Azure Blob Storage service

@dataclass
class AzureBlobConfig:
    """Azure Blob Storage configuration"""
    
    # Connection string (from environment variable)
    CONNECTION_STRING: str = os.getenv("AZURE_STORAGE_CONNECTION_STRING", "")
    
    # Container name for medical documents
    CONTAINER_NAME: str = os.getenv("AZURE_BLOB_CONTAINER", "medical-documents")
    
    # SAS token expiry (hours)
    SAS_EXPIRY_HOURS: int = 24
    
    @property
    def is_configured(self) -> bool:
        """Check if Blob Storage is properly configured"""
        return bool(self.CONNECTION_STRING)


# ============================================================================
# SECTION 2: AZURE DOCUMENT INTELLIGENCE CONFIGURATION
# ============================================================================
# Configuration for Azure Document Intelligence (Form Recognizer) service

@dataclass
class AzureDocIntelligenceConfig:
    """Azure Document Intelligence configuration"""
    
    # Endpoint and API key (from environment variables)
    ENDPOINT: str = os.getenv("AZURE_DOC_INTELLIGENCE_ENDPOINT", "")
    API_KEY: str = os.getenv("AZURE_DOC_INTELLIGENCE_KEY", "")
    
    # Model to use for OCR
    MODEL_ID: str = "prebuilt-layout"  # Layout model for structured extraction
    
    # API version
    API_VERSION: str = "2024-02-29-preview"
    
    # Processing options
    LOCALE: str = "en-US"
    OUTPUT_FORMAT: str = "text"  # "text" or "markdown"
    
    @property
    def is_configured(self) -> bool:
        """Check if Document Intelligence is properly configured"""
        return bool(self.ENDPOINT and self.API_KEY)


# ============================================================================
# SECTION 3: AZURE OPENAI CONFIGURATION
# ============================================================================
# Configuration for Azure OpenAI service (GPT-5, Embeddings)

@dataclass
class AzureOpenAIConfig:
    """Azure OpenAI configuration"""
    
    # Endpoint and API key (from environment variables)
    ENDPOINT: str = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    API_KEY: str = os.getenv("AZURE_OPENAI_KEY", "")
    
    # API version
    API_VERSION: str = "2024-02-15-preview"
    
    # Deployment names (as configured in Azure OpenAI Studio)
    GPT5_DEPLOYMENT: str = os.getenv("AZURE_OPENAI_GPT5_DEPLOYMENT", "gpt-5")
    GPT4O_DEPLOYMENT: str = os.getenv("AZURE_OPENAI_GPT4O_DEPLOYMENT", "gpt-4o")
    EMBEDDING_DEPLOYMENT: str = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-large")
    
    # Request settings
    MAX_RETRIES: int = 3
    TIMEOUT_SECONDS: int = 120
    
    # Prompt caching settings
    ENABLE_PROMPT_CACHING: bool = True
    
    @property
    def is_configured(self) -> bool:
        """Check if Azure OpenAI is properly configured"""
        return bool(self.ENDPOINT and self.API_KEY)


# ============================================================================
# SECTION 4: CONFIGURATION VALIDATION
# ============================================================================
# Utility functions to validate Azure configuration

def validate_all_configs() -> dict:
    """
    Validate all Azure configurations and return status
    
    Returns:
        dict: Configuration status for each service
    """
    blob_config = AzureBlobConfig()
    doc_config = AzureDocIntelligenceConfig()
    openai_config = AzureOpenAIConfig()
    
    return {
        "blob_storage": {
            "configured": blob_config.is_configured,
            "container": blob_config.CONTAINER_NAME
        },
        "document_intelligence": {
            "configured": doc_config.is_configured,
            "model": doc_config.MODEL_ID
        },
        "openai": {
            "configured": openai_config.is_configured,
            "gpt5_deployment": openai_config.GPT5_DEPLOYMENT,
            "prompt_caching": openai_config.ENABLE_PROMPT_CACHING
        }
    }


# ============================================================================
# SECTION 5: GLOBAL CONFIG INSTANCES
# ============================================================================
# Singleton instances for easy import

blob_config = AzureBlobConfig()
doc_intelligence_config = AzureDocIntelligenceConfig()
openai_config = AzureOpenAIConfig()
