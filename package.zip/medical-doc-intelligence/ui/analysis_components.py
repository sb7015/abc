# ============================================================================
# ANALYSIS_COMPONENTS.PY - UI Components for Application Analysis
# ============================================================================
# Purpose: Streamlit UI components for discrepancy detection display
# Author: Medical Doc Intelligence Team
# ============================================================================

import streamlit as st
from typing import List, Dict, Any, Optional


# ============================================================================
# SECTION 1: SEVERITY BADGE STYLING
# ============================================================================
# Color-coded badges for discrepancy severity

SEVERITY_COLORS = {
    "critical": {"bg": "#dc3545", "text": "white", "icon": "🚨"},
    "high": {"bg": "#fd7e14", "text": "white", "icon": "⚠️"},
    "medium": {"bg": "#ffc107", "text": "black", "icon": "⚡"},
    "low": {"bg": "#17a2b8", "text": "white", "icon": "ℹ️"},
    "match": {"bg": "#28a745", "text": "white", "icon": "✅"},
    "info": {"bg": "#6c757d", "text": "white", "icon": "📋"}
}


def render_severity_badge(severity: str) -> str:
    """
    Render a colored severity badge as HTML.
    
    Args:
        severity: Severity level string
        
    Returns:
        str: HTML badge
    """
    config = SEVERITY_COLORS.get(severity.lower(), SEVERITY_COLORS["info"])
    return f"""
    <span style="
        background-color: {config['bg']};
        color: {config['text']};
        padding: 4px 12px;
        border-radius: 12px;
        font-weight: bold;
        font-size: 0.85em;
    ">{config['icon']} {severity.upper()}</span>
    """


# ============================================================================
# SECTION 2: ANALYSIS STATUS DISPLAY
# ============================================================================
# Show current analysis status

def render_analysis_status(
    rag_ready: bool,
    summary_available: bool,
    analysis_complete: bool = False,
    result: Optional[Dict] = None
):
    """
    Render the analysis status panel.
    
    Args:
        rag_ready: Whether RAG index is built
        summary_available: Whether medical summary exists
        analysis_complete: Whether analysis has been run
        result: Analysis result dict (optional)
    """
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if summary_available:
            st.success("✅ Medical Records Processed")
        else:
            st.warning("⚠️ Process medical records first")
    
    with col2:
        if rag_ready:
            st.success("✅ RAG Index Ready")
        else:
            st.warning("⚠️ RAG index not built")
    
    with col3:
        if analysis_complete and result:
            critical = result.get("summary", {}).get("critical_count", 0)
            high = result.get("summary", {}).get("high_count", 0)
            if critical > 0:
                st.error(f"🚨 {critical} Critical Issues")
            elif high > 0:
                st.warning(f"⚠️ {high} High Issues")
            else:
                st.success("✅ Analysis Complete")
        else:
            st.info("📋 Upload application to analyze")


# ============================================================================
# SECTION 3: APPLICATION FILE UPLOADER
# ============================================================================
# Upload component for application PDF

def render_application_uploader():
    """
    Render the application PDF uploader.
    
    Returns:
        Uploaded file or None
    """
    st.subheader("📄 Upload Insurance Application")
    
    uploaded_file = st.file_uploader(
        "Select insurance application PDF",
        type=["pdf"],
        key="application_upload",
        help="Upload the insurance application form to compare against medical records"
    )
    
    if uploaded_file:
        st.info(f"📎 Selected: **{uploaded_file.name}** ({uploaded_file.size / 1024:.1f} KB)")
    
    return uploaded_file


# ============================================================================
# SECTION 4: EXTRACTED FIELDS TABLE
# ============================================================================
# Display extracted application fields

def render_extracted_fields(fields: List[Dict[str, Any]]):
    """
    Render table of extracted application fields.
    
    Args:
        fields: List of extracted field dictionaries
    """
    if not fields:
        st.info("No fields extracted yet")
        return
    
    st.subheader(f"📋 Extracted Fields ({len(fields)})")
    
    # Group by category
    categories = {}
    for field in fields:
        cat = field.get("category", "other")
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(field)
    
    # Display by category
    for category, cat_fields in categories.items():
        with st.expander(f"**{category.replace('_', ' ').title()}** ({len(cat_fields)} fields)", expanded=False):
            for field in cat_fields:
                col1, col2 = st.columns([1, 2])
                with col1:
                    st.markdown(f"**{field['field_name']}**")
                with col2:
                    st.markdown(field['field_value'])


# ============================================================================
# SECTION 5: DISCREPANCY SUMMARY
# ============================================================================
# Summary metrics of discrepancies

def render_discrepancy_summary(result: Dict[str, Any]):
    """
    Render summary metrics of discrepancies.
    
    Args:
        result: Analysis result dictionary
    """
    summary = result.get("summary", {})
    
    st.subheader("📊 Analysis Summary")
    
    cols = st.columns(6)
    
    metrics = [
        ("Total Fields", summary.get("total_fields_analyzed", 0), None),
        ("🚨 Critical", summary.get("critical_count", 0), "critical"),
        ("⚠️ High", summary.get("high_count", 0), "high"),
        ("⚡ Medium", summary.get("medium_count", 0), "medium"),
        ("ℹ️ Low", summary.get("low_count", 0), "low"),
        ("✅ Match", summary.get("match_count", 0), "match")
    ]
    
    for i, (label, value, severity) in enumerate(metrics):
        with cols[i]:
            if severity == "critical" and value > 0:
                st.metric(label, value, delta="Issues found", delta_color="inverse")
            elif severity == "high" and value > 0:
                st.metric(label, value, delta="Review needed", delta_color="inverse")
            else:
                st.metric(label, value)


# ============================================================================
# SECTION 6: DISCREPANCY CARD
# ============================================================================
# Display individual discrepancy with citation

def render_discrepancy_card(discrepancy: Dict[str, Any], index: int):
    """
    Render a single discrepancy card with expandable details.
    
    Args:
        discrepancy: Discrepancy dictionary
        index: Card index for unique keys
    """
    severity = discrepancy.get("severity", "info")
    field_name = discrepancy.get("field_name", "Unknown Field")
    app_value = discrepancy.get("application_value", "")
    record_value = discrepancy.get("medical_record_value", "")
    explanation = discrepancy.get("explanation", "")
    citations = discrepancy.get("citations", [])
    
    # Determine container style based on severity
    border_colors = {
        "critical": "#dc3545",
        "high": "#fd7e14",
        "medium": "#ffc107",
        "low": "#17a2b8",
        "match": "#28a745",
        "info": "#6c757d"
    }
    border_color = border_colors.get(severity.lower(), "#6c757d")
    
    # Create expandable card
    with st.expander(
        f"{SEVERITY_COLORS.get(severity.lower(), {}).get('icon', '📋')} **{field_name}** - {severity.upper()}",
        expanded=(severity in ["critical", "high"])
    ):
        # Comparison view
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**📝 Application States:**")
            st.info(app_value or "Not specified")
        
        with col2:
            st.markdown("**📁 Medical Records Show:**")
            if severity == "match":
                st.success(record_value or "Matches application")
            elif severity in ["critical", "high"]:
                st.error(record_value or "Contradicts application")
            else:
                st.warning(record_value or "Partial information")
        
        # Explanation
        st.markdown("**💡 Analysis:**")
        st.markdown(explanation)
        
        # Citations
        if citations:
            st.markdown("**📌 Source Citations:**")
            for i, citation in enumerate(citations[:3]):
                pdf_name = citation.get("pdf_name", "Unknown")
                page = citation.get("page_number", "?")
                line_start = citation.get("line_start", "?")
                line_end = citation.get("line_end", "?")
                section = citation.get("section_type", "")
                
                citation_text = f"`{pdf_name}` | Page {page} | Lines {line_start}-{line_end}"
                if section and section != "unknown":
                    citation_text += f" | Section: {section}"
                
                st.caption(citation_text)
                
                # Show snippet if available
                if "text" in citation:
                    with st.expander("View excerpt", expanded=False):
                        st.text(citation["text"][:500] + "..." if len(citation.get("text", "")) > 500 else citation.get("text", ""))


# ============================================================================
# SECTION 7: FULL DISCREPANCY LIST
# ============================================================================
# Display all discrepancies grouped by severity

def render_discrepancy_list(discrepancies: List[Dict[str, Any]]):
    """
    Render full list of discrepancies, grouped by severity.
    
    Args:
        discrepancies: List of discrepancy dictionaries
    """
    if not discrepancies:
        st.info("No discrepancies to display")
        return
    
    st.subheader("🔍 Detailed Findings")
    
    # Filter options
    severity_filter = st.multiselect(
        "Filter by severity:",
        options=["critical", "high", "medium", "low", "match", "info"],
        default=["critical", "high", "medium"],
        format_func=lambda x: f"{SEVERITY_COLORS.get(x, {}).get('icon', '')} {x.title()}"
    )
    
    # Filter discrepancies
    filtered = [
        d for d in discrepancies 
        if d.get("severity", "").lower() in severity_filter
    ]
    
    if not filtered:
        st.info("No discrepancies match the selected filters")
        return
    
    st.caption(f"Showing {len(filtered)} of {len(discrepancies)} findings")
    
    # Group by severity for display
    severity_order = ["critical", "high", "medium", "low", "info", "match"]
    
    for severity in severity_order:
        severity_items = [d for d in filtered if d.get("severity", "").lower() == severity]
        if severity_items:
            st.markdown(f"### {SEVERITY_COLORS.get(severity, {}).get('icon', '')} {severity.title()} ({len(severity_items)})")
            for i, discrepancy in enumerate(severity_items):
                render_discrepancy_card(discrepancy, i)


# ============================================================================
# SECTION 8: PROGRESS DISPLAY
# ============================================================================
# Show analysis progress

def render_analysis_progress(step: str, percent: float):
    """
    Render analysis progress bar.
    
    Args:
        step: Current step description
        percent: Progress percentage (0-100)
    """
    st.progress(percent / 100)
    st.caption(f"🔄 {step}")


# ============================================================================
# SECTION 9: EXPORT BUTTON
# ============================================================================
# Export analysis results

def render_export_buttons(result: Dict[str, Any]):
    """
    Render export buttons for analysis results.
    
    Args:
        result: Analysis result dictionary
    """
    import json
    
    col1, col2 = st.columns(2)
    
    with col1:
        # JSON export
        json_data = json.dumps(result, indent=2)
        st.download_button(
            label="📥 Download JSON Report",
            data=json_data,
            file_name="discrepancy_report.json",
            mime="application/json",
            use_container_width=True
        )
    
    with col2:
        # Markdown report
        md_report = generate_markdown_report(result)
        st.download_button(
            label="📥 Download Markdown Report",
            data=md_report,
            file_name="discrepancy_report.md",
            mime="text/markdown",
            use_container_width=True
        )


def generate_markdown_report(result: Dict[str, Any]) -> str:
    """
    Generate a markdown report from analysis result.
    
    Args:
        result: Analysis result dictionary
        
    Returns:
        str: Markdown formatted report
    """
    summary = result.get("summary", {})
    discrepancies = result.get("discrepancies", [])
    
    md = f"""# Application Analysis Report

**Application:** {result.get('application_filename', 'Unknown')}
**Session ID:** {result.get('session_id', 'Unknown')}
**Analysis Date:** {result.get('timestamp', 'Unknown')}
**Processing Time:** {result.get('processing_time_seconds', 0):.2f} seconds

---

## Summary

| Metric | Count |
|--------|-------|
| Total Fields Analyzed | {summary.get('total_fields_analyzed', 0)} |
| 🚨 Critical Issues | {summary.get('critical_count', 0)} |
| ⚠️ High Issues | {summary.get('high_count', 0)} |
| ⚡ Medium Issues | {summary.get('medium_count', 0)} |
| ℹ️ Low Issues | {summary.get('low_count', 0)} |
| ✅ Matches | {summary.get('match_count', 0)} |

---

## Detailed Findings

"""
    
    # Group by severity
    severity_order = ["critical", "high", "medium", "low", "info", "match"]
    
    for severity in severity_order:
        items = [d for d in discrepancies if d.get("severity", "").lower() == severity]
        if items:
            md += f"### {severity.title()} ({len(items)})\n\n"
            
            for d in items:
                md += f"#### {d.get('field_name', 'Unknown')}\n\n"
                md += f"- **Application Value:** {d.get('application_value', 'N/A')}\n"
                md += f"- **Medical Record Value:** {d.get('medical_record_value', 'N/A')}\n"
                md += f"- **Explanation:** {d.get('explanation', 'N/A')}\n"
                
                citations = d.get("citations", [])
                if citations:
                    md += "- **Citations:**\n"
                    for c in citations[:3]:
                        md += f"  - {c.get('pdf_name', 'Unknown')} | Page {c.get('page_number', '?')} | Lines {c.get('line_start', '?')}-{c.get('line_end', '?')}\n"
                
                md += "\n"
    
    md += """---

*Report generated by Medical Document Intelligence Dashboard*
"""
    
    return md
