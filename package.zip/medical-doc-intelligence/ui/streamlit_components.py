# ============================================================================
# STREAMLIT_COMPONENTS.PY - Reusable Streamlit UI Components
# ============================================================================
# Purpose: UI components for the Medical Document Intelligence dashboard
# Author: Medical Doc Intelligence Team
# ============================================================================

import streamlit as st
from typing import List, Dict, Any, Optional
import pandas as pd

# ============================================================================
# SECTION 1: FILE UPLOAD COMPONENT
# ============================================================================
# Component for uploading medical PDF documents

def render_file_uploader() -> List[Any]:
    """
    Render file upload component for medical PDFs.
    
    Returns:
        List of uploaded file objects
    """
    st.subheader("📄 Upload Medical Records")
    
    uploaded_files = st.file_uploader(
        "Upload PDF files",
        type=["pdf"],
        accept_multiple_files=True,
        help="Upload one or more medical record PDFs for summarization"
    )
    
    if uploaded_files:
        st.success(f"✅ {len(uploaded_files)} file(s) uploaded")
        
        # Show file details
        with st.expander("View uploaded files"):
            for file in uploaded_files:
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.text(f"📄 {file.name}")
                with col2:
                    size_mb = file.size / (1024 * 1024)
                    st.text(f"{size_mb:.2f} MB")
    
    return uploaded_files


# ============================================================================
# SECTION 2: PROGRESS DISPLAY COMPONENT
# ============================================================================
# Component for showing processing progress

def render_progress_display(status: Dict[str, Any]):
    """
    Render processing progress with step indicators.
    
    Args:
        status: ProcessingStatus dictionary
    """
    st.subheader("⏳ Processing Status")
    
    # Overall progress bar
    progress = status.get("progress_percent", 0) / 100
    st.progress(progress)
    st.caption(f"Current step: {status.get('current_step', 'Waiting...')}")
    
    # Step status indicators
    steps = [
        ("Upload", status.get("upload_status", "pending")),
        ("OCR", status.get("ocr_status", "pending")),
        ("Chunking", status.get("chunking_status", "pending")),
        ("Summarization", status.get("summarization_status", "pending")),
        ("Final Summary", status.get("final_summary_status", "pending")),
    ]
    
    cols = st.columns(len(steps))
    for col, (step_name, step_status) in zip(cols, steps):
        with col:
            if step_status == "completed":
                st.success(f"✅ {step_name}")
            elif step_status == "processing":
                st.info(f"⏳ {step_name}")
            elif step_status == "failed":
                st.error(f"❌ {step_name}")
            else:
                st.text(f"⬜ {step_name}")


# ============================================================================
# SECTION 3: SUMMARY DISPLAY COMPONENT
# ============================================================================
# Component for displaying the medical summary

def render_summary_display(summary: str, condition_tags: List[str] = None):
    """
    Render the medical summary with condition tags.
    
    Args:
        summary: Markdown summary content
        condition_tags: List of condition tags (optional)
    """
    st.subheader("📋 Medical Summary")
    
    # Condition tags
    if condition_tags:
        st.write("**Identified Conditions:**")
        tag_html = " ".join([
            f'<span style="background-color: #e0f7fa; padding: 4px 12px; '
            f'border-radius: 16px; margin: 2px; display: inline-block;">'
            f'{tag}</span>'
            for tag in condition_tags
        ])
        st.markdown(tag_html, unsafe_allow_html=True)
        st.divider()
    
    # Summary content
    st.markdown(summary)


# ============================================================================
# SECTION 4: OCR STATISTICS TABLE (Table 1)
# ============================================================================
# Component for displaying OCR statistics

def render_ocr_stats_table(stats: List[Dict[str, Any]]):
    """
    Render OCR statistics table (Table 1).
    
    Columns: PDF Name | Page Count | Word Count | Processing Time
    
    Args:
        stats: List of OCR statistics dictionaries
    """
    st.subheader("📊 OCR Statistics")
    
    if not stats:
        st.info("No OCR statistics available")
        return
    
    # Create DataFrame
    df = pd.DataFrame(stats)
    df.columns = ["PDF Name", "Page Count", "Word Count", "Processing Time (s)", "Status"]
    
    # Display table
    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True
    )
    
    # Download button
    csv = df.to_csv(index=False)
    st.download_button(
        label="📥 Download as CSV",
        data=csv,
        file_name="ocr_stats.csv",
        mime="text/csv"
    )


# ============================================================================
# SECTION 5: CHUNK STATISTICS TABLE (Table 2)
# ============================================================================
# Component for displaying chunk processing statistics

def render_chunk_stats_table(stats: List[Dict[str, Any]]):
    """
    Render chunk processing statistics table (Table 2).
    
    Columns: Chunk # | Token Count | Processing Time | Cost | Cache Hit
    
    Args:
        stats: List of chunk statistics dictionaries
    """
    st.subheader("📈 Chunk Processing Statistics")
    
    if not stats:
        st.info("No chunk statistics available")
        return
    
    # Create DataFrame
    df = pd.DataFrame(stats)
    df.columns = ["Chunk #", "Token Count", "Processing Time (s)", "Cost ($)", "Cache Hit"]
    
    # Display table
    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True
    )
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Chunks", len(stats))
    with col2:
        total_tokens = sum(s.get("token_count", 0) for s in stats)
        st.metric("Total Tokens", f"{total_tokens:,}")
    with col3:
        total_cost = sum(s.get("cost", 0) for s in stats)
        st.metric("Total Cost", f"${total_cost:.4f}")
    with col4:
        cache_hits = sum(1 for s in stats if "Yes" in str(s.get("cache_hit", "")))
        st.metric("Cache Hits", f"{cache_hits}/{len(stats)}")
    
    # Download button
    csv = df.to_csv(index=False)
    st.download_button(
        label="📥 Download as CSV",
        data=csv,
        file_name="chunk_stats.csv",
        mime="text/csv"
    )


# ============================================================================
# SECTION 6: ERROR DISPLAY COMPONENT
# ============================================================================
# Component for displaying errors

def render_errors(errors: List[str]):
    """
    Render error messages.
    
    Args:
        errors: List of error messages
    """
    if errors:
        st.error("❌ Errors occurred during processing:")
        for error in errors:
            st.warning(error)


# ============================================================================
# SECTION 7: SIDEBAR COMPONENT
# ============================================================================
# Component for the sidebar

def render_sidebar():
    """
    Render the application sidebar.
    
    Returns:
        dict: Sidebar configuration values
    """
    with st.sidebar:
        st.title("⚕️ Medical Doc Intelligence")
        st.divider()
        
        # Session info
        st.subheader("📋 Session Info")
        session_id = st.text_input(
            "Session ID",
            value=st.session_state.get("session_id", ""),
            help="Unique identifier for this session"
        )
        
        st.divider()
        
        # Configuration
        st.subheader("⚙️ Configuration")
        
        chunk_size = st.number_input(
            "Chunk Size (tokens)",
            min_value=10000,
            max_value=100000,
            value=50000,
            step=5000
        )
        
        max_workers = st.slider(
            "Parallel Workers",
            min_value=1,
            max_value=10,
            value=5
        )
        
        st.divider()
        
        # Help
        st.subheader("❓ Help")
        st.info(
            "1. Upload medical PDFs\n"
            "2. Click 'Start Processing'\n"
            "3. View summary and statistics"
        )
        
        return {
            "session_id": session_id,
            "chunk_size": chunk_size,
            "max_workers": max_workers
        }
