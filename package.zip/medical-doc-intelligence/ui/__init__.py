# ============================================================================
# UI PACKAGE - Streamlit UI Components
# ============================================================================
from ui.streamlit_components import (
    render_file_uploader,
    render_progress_display,
    render_summary_display,
    render_ocr_stats_table,
    render_chunk_stats_table,
    render_errors,
    render_sidebar
)
from ui.qa_components import (
    render_chat_message,
    render_chat_history,
    render_chat_input,
    render_citation_details,
    render_qa_status,
    render_clear_history_button,
    render_qa_tab
)
from ui.analysis_components import (
    render_analysis_status,
    render_application_uploader,
    render_extracted_fields,
    render_discrepancy_summary,
    render_discrepancy_card,
    render_discrepancy_list,
    render_analysis_progress,
    render_export_buttons,
    render_severity_badge,
    generate_markdown_report
)

__all__ = [
    # Main UI Components
    "render_file_uploader",
    "render_progress_display",
    "render_summary_display",
    "render_ocr_stats_table",
    "render_chunk_stats_table",
    "render_errors",
    "render_sidebar",
    # Q&A Components
    "render_chat_message",
    "render_chat_history",
    "render_chat_input",
    "render_citation_details",
    "render_qa_status",
    "render_clear_history_button",
    "render_qa_tab",
    # Analysis Components
    "render_analysis_status",
    "render_application_uploader",
    "render_extracted_fields",
    "render_discrepancy_summary",
    "render_discrepancy_card",
    "render_discrepancy_list",
    "render_analysis_progress",
    "render_export_buttons",
    "render_severity_badge",
    "generate_markdown_report"
]
