# ============================================================================
# QA_COMPONENTS.PY - Q&A Tab UI Components
# ============================================================================
# Purpose: Streamlit UI components for the Q&A tab
#          - Chat interface
#          - Citation display
#          - Suggested questions
# Author: Medical Doc Intelligence Team
# ============================================================================

import streamlit as st
from typing import List, Dict, Any, Optional

# ============================================================================
# SECTION 1: CHAT MESSAGE DISPLAY
# ============================================================================
# Component for displaying chat messages with citations

def render_chat_message(
    role: str,
    content: str,
    citations: List[Dict[str, Any]] = None,
    confidence: float = None
):
    """
    Render a single chat message.
    
    Args:
        role: 'user' or 'assistant'
        content: Message content
        citations: List of citation dictionaries
        confidence: Confidence score (0-100)
    """
    if role == "user":
        with st.chat_message("user"):
            st.write(content)
    else:
        with st.chat_message("assistant"):
            st.write(content)
            
            # Show confidence if available
            if confidence is not None:
                confidence_color = "green" if confidence > 70 else "orange" if confidence > 40 else "red"
                st.caption(f"Confidence: :{confidence_color}[{confidence:.1f}%]")
            
            # Show citations if available
            if citations:
                with st.expander(f"📚 View Sources ({len(citations)} references)"):
                    for i, citation in enumerate(citations):
                        st.markdown(
                            f"**[{i+1}]** {citation.get('pdf_name', 'Unknown')} | "
                            f"Page {citation.get('page_number', '?')} | "
                            f"Lines {citation.get('line_start', '?')}-{citation.get('line_end', '?')}"
                        )
                        st.caption(f"Relevance: {citation.get('score', 0):.2%}")
                        with st.container():
                            st.text(citation.get('text', '')[:200] + "..." if len(citation.get('text', '')) > 200 else citation.get('text', ''))
                        st.divider()


# ============================================================================
# SECTION 2: CHAT HISTORY DISPLAY
# ============================================================================
# Component for displaying full chat history

def render_chat_history(messages: List[Dict[str, Any]]):
    """
    Render the complete chat history.
    
    Args:
        messages: List of message dictionaries with question, answer, citations
    """
    for msg in messages:
        # User question
        render_chat_message(
            role="user",
            content=msg.get("question", "")
        )
        
        # Assistant answer with citations
        render_chat_message(
            role="assistant",
            content=msg.get("answer", ""),
            citations=msg.get("citations", []),
            confidence=msg.get("confidence")
        )


# ============================================================================
# SECTION 3: CHAT INPUT
# ============================================================================
# Component for chat input with suggested questions

def render_chat_input(
    suggested_questions: List[str] = None,
    disabled: bool = False
) -> Optional[str]:
    """
    Render chat input with suggested questions.
    
    Args:
        suggested_questions: List of suggested questions
        disabled: Whether input is disabled
        
    Returns:
        str: User's question or None
    """
    # Suggested questions as buttons
    if suggested_questions:
        st.write("**💡 Suggested Questions:**")
        cols = st.columns(min(len(suggested_questions), 3))
        
        selected_question = None
        for i, q in enumerate(suggested_questions[:3]):
            with cols[i]:
                if st.button(
                    q[:50] + "..." if len(q) > 50 else q,
                    key=f"suggested_q_{i}",
                    disabled=disabled,
                    use_container_width=True
                ):
                    selected_question = q
        
        if selected_question:
            return selected_question
    
    # Main chat input
    question = st.chat_input(
        "Ask a question about the medical records...",
        disabled=disabled
    )
    
    return question


# ============================================================================
# SECTION 4: CITATION DETAILS PANEL
# ============================================================================
# Component for displaying detailed citation information

def render_citation_details(citations: List[Dict[str, Any]]):
    """
    Render detailed citation panel.
    
    Args:
        citations: List of citation dictionaries
    """
    if not citations:
        st.info("No citations available")
        return
    
    st.subheader("📚 Source Citations")
    
    for i, citation in enumerate(citations):
        with st.container():
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.markdown(f"### [{i+1}] {citation.get('pdf_name', 'Unknown')}")
                st.write(f"**Page:** {citation.get('page_number', '?')}")
                st.write(f"**Lines:** {citation.get('line_start', '?')} - {citation.get('line_end', '?')}")
            
            with col2:
                score = citation.get('score', 0)
                st.metric("Relevance", f"{score:.1%}")
            
            st.text_area(
                "Content",
                value=citation.get('text', ''),
                height=100,
                disabled=True,
                key=f"citation_text_{i}"
            )
            
            st.divider()


# ============================================================================
# SECTION 5: Q&A STATUS INDICATOR
# ============================================================================
# Component for showing Q&A readiness status

def render_qa_status(
    rag_ready: bool,
    summary_available: bool,
    chunk_count: int = 0
):
    """
    Render Q&A system status.
    
    Args:
        rag_ready: Whether RAG index is built
        summary_available: Whether medical summary exists
        chunk_count: Number of indexed chunks
    """
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if summary_available:
            st.success("✅ Medical Summary Available")
        else:
            st.warning("⚠️ No Medical Summary")
    
    with col2:
        if rag_ready:
            st.success(f"✅ RAG Index Ready ({chunk_count} chunks)")
        else:
            st.warning("⚠️ RAG Index Not Built")
    
    with col3:
        if rag_ready and summary_available:
            st.success("✅ Ready for Q&A")
        else:
            st.error("❌ Process records first")


# ============================================================================
# SECTION 6: CLEAR HISTORY BUTTON
# ============================================================================
# Component for clearing chat history

def render_clear_history_button(on_clear: callable = None) -> bool:
    """
    Render clear history button.
    
    Args:
        on_clear: Callback function when cleared
        
    Returns:
        bool: True if cleared
    """
    col1, col2 = st.columns([4, 1])
    
    with col2:
        if st.button("🗑️ Clear Chat", use_container_width=True):
            if on_clear:
                on_clear()
            return True
    
    return False


# ============================================================================
# SECTION 7: COMPLETE Q&A TAB
# ============================================================================
# Main component that combines all Q&A elements

def render_qa_tab(
    session_id: str,
    rag_ready: bool,
    summary_available: bool,
    chat_history: List[Dict[str, Any]],
    suggested_questions: List[str] = None,
    on_question: callable = None,
    on_clear: callable = None
):
    """
    Render the complete Q&A tab.
    
    Args:
        session_id: Current session ID
        rag_ready: Whether RAG is ready
        summary_available: Whether summary exists
        chat_history: List of chat messages
        suggested_questions: Suggested questions
        on_question: Callback when question is asked
        on_clear: Callback when history is cleared
    """
    st.header("💬 Q&A - Ask Questions About Medical Records")
    
    # Status indicator
    render_qa_status(
        rag_ready=rag_ready,
        summary_available=summary_available,
        chunk_count=len(chat_history) if chat_history else 0
    )
    
    st.divider()
    
    # Check if ready
    if not rag_ready or not summary_available:
        st.warning(
            "⚠️ Please process medical records first (in the Medical Summary tab) "
            "before using Q&A."
        )
        return
    
    # Clear history button
    if chat_history:
        if render_clear_history_button(on_clear):
            st.rerun()
    
    # Chat history
    if chat_history:
        render_chat_history(chat_history)
    else:
        st.info("👋 Ask a question to get started!")
    
    # Chat input
    question = render_chat_input(
        suggested_questions=suggested_questions,
        disabled=not rag_ready
    )
    
    if question and on_question:
        on_question(question)
        st.rerun()
