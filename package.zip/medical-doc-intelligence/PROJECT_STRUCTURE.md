# Medical Document Intelligence - Project Structure

## Overview
Azure-powered medical document processing system with Streamlit UI for life insurance underwriting.

---

## Folder Structure

```
medical-doc-intelligence/
│
├── app.py                          # Main Streamlit application entry point
│
├── config/
│   ├── __init__.py
│   ├── settings.py                 # Azure credentials, API keys, endpoints
│   ├── constants.py                # Prompt size (50K), chunk sizes, thresholds
│   └── azure_config.py             # Azure Blob, Doc Intelligence, OpenAI configs
│
├── services/
│   ├── __init__.py
│   │
│   ├── blob_service.py             # Azure Blob Storage operations
│   │   # - upload_file(file, session_id, doc_type)
│   │   # - download_file(blob_path)
│   │   # - save_json(data, session_id, filename)
│   │   # - get_json(session_id, filename)
│   │   # - list_files(session_id)
│   │
│   ├── ocr_service.py              # Azure Document Intelligence (Layout Model)
│   │   # - extract_document(blob_url) -> OCR text + metadata
│   │   # - process_single_pdf(pdf_path) -> sequential processing
│   │   # - get_word_count(text)
│   │   # - calculate_processing_time()
│   │
│   ├── llm_service.py              # Azure OpenAI GPT-5 with prompt caching
│   │   # - summarize_chunk(chunk_text, prompt) -> chunk summary
│   │   # - summarize_all_chunks(chunk_summaries) -> final MD summary
│   │   # - sliding_window_process(full_text, window_size=50000)
│   │   # - get_token_count(text)
│   │   # - calculate_cost(input_tokens, output_tokens)
│   │   # - enable_prompt_caching()
│   │
│   ├── application_service.py      # Application form extraction (Layout + GPT-4o)
│   │   # - extract_application_fields(blob_url) -> JSON
│   │   # - parse_structured_data(ocr_result)
│   │   # - validate_fields(extracted_data)
│   │
│   ├── rules_service.py            # Auto-reject rules engine
│   │   # - load_rules(rules_blob_path) -> parse Word file
│   │   # - evaluate_rules(application_data) -> pass/fail list
│   │   # - get_auto_reject_decision(rule_results)
│   │
│   └── comparison_service.py       # Medical vs Application comparison
│       # - compare_records(medical_summary, application_data)
│       # - find_discrepancies() -> list with citations
│       # - generate_citation(field, source_doc, page_num)
│       # - calculate_severity(discrepancy_type)
│
├── models/
│   ├── __init__.py
│   ├── session.py                  # Session model (UUID, timestamps, status)
│   ├── document.py                 # Document model (name, type, pages, word_count)
│   ├── chunk.py                    # Chunk model (name, size, tokens, cost, doc_ref)
│   ├── discrepancy.py              # Discrepancy model (field, app_val, med_val, citation)
│   └── statistics.py               # Statistics model (OCR stats, chunk stats)
│
├── utils/
│   ├── __init__.py
│   ├── session_manager.py          # UUID generation, session tracking
│   │   # - create_session() -> UUID
│   │   # - get_session_data(session_id)
│   │   # - update_session_status(session_id, status)
│   │
│   ├── text_processor.py           # Text chunking and processing
│   │   # - chunk_text(text, max_size=50000) -> list of chunks
│   │   # - clean_text(raw_text)
│   │   # - extract_sections(text)
│   │
│   ├── token_counter.py            # Token counting utilities
│   │   # - count_tokens(text, model="gpt-5")
│   │   # - estimate_cost(input_tokens, output_tokens)
│   │
│   ├── excel_exporter.py           # Excel/CSV export utilities
│   │   # - export_ocr_stats(data) -> Excel bytes
│   │   # - export_chunk_stats(data) -> Excel bytes
│   │   # - create_download_link(df, filename)
│   │
│   └── word_parser.py              # Parse Word files (rules document)
│       # - parse_docx(file_path) -> rules list
│       # - extract_rules(docx_content)
│
├── prompts/
│   ├── __init__.py
│   ├── medical_summary.py          # Prompts for medical record summarization
│   │   # - CHUNK_SUMMARY_PROMPT
│   │   # - FINAL_SUMMARY_PROMPT
│   │   # - CONDITION_EXTRACTION_PROMPT
│   │
│   ├── application_extract.py      # Prompts for application field extraction
│   │   # - FIELD_EXTRACTION_PROMPT
│   │   # - VALIDATION_PROMPT
│   │
│   └── comparison.py               # Prompts for discrepancy detection
│       # - COMPARISON_PROMPT
│       # - CITATION_GENERATION_PROMPT
│
├── ui/
│   ├── __init__.py
│   ├── sidebar.py                  # Streamlit sidebar components
│   │   # - render_session_info(session_id)
│   │   # - render_medical_uploader()
│   │   # - render_application_uploader()
│   │   # - render_process_button()
│   │
│   ├── tab_medical_summary.py      # Tab 1: Medical Summary display
│   │   # - render_summary_card(md_content)
│   │   # - render_condition_tags(conditions)
│   │
│   ├── tab_application_analysis.py # Tab 2: Application Analysis display
│   │   # - render_auto_reject_status(decision)
│   │   # - render_rules_check(rule_results)
│   │   # - render_discrepancy_table(discrepancies)
│   │
│   └── tab_statistics.py           # Tab 3: Statistics display
│       # - render_ocr_stats_table(ocr_data)  + download button
│       # - render_chunk_stats_table(chunk_data) + download button
│       # - render_total_processing_time()
│
├── data/
│   ├── rules/
│   │   └── auto_reject_rules.docx  # Pre-uploaded rules Word file
│   │
│   └── sample/                     # Sample test files (optional)
│       ├── sample_medical.pdf
│       └── sample_application.pdf
│
├── tests/
│   ├── __init__.py
│   ├── test_ocr_service.py
│   ├── test_llm_service.py
│   ├── test_comparison_service.py
│   └── test_rules_service.py
│
├── requirements.txt                # Python dependencies
├── .env.example                    # Environment variables template
├── .gitignore                      # Git ignore file
├── Dockerfile                      # Docker configuration for Azure App Service
├── azure-pipelines.yml             # CI/CD pipeline (optional)
└── README.md                       # Project documentation
```

---

## Key Components Description

### 1. `app.py` - Main Entry Point
```python
# - Initialize Streamlit page config
# - Create session UUID on first load
# - Render sidebar (uploaders, session info)
# - Render 3 tabs (Medical Summary, Application Analysis, Statistics)
# - Orchestrate processing flow when "Analyze" clicked
```

### 2. `services/` - Core Business Logic

| Service | Purpose |
|---------|---------|
| `blob_service.py` | All Azure Blob operations (upload/download/list) |
| `ocr_service.py` | Azure Doc Intelligence - Layout model for OCR |
| `llm_service.py` | GPT-5 with sliding window (50K) + prompt caching |
| `application_service.py` | Layout + GPT-4o for application form extraction |
| `rules_service.py` | Load & evaluate auto-reject rules from Word file |
| `comparison_service.py` | Compare medical vs application, generate citations |

### 3. `ui/` - Streamlit Components

| Component | Tab/Section |
|-----------|-------------|
| `sidebar.py` | Left sidebar - uploads, session, process button |
| `tab_medical_summary.py` | Tab 1 - MD summary + condition tags |
| `tab_application_analysis.py` | Tab 2 - Rules check + discrepancy table |
| `tab_statistics.py` | Tab 3 - Two tables with download buttons |

### 4. `prompts/` - LLM Prompts
All prompts stored as constants for easy modification and prompt caching.

### 5. `models/` - Data Models
Pydantic/dataclass models for type safety and validation.

---

## Processing Flow (Sequential)

```
1. User uploads medical PDFs
   └── Store in Blob: /{session_id}/medical/{filename}

2. User uploads application PDF
   └── Store in Blob: /{session_id}/application/{filename}

3. User clicks "Analyze"
   │
   ├── Step A: OCR Processing (Sequential per document)
   │   ├── For each PDF in medical folder:
   │   │   ├── Call Azure Doc Intelligence (Layout)
   │   │   ├── Record: word_count, extraction_time
   │   │   └── Save OCR text to Blob
   │   └── Save ocr_stats.json to Blob
   │
   ├── Step B: Medical Summarization (GPT-5 + Prompt Caching)
   │   ├── Combine all OCR texts
   │   ├── Sliding window chunking (50K tokens)
   │   ├── For each chunk (sequential):
   │   │   ├── Summarize chunk
   │   │   └── Record: chunk_name, size, tokens, cost, time
   │   ├── Final summary of all chunks -> MD output
   │   └── Save chunk_stats.json to Blob
   │
   ├── Step C: Application Extraction (Layout + GPT-4o)
   │   ├── OCR application PDF
   │   ├── Extract structured fields -> JSON
   │   └── Save to Blob
   │
   ├── Step D: Rules Evaluation
   │   ├── Load rules from Word file
   │   ├── Evaluate each rule against application
   │   └── Return auto-reject decision
   │
   └── Step E: Discrepancy Detection
       ├── Compare application JSON vs medical summary
       ├── Find mismatches with citations
       └── Return discrepancy list

4. Display results in 3 tabs
```

---

## JSON Files Stored in Blob (per session)

| File | Content |
|------|---------|
| `/{session_id}/ocr_stats.json` | OCR table data (doc name, word count, time) |
| `/{session_id}/chunk_stats.json` | Chunk table data (chunk name, tokens, cost) |
| `/{session_id}/medical_summary.md` | Final medical summary in Markdown |
| `/{session_id}/application_data.json` | Extracted application fields |
| `/{session_id}/discrepancies.json` | Comparison results with citations |

---

## Environment Variables (.env)

```env
# Azure Blob Storage
AZURE_STORAGE_CONNECTION_STRING=
AZURE_STORAGE_CONTAINER_NAME=medical-docs

# Azure Document Intelligence
AZURE_DOC_INTELLIGENCE_ENDPOINT=
AZURE_DOC_INTELLIGENCE_KEY=

# Azure OpenAI
AZURE_OPENAI_ENDPOINT=
AZURE_OPENAI_KEY=
AZURE_OPENAI_GPT5_DEPLOYMENT=gpt-5
AZURE_OPENAI_GPT4O_DEPLOYMENT=gpt-4o

# App Config
PROMPT_MAX_SIZE=50000
ENABLE_PROMPT_CACHING=true
```

---

## Dependencies (requirements.txt)

```
streamlit>=1.30.0
azure-storage-blob>=12.19.0
azure-ai-formrecognizer>=3.3.0
openai>=1.12.0
python-docx>=1.1.0
pandas>=2.1.0
openpyxl>=3.1.0
tiktoken>=0.5.0
python-dotenv>=1.0.0
pydantic>=2.5.0
```
