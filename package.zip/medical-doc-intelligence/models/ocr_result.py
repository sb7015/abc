# ============================================================================
# OCR_RESULT.PY - OCR Result Data Models
# ============================================================================
# Purpose: Data models for storing OCR results with metadata
# Author: Medical Doc Intelligence Team
# ============================================================================

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime
import json

# ============================================================================
# SECTION 1: LINE METADATA MODEL
# ============================================================================
# Model for storing individual line information with position

@dataclass
class LineMetadata:
    """
    Represents a single line of text with its metadata.
    Used for citation purposes (page, line number reference).
    """
    line_number: int
    text: str
    page_number: int
    bounding_box: List[float] = field(default_factory=list)  # [x1, y1, x2, y2, ...]
    confidence: float = 1.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return {
            "line_number": self.line_number,
            "text": self.text,
            "page_number": self.page_number,
            "bounding_box": self.bounding_box,
            "confidence": self.confidence
        }


# ============================================================================
# SECTION 2: PAGE METADATA MODEL
# ============================================================================
# Model for storing page-level information

@dataclass
class PageMetadata:
    """
    Represents a single page with all its lines and metadata.
    """
    page_number: int
    width: float = 0.0
    height: float = 0.0
    lines: List[LineMetadata] = field(default_factory=list)
    word_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return {
            "page_number": self.page_number,
            "width": self.width,
            "height": self.height,
            "lines": [line.to_dict() for line in self.lines],
            "word_count": self.word_count
        }
    
    @property
    def full_text(self) -> str:
        """Get all text from the page"""
        return "\n".join([line.text for line in self.lines])


# ============================================================================
# SECTION 3: OCR RESULT MODEL
# ============================================================================
# Complete OCR result for a single PDF document

@dataclass
class OCRResult:
    """
    Complete OCR result for a single PDF document.
    Contains all pages with their lines and metadata.
    """
    # Document identification
    pdf_name: str
    session_id: str
    
    # Content
    pages: List[PageMetadata] = field(default_factory=list)
    
    # Statistics
    total_pages: int = 0
    total_words: int = 0
    total_lines: int = 0
    
    # Processing info
    processing_time_seconds: float = 0.0
    processed_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    
    # Status
    status: str = "pending"  # pending, processing, completed, failed
    error_message: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return {
            "pdf_name": self.pdf_name,
            "session_id": self.session_id,
            "pages": [page.to_dict() for page in self.pages],
            "total_pages": self.total_pages,
            "total_words": self.total_words,
            "total_lines": self.total_lines,
            "processing_time_seconds": self.processing_time_seconds,
            "processed_at": self.processed_at,
            "status": self.status,
            "error_message": self.error_message
        }
    
    def to_json(self) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict(), indent=2)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "OCRResult":
        """Create OCRResult from dictionary"""
        result = cls(
            pdf_name=data["pdf_name"],
            session_id=data["session_id"],
            total_pages=data.get("total_pages", 0),
            total_words=data.get("total_words", 0),
            total_lines=data.get("total_lines", 0),
            processing_time_seconds=data.get("processing_time_seconds", 0.0),
            processed_at=data.get("processed_at", ""),
            status=data.get("status", "pending"),
            error_message=data.get("error_message")
        )
        
        # Parse pages
        for page_data in data.get("pages", []):
            page = PageMetadata(
                page_number=page_data["page_number"],
                width=page_data.get("width", 0),
                height=page_data.get("height", 0),
                word_count=page_data.get("word_count", 0)
            )
            # Parse lines
            for line_data in page_data.get("lines", []):
                line = LineMetadata(
                    line_number=line_data["line_number"],
                    text=line_data["text"],
                    page_number=line_data["page_number"],
                    bounding_box=line_data.get("bounding_box", []),
                    confidence=line_data.get("confidence", 1.0)
                )
                page.lines.append(line)
            result.pages.append(page)
        
        return result
    
    @property
    def full_text(self) -> str:
        """Get all text from all pages"""
        return "\n\n".join([
            f"[Page {page.page_number}]\n{page.full_text}" 
            for page in self.pages
        ])
    
    def get_text_with_citations(self) -> List[Dict[str, Any]]:
        """
        Get text chunks with citation metadata.
        Used for RAG indexing.
        """
        chunks = []
        for page in self.pages:
            for line in page.lines:
                chunks.append({
                    "text": line.text,
                    "pdf_name": self.pdf_name,
                    "page_number": page.page_number,
                    "line_number": line.line_number,
                    "bounding_box": line.bounding_box
                })
        return chunks


# ============================================================================
# SECTION 4: OCR STATISTICS MODEL
# ============================================================================
# Model for OCR processing statistics (for Statistics tab)

@dataclass
class OCRStats:
    """
    OCR processing statistics for a single PDF.
    Used for Table 1 in Statistics tab.
    """
    pdf_name: str
    page_count: int
    word_count: int
    processing_time_seconds: float
    status: str = "completed"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "pdf_name": self.pdf_name,
            "page_count": self.page_count,
            "word_count": self.word_count,
            "processing_time_seconds": round(self.processing_time_seconds, 2),
            "status": self.status
        }


# ============================================================================
# SECTION 5: COMBINED OCR RESULTS MODEL
# ============================================================================
# Model for combining results from multiple PDFs

@dataclass
class CombinedOCRResults:
    """
    Combined OCR results from multiple PDF documents.
    """
    session_id: str
    results: List[OCRResult] = field(default_factory=list)
    stats: List[OCRStats] = field(default_factory=list)
    
    # Aggregated statistics
    total_pdfs: int = 0
    total_pages: int = 0
    total_words: int = 0
    total_processing_time: float = 0.0
    
    def add_result(self, result: OCRResult):
        """Add an OCR result and update statistics"""
        self.results.append(result)
        self.stats.append(OCRStats(
            pdf_name=result.pdf_name,
            page_count=result.total_pages,
            word_count=result.total_words,
            processing_time_seconds=result.processing_time_seconds,
            status=result.status
        ))
        
        # Update aggregated stats
        self.total_pdfs += 1
        self.total_pages += result.total_pages
        self.total_words += result.total_words
        self.total_processing_time += result.processing_time_seconds
    
    def get_combined_text(self) -> str:
        """Get combined text from all PDFs"""
        return "\n\n".join([
            f"=== {result.pdf_name} ===\n{result.full_text}"
            for result in self.results
        ])
    
    def get_all_citations(self) -> List[Dict[str, Any]]:
        """Get all text chunks with citations from all PDFs"""
        all_citations = []
        for result in self.results:
            all_citations.extend(result.get_text_with_citations())
        return all_citations
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "session_id": self.session_id,
            "total_pdfs": self.total_pdfs,
            "total_pages": self.total_pages,
            "total_words": self.total_words,
            "total_processing_time_seconds": round(self.total_processing_time, 2),
            "results": [r.to_dict() for r in self.results],
            "stats": [s.to_dict() for s in self.stats]
        }
