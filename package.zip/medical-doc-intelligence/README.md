# Medical Document Intelligence Dashboard

A comprehensive Streamlit-based application for intelligent medical document processing and analysis. Built with Azure services for OCR, AI summarization, discrepancy detection, and semantic search.

## Features

- **Medical Record Summarization**: Upload PDFs, extract text via Azure Document Intelligence, and generate AI-powered summaries using GPT-5
- **Application Discrepancy Detection**: Compare insurance applications against medical records to identify inconsistencies
- **Q&A Chat Interface**: Ask natural language questions about medical records with RAG-powered semantic search and citations
- **Processing Statistics**: Track OCR metrics, token usage, costs, and cache performance

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Streamlit Dashboard                          │
├────────────┬────────────┬────────────┬────────────────────────┤
│  Summary   │  Analysis  │    Q&A     │       Statistics       │
│    Tab     │    Tab     │    Tab     │          Tab           │
└─────┬──────┴─────┬──────┴─────┬──────┴───────────┬────────────┘
       │                │                        │
       ▼                ▼                        ▼
┌─────────────────────────────────────────────────────────────────┐
│                       Service Layer                             │
├─────────────┬─────────────┬────────────┬────────────────────────┤
│ OCR Service │ LLM Service │RAG Service │ Analysis Service       │
└──────┬──────┴──────┬──────┴─────┬──────┴──────────┬─────────────┘
       │             │            │                 │
       ▼             ▼            ▼                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                     Azure Services                              │
├─────────────────┬──────────────────┬────────────────────────────┤
│ Document        │   Azure OpenAI   │   Azure Blob              │
│ Intelligence    │   (GPT-5, GPT-4o)│   Storage                 │
│ (OCR)           │   (Embeddings)   │   (Files, Index)          │
└─────────────────┴──────────────────┴────────────────────────────┘
```

## Prerequisites

- **Python 3.10+**
- **Azure Account** with the following services provisioned:
  - Azure Blob Storage
  - Azure Document Intelligence (Form Recognizer)
  - Azure OpenAI Service with deployed models

## Environment Variables

Create a `.env` file in the project root with the following variables:

```bash
# ============================================================================
# AZURE BLOB STORAGE
# ============================================================================
# Connection string from Azure Portal > Storage Account > Access Keys
AZURE_STORAGE_CONNECTION_STRING=DefaultEndpointsProtocol=https;AccountName=<your-account>;AccountKey=<your-key>;EndpointSuffix=core.windows.net

# Container name for storing medical documents (created automatically)
AZURE_BLOB_CONTAINER=medical-documents

# ============================================================================
# AZURE DOCUMENT INTELLIGENCE
# ============================================================================
# Endpoint from Azure Portal > Document Intelligence > Keys and Endpoint
AZURE_DOC_INTELLIGENCE_ENDPOINT=https://<your-resource>.cognitiveservices.azure.com/

# API Key from Azure Portal > Document Intelligence > Keys and Endpoint
AZURE_DOC_INTELLIGENCE_KEY=<your-key>

# ============================================================================
# AZURE OPENAI
# ============================================================================
# Endpoint from Azure Portal > Azure OpenAI > Keys and Endpoint
AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com/

# API Key from Azure Portal > Azure OpenAI > Keys and Endpoint
AZURE_OPENAI_KEY=<your-key>

# ============================================================================
# AZURE OPENAI MODEL DEPLOYMENTS
# ============================================================================
# Deployment names as configured in Azure OpenAI Studio

# GPT-5 deployment name (for summarization and comparison)
AZURE_OPENAI_GPT5_DEPLOYMENT=gpt-5

# GPT-4o deployment name (for field extraction)
AZURE_OPENAI_GPT4O_DEPLOYMENT=gpt-4o

# Text embedding model deployment name (for RAG)
AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-large
```

### How to Get Azure Credentials

1. **Azure Blob Storage**:
   - Go to Azure Portal > Storage Accounts > Create
   - After creation, go to "Access keys" and copy the connection string

2. **Azure Document Intelligence**:
   - Go to Azure Portal > Create a resource > Document Intelligence
   - After creation, go to "Keys and Endpoint" to get credentials

3. **Azure OpenAI**:
   - Go to Azure Portal > Azure OpenAI > Create
   - Deploy models in Azure OpenAI Studio (GPT-5, GPT-4o, text-embedding-3-large)
   - Get endpoint and keys from "Keys and Endpoint"

## Installation

1. **Clone or navigate to the project directory**:
   ```bash
   cd medical-doc-intelligence
   ```

2. **Create a virtual environment** (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/macOS
   # or
   .\venv\Scripts\activate   # Windows
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Create the `.env` file** with your Azure credentials (see Environment Variables section above)

5. **Verify configuration**:
   ```bash
   python -c "from config.azure_config import validate_all_configs; print(validate_all_configs())"
   ```

## Running the Application

```bash
streamlit run app.py
```

The application will open in your browser at `http://localhost:8501`

### Running with Custom Port

```bash
streamlit run app.py --server.port 8080
```

## Usage Guide

### Tab 1: Medical Summary

1. **Upload PDFs**: Drag and drop or click to upload medical record PDFs
2. **Click "Start Processing"**: The system will:
   - Upload files to Azure Blob Storage
   - Run OCR using Azure Document Intelligence (parallel processing)
   - Chunk the extracted text (50K token sliding window)
   - Summarize each chunk with GPT-5 (with prompt caching)
   - Merge summaries into a final comprehensive summary
3. **View Results**: See the formatted summary with condition tags
4. **Download**: Export the summary as Markdown

### Tab 2: Application Analysis

*Requires: Medical Summary tab must be completed first*

1. **Upload Application**: Upload an insurance application PDF
2. **Click "Analyze Application"**: The system will:
   - Extract structured fields using GPT-4o
   - Search RAG index for each field's evidence
   - Compare application claims against medical records using GPT-5
   - Generate discrepancy report with citations
3. **Review Discrepancies**: View severity-coded findings (CRITICAL, HIGH, MEDIUM, LOW)
4. **Export**: Download results as JSON or Markdown

### Tab 3: Q&A (Question & Answer)

*Requires: Medical Summary tab must be completed first (RAG index built)*

1. **Ask Questions**: Type natural language questions about the medical records
2. **Get Answers**: The system uses RAG (Retrieval-Augmented Generation) to:
   - Search the HNSW vector index for relevant chunks
   - Generate accurate answers with GPT-5
   - Provide citations (file, page, line numbers)
3. **Suggested Questions**: Click pre-built questions for common queries
4. **Clear Chat**: Reset the conversation history

### Tab 4: Statistics

- **OCR Stats Table**: PDF name, page count, word count, processing time
- **Chunk Stats Table**: Chunk number, token count, processing time, cost, cache hit
- **Overall Metrics**: Total time, cost, cache hit rate
- **Export**: Download tables as CSV/Excel

## Project Structure

```
medical-doc-intelligence/
├── app.py                          # Main Streamlit application
├── requirements.txt                # Python dependencies
├── README.md                       # This file
├── PROJECT_STRUCTURE.md            # Detailed structure documentation
│
├── config/                         # Configuration
│   ├── __init__.py
│   ├── azure_config.py             # Azure service credentials
│   └── settings.py                 # Application settings
│
├── services/                       # Business logic
│   ├── __init__.py
│   ├── blob_service.py             # Azure Blob Storage operations
│   ├── ocr_service.py              # Document Intelligence OCR
│   ├── llm_service.py              # Azure OpenAI LLM calls
│   ├── rag_service.py              # FAISS vector store & search
│   ├── qa_service.py               # Q&A with RAG search and citations
│   ├── analysis_service.py         # Discrepancy detection
│   └── summarization_service.py    # Summarization pipeline
│
├── models/                         # Data models
│   ├── __init__.py
│   └── ocr_result.py               # OCR result structures
│
├── ui/                             # UI components
│   ├── __init__.py
│   ├── streamlit_components.py     # Summary tab components
│   └── analysis_components.py      # Analysis tab components
│
├── utils/                          # Utility functions
│   ├── __init__.py
│   └── text_chunker.py             # Contextual text chunking
│
├── prompts/                        # LLM prompts
│   ├── __init__.py
│   ├── summarization_prompt.txt    # Summarization system prompt
│   └── qa_prompt.txt               # RAG search prompt
│
├── data/                           # Data files
│   ├── rules/                      # Comparison rules (optional)
│   └── sample/                     # Sample files for testing
│
└── tests/                          # Test files
    └── __init__.py
```

## Key Technologies

| Component | Technology | Purpose |
|-----------|------------|---------|
| Frontend | Streamlit | Interactive web dashboard |
| OCR | Azure Document Intelligence | PDF text extraction |
| LLM | Azure OpenAI GPT-5 | Summarization, comparison |
| Extraction | Azure OpenAI GPT-4o | Field extraction |
| Embeddings | text-embedding-3-large | Semantic search vectors |
| Vector Store | FAISS (HNSW) | Fast similarity search |
| Storage | Azure Blob Storage | File & index persistence |
| Chunking | Contextual/Section-aware | Medical document parsing |

## Performance Features

- **Parallel OCR Processing**: Multiple PDFs processed concurrently
- **Parallel LLM Calls**: Chunk summarization runs in parallel
- **Prompt Caching**: GPT-5 prompt caching reduces costs for repeated patterns
- **HNSW Index**: O(log n) vector search instead of O(n) brute force
- **Section-Aware Chunking**: Keeps related medical content together

## Cost Tracking

The application tracks:
- Token usage (input/output)
- API costs per chunk
- Cache hit rates
- Total processing costs

View detailed breakdowns in the Statistics tab.

## Troubleshooting

### "Azure configuration not valid"
- Verify all environment variables are set correctly
- Check that Azure services are provisioned and accessible
- Ensure API keys haven't expired

### "RAG index not ready"
- Process medical records in the Medical Summary tab first
- Wait for the "RAG index built" success message

### "OCR failed for PDF"
- Ensure PDF is not password-protected
- Check that PDF contains actual text (not just images without OCR)
- Verify Azure Document Intelligence service is running

### Slow processing
- Large PDFs take longer for OCR
- Consider reducing the number of concurrent files
- Check Azure service quotas

## License

This project is proprietary software. All rights reserved.

---

*Built with Azure AI Services and Streamlit*
