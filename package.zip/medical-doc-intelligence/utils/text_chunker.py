# ============================================================================
# TEXT_CHUNKER.PY - Text Chunking Utilities
# ============================================================================
# Purpose: Split OCR text into chunks for LLM processing
#          - CONTEXTUAL/SECTION-BASED chunking for medical documents
#          - Sliding window for summarization (50K tokens)
#          - Smaller semantic chunks for RAG (500 tokens)
# Author: Medical Doc Intelligence Team
# ============================================================================

import re
import tiktoken
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import logging

from config.settings import processing_settings

# Setup logging
logger = logging.getLogger(__name__)

# ============================================================================
# SECTION 1: MEDICAL DOCUMENT SECTION TYPES
# ============================================================================
# Define section types for contextual chunking

class MedicalSectionType(Enum):
    """
    Types of sections found in medical documents.
    Used for contextual chunking to keep related content together.
    """
    LAB_RESULTS = "lab_results"
    VITALS = "vitals"
    DIAGNOSIS = "diagnosis"
    PROVIDER_NOTES = "provider_notes"
    PRESCRIPTION = "prescription"
    IMAGING = "imaging"
    PROCEDURE = "procedure"
    HISTORY = "history"
    FAX_COVER = "fax_cover"
    EMAIL = "email"
    INSURANCE = "insurance"
    BILLING = "billing"
    CONSENT = "consent"
    UNKNOWN = "unknown"


# ============================================================================
# SECTION 2: SECTION DETECTION PATTERNS
# ============================================================================
# Regex patterns to detect medical document sections

SECTION_PATTERNS = {
    MedicalSectionType.LAB_RESULTS: [
        r"lab(?:oratory)?\s*results?",
        r"blood\s*(?:work|test|panel)",
        r"cbc|cmp|bmp|lipid\s*panel",
        r"urinalysis|urine\s*test",
        r"a1c|hemoglobin",
        r"specimen|collected",
        r"reference\s*range",
    ],
    MedicalSectionType.VITALS: [
        r"vital\s*signs?",
        r"blood\s*pressure|bp[\s:]+\d",
        r"heart\s*rate|pulse[\s:]+\d",
        r"temperature[\s:]+\d",
        r"weight[\s:]+\d",
        r"height[\s:]+\d",
        r"bmi[\s:]+\d",
        r"oxygen\s*sat|spo2",
    ],
    MedicalSectionType.DIAGNOSIS: [
        r"diagnos[ie]s",
        r"icd[-\s]?\d+",
        r"assessment\s*(?:and|&)?\s*plan",
        r"impression",
        r"findings?",
        r"conclusion",
    ],
    MedicalSectionType.PROVIDER_NOTES: [
        r"(?:physician|doctor|provider|nurse)\s*notes?",
        r"progress\s*notes?",
        r"clinical\s*notes?",
        r"encounter\s*notes?",
        r"soap\s*note",
        r"chief\s*complaint",
        r"history\s*of\s*present\s*illness|hpi",
        r"review\s*of\s*systems|ros",
        r"physical\s*exam(?:ination)?",
    ],
    MedicalSectionType.PRESCRIPTION: [
        r"prescription",
        r"medication(?:s)?(?:\s*list)?",
        r"rx\s*:",
        r"refill",
        r"dosage",
        r"sig\s*:",
        r"dispense",
    ],
    MedicalSectionType.IMAGING: [
        r"radiology",
        r"x[-\s]?ray",
        r"ct\s*scan|computed\s*tomography",
        r"mri|magnetic\s*resonance",
        r"ultrasound|sonograph",
        r"mammogra",
        r"pet\s*scan",
    ],
    MedicalSectionType.PROCEDURE: [
        r"procedure(?:\s*report)?",
        r"operative\s*(?:report|note)",
        r"surgical\s*(?:report|note)",
        r"colonoscopy",
        r"endoscopy",
        r"biopsy",
    ],
    MedicalSectionType.HISTORY: [
        r"medical\s*history",
        r"past\s*(?:medical|surgical)\s*history",
        r"pmh|psh",
        r"family\s*history",
        r"social\s*history",
        r"allergies",
    ],
    MedicalSectionType.FAX_COVER: [
        r"fax\s*cover",
        r"facsimile",
        r"attention\s*:",
        r"from\s*:\s*\w+.*to\s*:",
        r"pages?\s*(?:including|incl)",
    ],
    MedicalSectionType.EMAIL: [
        r"from\s*:.*@",
        r"to\s*:.*@",
        r"subject\s*:",
        r"sent\s*:",
        r"cc\s*:",
    ],
    MedicalSectionType.INSURANCE: [
        r"insurance",
        r"policy\s*(?:number|#)",
        r"member\s*id",
        r"group\s*(?:number|#)",
        r"copay|deductible",
        r"prior\s*auth",
    ],
    MedicalSectionType.BILLING: [
        r"billing",
        r"invoice",
        r"charges?",
        r"payment",
        r"account\s*(?:number|#)",
        r"amount\s*due",
    ],
    MedicalSectionType.CONSENT: [
        r"consent",
        r"authorization",
        r"hipaa",
        r"release\s*of\s*information",
        r"patient\s*signature",
    ],
}


# ============================================================================
# SECTION 3: CHUNK DATA MODEL
# ============================================================================
# Model for representing a text chunk with metadata

@dataclass
class TextChunk:
    """
    Represents a chunk of text with metadata for citation tracking.
    """
    chunk_id: int
    text: str
    token_count: int
    
    # Section information for contextual chunking
    section_type: MedicalSectionType = MedicalSectionType.UNKNOWN
    section_header: str = ""
    
    # Source tracking for citations
    source_files: List[str] = field(default_factory=list)
    start_page: int = 0
    end_page: int = 0
    start_line: int = 0
    end_line: int = 0
    
    # Metadata
    is_first_chunk: bool = False
    is_last_chunk: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "chunk_id": self.chunk_id,
            "text": self.text,
            "token_count": self.token_count,
            "section_type": self.section_type.value,
            "section_header": self.section_header,
            "source_files": self.source_files,
            "start_page": self.start_page,
            "end_page": self.end_page,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "is_first_chunk": self.is_first_chunk,
            "is_last_chunk": self.is_last_chunk
        }


# ============================================================================
# SECTION 4: TOKEN COUNTER
# ============================================================================
# Count tokens using tiktoken for accurate chunking

class TokenCounter:
    """
    Token counter using tiktoken for GPT models.
    """
    
    def __init__(self, model: str = "gpt-4"):
        """
        Initialize token counter.
        
        Args:
            model: Model name for encoding (gpt-4, gpt-3.5-turbo, etc.)
        """
        try:
            self.encoding = tiktoken.encoding_for_model(model)
        except KeyError:
            # Fallback to cl100k_base for GPT-4/GPT-5 models
            self.encoding = tiktoken.get_encoding("cl100k_base")
    
    def count_tokens(self, text: str) -> int:
        """
        Count tokens in text.
        
        Args:
            text: Input text
            
        Returns:
            int: Number of tokens
        """
        return len(self.encoding.encode(text))
    
    def truncate_to_tokens(self, text: str, max_tokens: int) -> str:
        """
        Truncate text to maximum tokens.
        
        Args:
            text: Input text
            max_tokens: Maximum number of tokens
            
        Returns:
            str: Truncated text
        """
        tokens = self.encoding.encode(text)
        if len(tokens) <= max_tokens:
            return text
        return self.encoding.decode(tokens[:max_tokens])


# ============================================================================
# SECTION 5: SECTION DETECTOR
# ============================================================================
# Detect medical document sections from text

class MedicalSectionDetector:
    """
    Detects medical document sections from text content.
    Used for contextual chunking to keep related content together.
    """
    
    def __init__(self):
        """Initialize section detector with compiled patterns"""
        self.compiled_patterns = {}
        for section_type, patterns in SECTION_PATTERNS.items():
            self.compiled_patterns[section_type] = [
                re.compile(pattern, re.IGNORECASE)
                for pattern in patterns
            ]
    
    def detect_section(self, text: str) -> Tuple[MedicalSectionType, float]:
        """
        Detect the section type from text.
        
        Args:
            text: Text content to analyze
            
        Returns:
            Tuple[MedicalSectionType, float]: Section type and confidence score
        """
        scores = {}
        text_lower = text.lower()
        
        for section_type, patterns in self.compiled_patterns.items():
            matches = sum(1 for p in patterns if p.search(text_lower))
            if matches > 0:
                # Score based on number of pattern matches
                scores[section_type] = matches / len(patterns)
        
        if scores:
            best_match = max(scores.items(), key=lambda x: x[1])
            return best_match[0], best_match[1]
        
        return MedicalSectionType.UNKNOWN, 0.0
    
    def is_section_header(self, text: str) -> bool:
        """
        Check if text is likely a section header.
        
        Args:
            text: Text to check
            
        Returns:
            bool: True if likely a header
        """
        # Headers are typically short, uppercase, or end with ':'
        text_stripped = text.strip()
        
        if len(text_stripped) > 100:
            return False
        
        if text_stripped.isupper():
            return True
        
        if text_stripped.endswith(':'):
            return True
        
        # Check if it matches any section pattern strongly
        section_type, confidence = self.detect_section(text_stripped)
        return section_type != MedicalSectionType.UNKNOWN and confidence > 0.3
    
    def extract_section_header(self, text: str) -> Optional[str]:
        """
        Extract section header from text.
        
        Args:
            text: Text that might contain a header
            
        Returns:
            Optional[str]: Extracted header or None
        """
        lines = text.split('\n')
        for line in lines[:3]:  # Check first 3 lines
            if self.is_section_header(line):
                return line.strip()
        return None


# ============================================================================
# SECTION 6: CONTEXTUAL MEDICAL DOCUMENT CHUNKER
# ============================================================================
# Section-aware chunking for medical documents

class ContextualMedicalChunker:
    """
    Contextual chunker for medical documents.
    - Detects document sections (lab results, provider notes, etc.)
    - Keeps sections together when possible
    - Respects token limits while preserving context
    - Adds section metadata for better retrieval
    """
    
    def __init__(
        self,
        chunk_size: int = None,
        overlap_size: int = None,
        min_section_size: int = 50
    ):
        """
        Initialize contextual chunker.
        
        Args:
            chunk_size: Maximum tokens per chunk (default from settings)
            overlap_size: Overlap tokens between chunks (default from settings)
            min_section_size: Minimum tokens to keep section together
        """
        self.chunk_size = chunk_size or processing_settings.RAG_CHUNK_SIZE_TOKENS
        self.overlap_size = overlap_size or processing_settings.RAG_CHUNK_OVERLAP_TOKENS
        self.min_section_size = min_section_size
        self.token_counter = TokenCounter()
        self.section_detector = MedicalSectionDetector()
        
        logger.info(
            f"ContextualMedicalChunker initialized: "
            f"chunk_size={self.chunk_size}, "
            f"overlap={self.overlap_size}"
        )
    
    # ========================================================================
    # SECTION 6.1: PARSE DOCUMENT INTO SECTIONS
    # ========================================================================
    # Identify and extract sections from OCR output
    
    def _parse_sections(
        self,
        text_with_metadata: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Parse OCR output into sections.
        
        Args:
            text_with_metadata: List of OCR line items with metadata
            
        Returns:
            List of section dictionaries
        """
        sections = []
        current_section = {
            "type": MedicalSectionType.UNKNOWN,
            "header": "",
            "items": [],
            "pdf_name": "",
            "start_page": 0,
            "start_line": 0,
            "end_page": 0,
            "end_line": 0
        }
        
        for item in text_with_metadata:
            text = item.get("text", "")
            pdf_name = item.get("pdf_name", "")
            page_num = item.get("page_number", 0)
            line_num = item.get("line_number", 0)
            
            # Check if this is a new section header
            if self.section_detector.is_section_header(text):
                # Save current section if it has content
                if current_section["items"]:
                    sections.append(current_section)
                
                # Start new section
                section_type, _ = self.section_detector.detect_section(text)
                current_section = {
                    "type": section_type,
                    "header": text.strip(),
                    "items": [item],
                    "pdf_name": pdf_name,
                    "start_page": page_num,
                    "start_line": line_num,
                    "end_page": page_num,
                    "end_line": line_num
                }
            else:
                # Add to current section
                current_section["items"].append(item)
                current_section["end_page"] = page_num
                current_section["end_line"] = line_num
                
                if not current_section["pdf_name"]:
                    current_section["pdf_name"] = pdf_name
                    current_section["start_page"] = page_num
                    current_section["start_line"] = line_num
        
        # Add final section
        if current_section["items"]:
            sections.append(current_section)
        
        logger.info(f"Parsed {len(sections)} sections from OCR output")
        return sections
    
    # ========================================================================
    # SECTION 6.2: CHUNK SECTIONS
    # ========================================================================
    # Convert sections into chunks while respecting boundaries
    
    def chunk_with_context(
        self,
        text_with_metadata: List[Dict[str, Any]]
    ) -> List[TextChunk]:
        """
        Chunk OCR output while preserving section context.
        
        CONTEXTUAL CHUNKING STRATEGY:
        1. Parse document into sections (lab results, notes, etc.)
        2. Keep small sections together as single chunks
        3. Split large sections at natural boundaries
        4. Add section metadata to each chunk for better retrieval
        
        Args:
            text_with_metadata: List of OCR line items with metadata
            
        Returns:
            List[TextChunk]: Contextually-aware chunks
        """
        # Parse into sections first
        sections = self._parse_sections(text_with_metadata)
        
        chunks = []
        chunk_id = 0
        
        for section in sections:
            # Get section text and token count
            section_text = "\n".join(
                item.get("text", "") for item in section["items"]
            )
            section_tokens = self.token_counter.count_tokens(section_text)
            
            # ----------------------------------------------------------------
            # CASE 1: Section fits in one chunk - keep it together
            # ----------------------------------------------------------------
            if section_tokens <= self.chunk_size:
                chunk = TextChunk(
                    chunk_id=chunk_id,
                    text=section_text,
                    token_count=section_tokens,
                    section_type=section["type"],
                    section_header=section["header"],
                    source_files=[section["pdf_name"]] if section["pdf_name"] else [],
                    start_page=section["start_page"],
                    end_page=section["end_page"],
                    start_line=section["start_line"],
                    end_line=section["end_line"],
                    is_first_chunk=(chunk_id == 0)
                )
                chunks.append(chunk)
                chunk_id += 1
            
            # ----------------------------------------------------------------
            # CASE 2: Section too large - split at natural boundaries
            # ----------------------------------------------------------------
            else:
                section_chunks = self._split_large_section(
                    section, chunk_id
                )
                chunks.extend(section_chunks)
                chunk_id += len(section_chunks)
        
        # Mark last chunk
        if chunks:
            chunks[-1].is_last_chunk = True
        
        logger.info(f"Created {len(chunks)} contextual chunks")
        return chunks
    
    def _split_large_section(
        self,
        section: Dict[str, Any],
        start_chunk_id: int
    ) -> List[TextChunk]:
        """
        Split a large section into multiple chunks.
        
        Args:
            section: Section dictionary
            start_chunk_id: Starting chunk ID
            
        Returns:
            List[TextChunk]: Chunks from this section
        """
        chunks = []
        current_texts = []
        current_tokens = 0
        current_start_page = section["start_page"]
        current_start_line = section["start_line"]
        chunk_id = start_chunk_id
        
        for item in section["items"]:
            text = item.get("text", "")
            page_num = item.get("page_number", 0)
            line_num = item.get("line_number", 0)
            item_tokens = self.token_counter.count_tokens(text)
            
            # Check if adding this exceeds limit
            if current_tokens + item_tokens > self.chunk_size and current_texts:
                # Create chunk
                chunk = TextChunk(
                    chunk_id=chunk_id,
                    text="\n".join(current_texts),
                    token_count=current_tokens,
                    section_type=section["type"],
                    section_header=section["header"],
                    source_files=[section["pdf_name"]] if section["pdf_name"] else [],
                    start_page=current_start_page,
                    end_page=page_num,
                    start_line=current_start_line,
                    end_line=line_num
                )
                chunks.append(chunk)
                chunk_id += 1
                
                # Get overlap for continuity
                overlap_texts, overlap_tokens = self._get_overlap(current_texts)
                current_texts = overlap_texts
                current_tokens = overlap_tokens
                current_start_page = page_num
                current_start_line = line_num
            
            current_texts.append(text)
            current_tokens += item_tokens
        
        # Final chunk
        if current_texts:
            chunk = TextChunk(
                chunk_id=chunk_id,
                text="\n".join(current_texts),
                token_count=current_tokens,
                section_type=section["type"],
                section_header=section["header"],
                source_files=[section["pdf_name"]] if section["pdf_name"] else [],
                start_page=current_start_page,
                end_page=section["end_page"],
                start_line=current_start_line,
                end_line=section["end_line"]
            )
            chunks.append(chunk)
        
        return chunks
    
    def _get_overlap(self, text_lines: List[str]) -> Tuple[List[str], int]:
        """
        Get overlap text from end of chunk.
        
        Args:
            text_lines: List of text lines
            
        Returns:
            Tuple: (overlap_lines, overlap_tokens)
        """
        if not text_lines:
            return [], 0
        
        overlap_lines = []
        overlap_tokens = 0
        
        for line in reversed(text_lines):
            line_tokens = self.token_counter.count_tokens(line)
            if overlap_tokens + line_tokens > self.overlap_size:
                break
            overlap_lines.insert(0, line)
            overlap_tokens += line_tokens
        
        return overlap_lines, overlap_tokens


# ============================================================================
# SECTION 7: SLIDING WINDOW TEXT CHUNKER (for Summarization)
# ============================================================================
# Large chunk (50K tokens) sliding window for LLM summarization

class TextChunker:
    """
    Text chunker using sliding window approach.
    Splits text into chunks of specified token size with overlap.
    Used for SUMMARIZATION (large 50K token chunks).
    """
    
    def __init__(
        self,
        chunk_size: int = None,
        overlap_size: int = None
    ):
        """
        Initialize chunker.
        
        Args:
            chunk_size: Maximum tokens per chunk (default from settings)
            overlap_size: Overlap tokens between chunks (default from settings)
        """
        self.chunk_size = chunk_size or processing_settings.CHUNK_SIZE_TOKENS
        self.overlap_size = overlap_size or processing_settings.CHUNK_OVERLAP_TOKENS
        self.token_counter = TokenCounter()
        
        logger.info(
            f"TextChunker initialized: "
            f"chunk_size={self.chunk_size}, "
            f"overlap={self.overlap_size}"
        )

    def chunk_text_with_metadata(
        self,
        text_with_metadata: List[Dict[str, Any]]
    ) -> List[TextChunk]:
        """
        Chunk text while preserving metadata for citations.
        
        Args:
            text_with_metadata: List of dicts with 'text', 'pdf_name', 
                              'page_number', 'line_number' keys
                              
        Returns:
            List[TextChunk]: List of chunks with metadata
        """
        chunks = []
        current_chunk_text = []
        current_chunk_tokens = 0
        current_sources = set()
        current_start_page = 0
        current_end_page = 0
        current_start_line = 0
        current_end_line = 0
        chunk_id = 0
        
        for item in text_with_metadata:
            text = item.get("text", "")
            pdf_name = item.get("pdf_name", "")
            page_num = item.get("page_number", 0)
            line_num = item.get("line_number", 0)
            
            item_tokens = self.token_counter.count_tokens(text)
            
            if current_chunk_tokens + item_tokens > self.chunk_size:
                if current_chunk_text:
                    chunk = TextChunk(
                        chunk_id=chunk_id,
                        text="\n".join(current_chunk_text),
                        token_count=current_chunk_tokens,
                        source_files=list(current_sources),
                        start_page=current_start_page,
                        end_page=current_end_page,
                        start_line=current_start_line,
                        end_line=current_end_line,
                        is_first_chunk=(chunk_id == 0)
                    )
                    chunks.append(chunk)
                    chunk_id += 1
                
                overlap_text, overlap_tokens = self._get_overlap(current_chunk_text)
                current_chunk_text = overlap_text
                current_chunk_tokens = overlap_tokens
                current_sources = set()
                current_start_page = page_num
                current_start_line = line_num
            
            current_chunk_text.append(text)
            current_chunk_tokens += item_tokens
            current_sources.add(pdf_name)
            current_end_page = page_num
            current_end_line = line_num
            
            if current_start_page == 0:
                current_start_page = page_num
                current_start_line = line_num
        
        if current_chunk_text:
            chunk = TextChunk(
                chunk_id=chunk_id,
                text="\n".join(current_chunk_text),
                token_count=current_chunk_tokens,
                source_files=list(current_sources),
                start_page=current_start_page,
                end_page=current_end_page,
                start_line=current_start_line,
                end_line=current_end_line,
                is_first_chunk=(chunk_id == 0),
                is_last_chunk=True
            )
            chunks.append(chunk)
        
        logger.info(f"Created {len(chunks)} chunks from text")
        return chunks
    
    def _get_overlap(self, text_lines: List[str]) -> Tuple[List[str], int]:
        """Get overlap text from end of chunk."""
        if not text_lines:
            return [], 0
        
        overlap_lines = []
        overlap_tokens = 0
        
        for line in reversed(text_lines):
            line_tokens = self.token_counter.count_tokens(line)
            if overlap_tokens + line_tokens > self.overlap_size:
                break
            overlap_lines.insert(0, line)
            overlap_tokens += line_tokens
        
        return overlap_lines, overlap_tokens

    def chunk_text(self, text: str) -> List[TextChunk]:
        """Simple text chunking without metadata."""
        lines = text.split('\n')
        text_with_metadata = [
            {"text": line, "pdf_name": "", "page_number": i, "line_number": i}
            for i, line in enumerate(lines)
        ]
        return self.chunk_text_with_metadata(text_with_metadata)

    def get_chunk_summary(self, chunks: List[TextChunk]) -> Dict[str, Any]:
        """Get summary statistics of chunks."""
        if not chunks:
            return {"total_chunks": 0}
        
        total_tokens = sum(c.token_count for c in chunks)
        
        return {
            "total_chunks": len(chunks),
            "total_tokens": total_tokens,
            "average_tokens_per_chunk": round(total_tokens / len(chunks), 2),
            "min_tokens": min(c.token_count for c in chunks),
            "max_tokens": max(c.token_count for c in chunks),
            "all_source_files": list(set(
                f for c in chunks for f in c.source_files
            ))
        }


# ============================================================================
# SECTION 8: RAG CHUNKER (Uses Contextual Chunking)
# ============================================================================
# Smaller contextual chunks optimized for RAG/embedding

class RAGChunker(ContextualMedicalChunker):
    """
    RAG-optimized chunker using CONTEXTUAL/SECTION-BASED chunking.
    - Detects medical document sections
    - Keeps related content together
    - Adds section metadata for better retrieval
    """
    
    def __init__(self):
        """Initialize RAG chunker with contextual settings"""
        super().__init__(
            chunk_size=processing_settings.RAG_CHUNK_SIZE_TOKENS,
            overlap_size=processing_settings.RAG_CHUNK_OVERLAP_TOKENS
        )
        logger.info(
            f"RAGChunker (Contextual) initialized: "
            f"chunk_size={self.chunk_size}, "
            f"overlap={self.overlap_size}"
        )


# ============================================================================
# SECTION 9: SINGLETON INSTANCES
# ============================================================================
# Global instances for easy import

text_chunker = TextChunker()
rag_chunker = RAGChunker()
contextual_chunker = ContextualMedicalChunker()
token_counter = TokenCounter()
section_detector = MedicalSectionDetector()
