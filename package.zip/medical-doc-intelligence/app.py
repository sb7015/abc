# ============================================================================
# APP.PY - Main Streamlit Application
# ============================================================================
# Purpose: Main entry point for Medical Document Intelligence Dashboard
# Author: Medical Doc Intelligence Team
# ============================================================================
#
# Usage: streamlit run app.py
#
# ============================================================================

import streamlit as st
import uuid
from datetime import datetime
from typing import List, Dict, Any

# Import UI components
from ui.streamlit_components import (
    render_file_uploader,
    render_progress_display,
    render_summary_display,
    render_ocr_stats_table,
    render_chunk_stats_table,
    render_errors,
    render_sidebar
)
from ui.qa_components import (
    render_chat_message,
    render_chat_history,
    render_chat_input,
    render_qa_status,
    render_clear_history_button
)
from ui.analysis_components import (
    render_analysis_status,
    render_application_uploader,
    render_extracted_fields,
    render_discrepancy_summary,
    render_discrepancy_list,
    render_analysis_progress,
    render_export_buttons
)

# Import services
from services.summarization_service import summarization_service, ProcessingStatus
from services.rag_service import rag_service
from services.qa_service import qa_service
from services.analysis_service import analysis_service

# ============================================================================
# SECTION 1: PAGE CONFIGURATION
# ============================================================================

st.set_page_config(
    page_title="Medical Document Intelligence",
    page_icon="⚕️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================================
# SECTION 2: SESSION STATE INITIALIZATION
# ============================================================================

def init_session_state():
    """Initialize session state variables"""
    if "session_id" not in st.session_state:
        st.session_state.session_id = str(uuid.uuid4())[:8]
    
    if "processing_status" not in st.session_state:
        st.session_state.processing_status = None
    
    if "uploaded_files" not in st.session_state:
        st.session_state.uploaded_files = []
    
    if "final_summary" not in st.session_state:
        st.session_state.final_summary = None
    
    if "ocr_stats" not in st.session_state:
        st.session_state.ocr_stats = []
    
    if "chunk_stats" not in st.session_state:
        st.session_state.chunk_stats = []
    
    # Q&A specific state
    if "rag_ready" not in st.session_state:
        st.session_state.rag_ready = False
    
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    
    if "suggested_questions" not in st.session_state:
        st.session_state.suggested_questions = []
    
    # Analysis specific state
    if "analysis_result" not in st.session_state:
        st.session_state.analysis_result = None
    
    if "analysis_in_progress" not in st.session_state:
        st.session_state.analysis_in_progress = False

init_session_state()

# ============================================================================
# SECTION 3: SIDEBAR
# ============================================================================

sidebar_config = render_sidebar()
st.session_state.session_id = sidebar_config["session_id"] or st.session_state.session_id

# ============================================================================
# SECTION 4: MAIN CONTENT - TAB NAVIGATION (4 TABS)
# ============================================================================

st.title("⚕️ Medical Document Intelligence Dashboard")
st.caption(f"Session ID: {st.session_state.session_id}")

# Create 4 tabs
tab1, tab2, tab3, tab4 = st.tabs([
    "📋 Medical Summary",
    "🔍 Application Analysis", 
    "💬 Q&A",
    "📊 Statistics"
])

# ============================================================================
# SECTION 5: TAB 1 - MEDICAL SUMMARY
# ============================================================================
# Handles: Upload, OCR, Chunking, Summarization

with tab1:
    st.header("Medical Record Summarization")
    
    # ========================================================================
    # SECTION 5.1: FILE UPLOAD
    # ========================================================================
    uploaded_files = render_file_uploader()
    
    # ========================================================================
    # SECTION 5.2: PROCESS BUTTON
    # ========================================================================
    if uploaded_files:
        col1, col2 = st.columns([1, 4])
        with col1:
            process_button = st.button(
                "🚀 Start Processing",
                type="primary",
                use_container_width=True
            )
        
        if process_button:
            # Prepare files for processing
            files_data = [
                {
                    "name": f.name,
                    "content": f.read()
                }
                for f in uploaded_files
            ]
            
            # Reset file position
            for f in uploaded_files:
                f.seek(0)
            
            # ================================================================
            # SECTION 5.3: RUN PROCESSING PIPELINE
            # ================================================================
            with st.spinner("Processing medical records..."):
                # Progress placeholder
                progress_placeholder = st.empty()
                
                def update_progress(status: ProcessingStatus):
                    with progress_placeholder.container():
                        render_progress_display(status.to_dict())
                
                # Run the pipeline
                status = summarization_service.run_pipeline(
                    session_id=st.session_state.session_id,
                    files=files_data,
                    progress_callback=update_progress
                )
                
                # Store results in session state
                st.session_state.processing_status = status
                st.session_state.final_summary = status.final_summary
                st.session_state.ocr_stats = [
                    s.to_dict() for s in status.ocr_results.stats
                ] if status.ocr_results else []
                st.session_state.chunk_stats = [
                    s.to_dict() for s in status.chunk_stats
                ]
                
                # ================================================================
                # SECTION 5.3.1: BUILD RAG INDEX FOR Q&A
                # ================================================================
                if status.status == "completed" and status.ocr_results:
                    with st.spinner("Building RAG index for Q&A..."):
                        try:
                            citations = status.ocr_results.get_all_citations()
                            chunk_count = rag_service.build_index_from_ocr(
                                citations,
                                st.session_state.session_id
                            )
                            st.session_state.rag_ready = True
                            
                            # Generate suggested questions
                            if status.final_summary:
                                st.session_state.suggested_questions = \
                                    qa_service.get_suggested_questions(status.final_summary)
                        except Exception as e:
                            st.warning(f"Failed to build RAG index: {e}")
            
            # Show completion message
            if status.status == "completed":
                st.success(
                    f"✅ Processing completed in {status.total_processing_time:.2f}s "
                    f"(Cost: ${status.total_cost:.4f})"
                )
                if st.session_state.rag_ready:
                    st.info("✅ RAG index built - Q&A is now available!")
            else:
                st.error("❌ Processing failed")
                render_errors(status.errors)
    
    # ========================================================================
    # SECTION 5.4: DISPLAY SUMMARY
    # ========================================================================
    if st.session_state.final_summary:
        st.divider()
        
        # Extract condition tags from summary (simple extraction)
        condition_tags = []
        if "[" in st.session_state.final_summary:
            import re
            tags = re.findall(r'\[([^\]]+)\]', st.session_state.final_summary)
            condition_tags = list(set(tags))[:10]  # Limit to 10 tags
        
        render_summary_display(
            summary=st.session_state.final_summary,
            condition_tags=condition_tags
        )
        
        # Download summary button
        st.download_button(
            label="📥 Download Summary (Markdown)",
            data=st.session_state.final_summary,
            file_name="medical_summary.md",
            mime="text/markdown"
        )

# ============================================================================
# SECTION 6: TAB 2 - APPLICATION ANALYSIS
# ============================================================================
# Handles: Application upload, discrepancy detection

with tab2:
    st.header("🔍 Application Analysis - Discrepancy Detection")
    
    # ========================================================================
    # SECTION 6.1: ANALYSIS STATUS
    # ========================================================================
    render_analysis_status(
        rag_ready=st.session_state.rag_ready,
        summary_available=st.session_state.final_summary is not None,
        analysis_complete=st.session_state.analysis_result is not None,
        result=st.session_state.analysis_result.to_dict() if st.session_state.analysis_result else None
    )
    
    st.divider()
    
    # ========================================================================
    # SECTION 6.2: CHECK PREREQUISITES
    # ========================================================================
    if not st.session_state.rag_ready or not st.session_state.final_summary:
        st.warning(
            "⚠️ **Prerequisites not met:**\n\n"
            "1. Process medical records in the **Medical Summary** tab first\n"
            "2. Wait for RAG index to be built\n\n"
            "Then return here to analyze insurance applications."
        )
    else:
        # ====================================================================
        # SECTION 6.3: APPLICATION UPLOAD
        # ====================================================================
        application_file = render_application_uploader()
        
        # ====================================================================
        # SECTION 6.4: ANALYZE BUTTON
        # ====================================================================
        if application_file:
            col1, col2 = st.columns([1, 4])
            with col1:
                analyze_button = st.button(
                    "🔍 Analyze Application",
                    type="primary",
                    use_container_width=True,
                    disabled=st.session_state.analysis_in_progress
                )
            
            if analyze_button:
                st.session_state.analysis_in_progress = True
                
                # Prepare file data
                file_data = {
                    "name": application_file.name,
                    "content": application_file.read()
                }
                application_file.seek(0)
                
                # ============================================================
                # SECTION 6.5: RUN ANALYSIS PIPELINE
                # ============================================================
                progress_placeholder = st.empty()
                
                def update_analysis_progress(progress: dict):
                    with progress_placeholder.container():
                        render_analysis_progress(
                            step=progress.get("step", "Processing..."),
                            percent=progress.get("percent", 0)
                        )
                
                with st.spinner("Analyzing application against medical records..."):
                    result = analysis_service.analyze_application(
                        session_id=st.session_state.session_id,
                        application_file=file_data,
                        progress_callback=update_analysis_progress
                    )
                    
                    st.session_state.analysis_result = result
                    st.session_state.analysis_in_progress = False
                
                # Show completion message
                progress_placeholder.empty()
                
                if result.critical_count > 0:
                    st.error(
                        f"🚨 Analysis complete: Found **{result.critical_count} CRITICAL** "
                        f"and **{result.high_count} HIGH** severity discrepancies!"
                    )
                elif result.high_count > 0:
                    st.warning(
                        f"⚠️ Analysis complete: Found **{result.high_count} HIGH** "
                        f"severity discrepancies that require review."
                    )
                else:
                    st.success(
                        f"✅ Analysis complete: {result.total_fields_analyzed} fields analyzed. "
                        f"No critical or high severity issues found."
                    )
                
                st.rerun()
        
        # ====================================================================
        # SECTION 6.6: DISPLAY ANALYSIS RESULTS
        # ====================================================================
        if st.session_state.analysis_result:
            result = st.session_state.analysis_result
            result_dict = result.to_dict()
            
            st.divider()
            
            # Summary metrics
            render_discrepancy_summary(result_dict)
            
            st.divider()
            
            # Tabs for different views
            analysis_tab1, analysis_tab2 = st.tabs(["📋 Discrepancies", "📄 Extracted Fields"])
            
            with analysis_tab1:
                render_discrepancy_list(result_dict.get("discrepancies", []))
            
            with analysis_tab2:
                render_extracted_fields(result_dict.get("extracted_fields", []))
            
            st.divider()
            
            # Export buttons
            render_export_buttons(result_dict)
            
            # Reset button
            if st.button("🔄 Analyze New Application", use_container_width=False):
                st.session_state.analysis_result = None
                st.rerun()

# ============================================================================
# SECTION 7: TAB 3 - Q&A
# ============================================================================
# Handles: RAG-based question answering with citations

with tab3:
    st.header("💬 Q&A - Ask Questions About Medical Records")
    
    # ========================================================================
    # SECTION 7.1: Q&A STATUS
    # ========================================================================
    render_qa_status(
        rag_ready=st.session_state.rag_ready,
        summary_available=st.session_state.final_summary is not None,
        chunk_count=len(rag_service.chunks) if st.session_state.rag_ready else 0
    )
    
    st.divider()
    
    # ========================================================================
    # SECTION 7.2: CHECK IF READY
    # ========================================================================
    if not st.session_state.rag_ready or not st.session_state.final_summary:
        st.warning(
            "⚠️ Please process medical records first (in the Medical Summary tab) "
            "before using Q&A. This will build the search index needed for answering questions."
        )
    else:
        # ====================================================================
        # SECTION 7.3: CLEAR HISTORY BUTTON
        # ====================================================================
        col1, col2 = st.columns([4, 1])
        with col2:
            if st.button("🗑️ Clear Chat", use_container_width=True):
                st.session_state.chat_history = []
                qa_service.clear_history(st.session_state.session_id)
                st.rerun()
        
        # ====================================================================
        # SECTION 7.4: DISPLAY CHAT HISTORY
        # ====================================================================
        if st.session_state.chat_history:
            for msg in st.session_state.chat_history:
                render_chat_message(
                    role="user",
                    content=msg.get("question", "")
                )
                render_chat_message(
                    role="assistant",
                    content=msg.get("answer", ""),
                    citations=msg.get("citations", []),
                    confidence=msg.get("confidence")
                )
        else:
            st.info("👋 Ask a question about the medical records to get started!")
            
            # Show suggested questions
            if st.session_state.suggested_questions:
                st.write("**💡 Suggested Questions:**")
                cols = st.columns(min(len(st.session_state.suggested_questions), 3))
                for i, q in enumerate(st.session_state.suggested_questions[:3]):
                    with cols[i]:
                        if st.button(
                            q[:50] + "..." if len(q) > 50 else q,
                            key=f"suggested_{i}",
                            use_container_width=True
                        ):
                            st.session_state.pending_question = q
                            st.rerun()
        
        # ====================================================================
        # SECTION 7.5: CHAT INPUT
        # ====================================================================
        question = st.chat_input("Ask a question about the medical records...")
        
        # Check for pending question from suggested buttons
        if "pending_question" in st.session_state:
            question = st.session_state.pending_question
            del st.session_state.pending_question
        
        # ====================================================================
        # SECTION 7.6: PROCESS QUESTION
        # ====================================================================
        if question:
            # Display user message immediately
            render_chat_message(role="user", content=question)
            
            # Generate answer
            with st.spinner("Searching medical records..."):
                result = qa_service.answer_question(
                    session_id=st.session_state.session_id,
                    question=question
                )
                
                # Add to history
                st.session_state.chat_history.append(result.to_dict())
            
            # Display answer
            render_chat_message(
                role="assistant",
                content=result.answer,
                citations=result.citations,
                confidence=result.confidence
            )
            
            st.rerun()

# ============================================================================
# SECTION 8: TAB 4 - STATISTICS
# ============================================================================
# Handles: OCR stats (Table 1), Chunk stats (Table 2)

with tab4:
    st.header("📊 Processing Statistics")
    
    col1, col2 = st.columns(2)
    
    # ========================================================================
    # SECTION 8.1: TABLE 1 - OCR STATISTICS
    # ========================================================================
    with col1:
        render_ocr_stats_table(st.session_state.ocr_stats)
    
    # ========================================================================
    # SECTION 8.2: TABLE 2 - CHUNK STATISTICS
    # ========================================================================
    with col2:
        render_chunk_stats_table(st.session_state.chunk_stats)
    
    # ========================================================================
    # SECTION 8.3: OVERALL METRICS
    # ========================================================================
    if st.session_state.processing_status:
        st.divider()
        st.subheader("📈 Overall Metrics")
        
        status = st.session_state.processing_status
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric(
                "Total Processing Time",
                f"{status.total_processing_time:.2f}s"
            )
        with col2:
            st.metric(
                "Total Cost",
                f"${status.total_cost:.4f}"
            )
        with col3:
            st.metric(
                "PDFs Processed",
                len(status.uploaded_files)
            )
        with col4:
            cache_hits = sum(1 for s in status.chunk_stats if s.cache_hit)
            total_chunks = len(status.chunk_stats)
            st.metric(
                "Cache Hit Rate",
                f"{(cache_hits/max(total_chunks,1)*100):.1f}%"
            )

# ============================================================================
# SECTION 9: FOOTER
# ============================================================================

st.divider()
st.caption(
    "Medical Document Intelligence Dashboard | "
    f"Session: {st.session_state.session_id} | "
    f"© {datetime.now().year}"
)
