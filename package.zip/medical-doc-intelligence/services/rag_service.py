# ============================================================================
# RAG_SERVICE.PY - RAG (Retrieval Augmented Generation) Service
# ============================================================================
# Purpose: Build and query vector index for Q&A and Discrepancy Detection
#          - Uses FAISS with HNSW index for O(log n) retrieval
#          - Azure OpenAI embeddings (text-embedding-3-large)
#          - Contextual/Section-based chunking for medical documents
#          - Azure Blob Storage for index persistence
#          - Shared index for Q&A and Application Analysis
# Author: Medical Doc Intelligence Team
# ============================================================================

import asyncio
import time
import json
import pickle
import io
import tempfile
import os
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
import logging
import numpy as np

from openai import AzureOpenAI

from config.azure_config import openai_config
from config.settings import processing_settings, stats_settings
from utils.text_chunker import (
    rag_chunker, 
    TextChunk, 
    MedicalSectionType,
    contextual_chunker
)

# Setup logging
logger = logging.getLogger(__name__)

# ============================================================================
# SECTION 1: RAG CHUNK MODEL WITH CITATION AND SECTION INFO
# ============================================================================
# Model for storing chunks with full citation and section metadata

@dataclass
class RAGChunk:
    """
    RAG chunk with citation metadata and section information.
    Used for Q&A and Discrepancy Detection with contextual awareness.
    """
    chunk_id: int
    text: str
    
    # Citation metadata
    pdf_name: str
    page_number: int
    line_start: int
    line_end: int
    
    # Section metadata (for contextual retrieval)
    section_type: str = "unknown"  # MedicalSectionType value
    section_header: str = ""
    
    # Embedding (numpy array)
    embedding: Optional[np.ndarray] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary (without embedding for JSON)"""
        return {
            "chunk_id": self.chunk_id,
            "text": self.text,
            "pdf_name": self.pdf_name,
            "page_number": self.page_number,
            "line_start": self.line_start,
            "line_end": self.line_end,
            "section_type": self.section_type,
            "section_header": self.section_header
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RAGChunk":
        """Create from dictionary"""
        return cls(
            chunk_id=data["chunk_id"],
            text=data["text"],
            pdf_name=data["pdf_name"],
            page_number=data["page_number"],
            line_start=data["line_start"],
            line_end=data["line_end"],
            section_type=data.get("section_type", "unknown"),
            section_header=data.get("section_header", "")
        )
    
    def get_citation(self) -> str:
        """Get formatted citation string"""
        section_info = f" [{self.section_type}]" if self.section_type != "unknown" else ""
        return f"{self.pdf_name} | Page {self.page_number} | Lines {self.line_start}-{self.line_end}{section_info}"


@dataclass
class RetrievalResult:
    """
    Result from RAG retrieval with relevance score.
    """
    chunk: RAGChunk
    score: float  # Similarity score (higher = more relevant)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "text": self.chunk.text,
            "citation": self.chunk.get_citation(),
            "score": round(self.score, 4),
            "pdf_name": self.chunk.pdf_name,
            "page_number": self.chunk.page_number,
            "line_start": self.chunk.line_start,
            "line_end": self.chunk.line_end,
            "section_type": self.chunk.section_type,
            "section_header": self.chunk.section_header
        }


# ============================================================================
# SECTION 2: HNSW INDEX CONFIGURATION
# ============================================================================
# Configuration for FAISS HNSW index (optimal performance)

class HNSWConfig:
    """
    Configuration for FAISS HNSW index.
    HNSW = Hierarchical Navigable Small World graphs
    Provides O(log n) query time vs O(n) for brute force.
    """
    # Number of bi-directional links per element (higher = more accurate, more memory)
    M: int = 32
    
    # Size of dynamic candidate list during construction
    EF_CONSTRUCTION: int = 200
    
    # Size of dynamic candidate list during search (higher = more accurate, slower)
    EF_SEARCH: int = 128
    
    # Dimension for text-embedding-3-large
    DIMENSION: int = 3072


# ============================================================================
# SECTION 3: RAG SERVICE INITIALIZATION
# ============================================================================
# Initialize RAG service with FAISS HNSW and Azure OpenAI

class RAGService:
    """
    RAG service for building and querying vector index.
    
    Features:
    - FAISS with HNSW index for O(log n) retrieval
    - Contextual/Section-based chunking for medical documents
    - Azure Blob Storage for index persistence
    - Azure OpenAI embeddings (text-embedding-3-large)
    - Shared index for Q&A and Discrepancy Detection
    """
    
    def __init__(self):
        """Initialize RAG service"""
        self.endpoint = openai_config.ENDPOINT
        self.api_key = openai_config.API_KEY
        self.embedding_deployment = openai_config.EMBEDDING_DEPLOYMENT
        self.client: Optional[AzureOpenAI] = None
        
        # HNSW configuration
        self.hnsw_config = HNSWConfig()
        self.dimension = self.hnsw_config.DIMENSION
        
        # FAISS HNSW index (initialized when building)
        self.index = None
        self.chunks: List[RAGChunk] = []
        
        # Index metadata
        self.index_built: bool = False
        self.session_id: Optional[str] = None
        self.build_time: float = 0.0
        self.chunk_count: int = 0
        
        if self.endpoint and self.api_key:
            self._initialize_client()
    
    def _initialize_client(self):
        """Initialize Azure OpenAI client for embeddings"""
        try:
            self.client = AzureOpenAI(
                azure_endpoint=self.endpoint,
                api_key=self.api_key,
                api_version=openai_config.API_VERSION
            )
            logger.info("RAG service initialized with Azure OpenAI embeddings")
        except Exception as e:
            logger.error(f"Failed to initialize RAG service: {e}")
            raise

    # ========================================================================
    # SECTION 4: EMBEDDING GENERATION
    # ========================================================================
    # Generate embeddings using Azure OpenAI
    
    def generate_embedding(self, text: str) -> np.ndarray:
        """
        Generate embedding for a single text.
        
        Args:
            text: Text to embed
            
        Returns:
            np.ndarray: Embedding vector (3072 dimensions)
        """
        try:
            response = self.client.embeddings.create(
                model=self.embedding_deployment,
                input=text
            )
            embedding = np.array(response.data[0].embedding, dtype=np.float32)
            return embedding
        except Exception as e:
            logger.error(f"Failed to generate embedding: {e}")
            raise
    
    def generate_embeddings_batch(
        self, 
        texts: List[str],
        batch_size: int = 100
    ) -> List[np.ndarray]:
        """
        Generate embeddings for multiple texts in batches.
        
        Args:
            texts: List of texts to embed
            batch_size: Number of texts per API call
            
        Returns:
            List[np.ndarray]: List of embedding vectors
        """
        all_embeddings = []
        total_batches = (len(texts) + batch_size - 1) // batch_size
        
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            batch_num = i // batch_size + 1
            
            try:
                response = self.client.embeddings.create(
                    model=self.embedding_deployment,
                    input=batch
                )
                
                batch_embeddings = [
                    np.array(item.embedding, dtype=np.float32)
                    for item in response.data
                ]
                all_embeddings.extend(batch_embeddings)
                
                logger.info(f"Generated embeddings batch {batch_num}/{total_batches}")
                
            except Exception as e:
                logger.error(f"Failed to generate embeddings for batch: {e}")
                # Add zero vectors for failed batch
                all_embeddings.extend([
                    np.zeros(self.dimension, dtype=np.float32)
                    for _ in batch
                ])
        
        return all_embeddings

    # ========================================================================
    # SECTION 5: BUILD RAG INDEX FROM OCR RESULTS
    # ========================================================================
    # Create FAISS HNSW index with contextual chunking
    
    def build_index_from_ocr(
        self,
        ocr_citations: List[Dict[str, Any]],
        session_id: str
    ) -> int:
        """
        Build FAISS HNSW index from OCR citations.
        
        SECTION: RAG Index Creation with HNSW
        - Contextual/Section-based chunking (preserves medical sections)
        - HNSW index for O(log n) retrieval performance
        - Azure OpenAI text-embedding-3-large
        - Persistent storage to Azure Blob
        
        Args:
            ocr_citations: List of dicts with text and citation metadata
            session_id: Session identifier for saving index
            
        Returns:
            int: Number of chunks indexed
        """
        import faiss
        
        logger.info(f"Building RAG HNSW index from {len(ocr_citations)} OCR items")
        start_time = time.time()
        
        # ----------------------------------------------------------------
        # STEP 5.1: Create contextual chunks from OCR
        # Uses section-based chunking to keep related content together
        # ----------------------------------------------------------------
        text_chunks = contextual_chunker.chunk_with_context(ocr_citations)
        
        # Convert TextChunk to RAGChunk with section metadata
        self.chunks = []
        for tc in text_chunks:
            rag_chunk = RAGChunk(
                chunk_id=tc.chunk_id,
                text=tc.text,
                pdf_name=tc.source_files[0] if tc.source_files else "",
                page_number=tc.start_page,
                line_start=tc.start_line,
                line_end=tc.end_line,
                section_type=tc.section_type.value if hasattr(tc, 'section_type') else "unknown",
                section_header=tc.section_header if hasattr(tc, 'section_header') else ""
            )
            self.chunks.append(rag_chunk)
        
        logger.info(f"Created {len(self.chunks)} contextual RAG chunks")
        
        # ----------------------------------------------------------------
        # STEP 5.2: Generate embeddings for all chunks
        # ----------------------------------------------------------------
        chunk_texts = [chunk.text for chunk in self.chunks]
        embeddings = self.generate_embeddings_batch(chunk_texts)
        
        # Assign embeddings to chunks
        for chunk, embedding in zip(self.chunks, embeddings):
            chunk.embedding = embedding
        
        # ----------------------------------------------------------------
        # STEP 5.3: Build FAISS HNSW Index
        # HNSW provides O(log n) query time for optimal performance
        # ----------------------------------------------------------------
        embeddings_matrix = np.vstack(embeddings).astype(np.float32)
        
        # Normalize for cosine similarity
        faiss.normalize_L2(embeddings_matrix)
        
        # Create HNSW index
        # IndexHNSWFlat: HNSW graph + flat storage
        self.index = faiss.IndexHNSWFlat(
            self.dimension,           # Vector dimension
            self.hnsw_config.M        # Number of connections per layer
        )
        
        # Set construction-time parameters
        self.index.hnsw.efConstruction = self.hnsw_config.EF_CONSTRUCTION
        
        # Set search-time parameters
        self.index.hnsw.efSearch = self.hnsw_config.EF_SEARCH
        
        # Add vectors to index
        self.index.add(embeddings_matrix)
        
        logger.info(
            f"FAISS HNSW index built: "
            f"{self.index.ntotal} vectors, "
            f"M={self.hnsw_config.M}, "
            f"efConstruction={self.hnsw_config.EF_CONSTRUCTION}"
        )
        
        # ----------------------------------------------------------------
        # STEP 5.4: Save index to Azure Blob Storage
        # ----------------------------------------------------------------
        self._save_index_to_blob(session_id)
        
        # Update metadata
        self.session_id = session_id
        self.index_built = True
        self.build_time = time.time() - start_time
        self.chunk_count = len(self.chunks)
        
        logger.info(f"RAG HNSW index built in {self.build_time:.2f}s")
        
        return len(self.chunks)
    
    # ========================================================================
    # SECTION 6: AZURE BLOB STORAGE OPERATIONS
    # ========================================================================
    # Save and load FAISS index from Azure Blob Storage
    
    def _save_index_to_blob(self, session_id: str):
        """
        Save FAISS HNSW index and chunks metadata to Azure Blob Storage.
        
        Storage structure:
        - {session_id}/rag/chunks_metadata.json  (chunk text + metadata)
        - {session_id}/rag/faiss_hnsw_index.bin  (serialized FAISS index)
        - {session_id}/rag/index_config.json     (index configuration)
        """
        import faiss
        from services.blob_service import blob_service
        
        try:
            # ----------------------------------------------------------------
            # Save chunks metadata (without embeddings)
            # ----------------------------------------------------------------
            chunks_meta = [chunk.to_dict() for chunk in self.chunks]
            blob_service.container_client.get_blob_client(
                f"{session_id}/rag/chunks_metadata.json"
            ).upload_blob(
                json.dumps(chunks_meta, indent=2, ensure_ascii=False).encode('utf-8'),
                overwrite=True
            )
            
            # ----------------------------------------------------------------
            # Save FAISS HNSW index
            # ----------------------------------------------------------------
            index_bytes = faiss.serialize_index(self.index)
            blob_service.container_client.get_blob_client(
                f"{session_id}/rag/faiss_hnsw_index.bin"
            ).upload_blob(
                bytes(index_bytes),
                overwrite=True
            )
            
            # ----------------------------------------------------------------
            # Save index configuration
            # ----------------------------------------------------------------
            config = {
                "index_type": "HNSW",
                "dimension": self.dimension,
                "M": self.hnsw_config.M,
                "efConstruction": self.hnsw_config.EF_CONSTRUCTION,
                "efSearch": self.hnsw_config.EF_SEARCH,
                "chunk_count": len(self.chunks),
                "build_time": self.build_time,
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            blob_service.container_client.get_blob_client(
                f"{session_id}/rag/index_config.json"
            ).upload_blob(
                json.dumps(config, indent=2).encode('utf-8'),
                overwrite=True
            )
            
            logger.info(f"RAG HNSW index saved to Blob Storage: {session_id}/rag/")
            
        except Exception as e:
            logger.error(f"Failed to save RAG index to Blob: {e}")
            raise
    
    def load_index_from_blob(self, session_id: str) -> bool:
        """
        Load existing RAG HNSW index from Azure Blob Storage.
        
        Args:
            session_id: Session identifier
            
        Returns:
            bool: True if loaded successfully
        """
        import faiss
        from services.blob_service import blob_service
        
        try:
            # ----------------------------------------------------------------
            # Load index configuration
            # ----------------------------------------------------------------
            config_blob = blob_service.container_client.get_blob_client(
                f"{session_id}/rag/index_config.json"
            )
            config = json.loads(
                config_blob.download_blob().readall().decode('utf-8')
            )
            logger.info(f"Loading RAG index: {config}")
            
            # ----------------------------------------------------------------
            # Load chunks metadata
            # ----------------------------------------------------------------
            meta_blob = blob_service.container_client.get_blob_client(
                f"{session_id}/rag/chunks_metadata.json"
            )
            chunks_data = json.loads(
                meta_blob.download_blob().readall().decode('utf-8')
            )
            
            self.chunks = [RAGChunk.from_dict(c) for c in chunks_data]
            
            # ----------------------------------------------------------------
            # Load FAISS HNSW index
            # ----------------------------------------------------------------
            index_blob = blob_service.container_client.get_blob_client(
                f"{session_id}/rag/faiss_hnsw_index.bin"
            )
            index_bytes = index_blob.download_blob().readall()
            self.index = faiss.deserialize_index(
                np.frombuffer(index_bytes, dtype=np.uint8)
            )
            
            # Set search parameters
            self.index.hnsw.efSearch = self.hnsw_config.EF_SEARCH
            
            # Update metadata
            self.session_id = session_id
            self.index_built = True
            self.chunk_count = len(self.chunks)
            self.build_time = config.get("build_time", 0.0)
            
            logger.info(
                f"Loaded RAG HNSW index: "
                f"{len(self.chunks)} chunks, "
                f"{self.index.ntotal} vectors"
            )
            return True
            
        except Exception as e:
            logger.warning(f"Failed to load RAG index from Blob: {e}")
            return False
    
    def check_index_exists(self, session_id: str) -> bool:
        """
        Check if a RAG index exists in Blob Storage for this session.
        
        Args:
            session_id: Session identifier
            
        Returns:
            bool: True if index exists
        """
        from services.blob_service import blob_service
        
        try:
            config_blob = blob_service.container_client.get_blob_client(
                f"{session_id}/rag/index_config.json"
            )
            return config_blob.exists()
        except Exception:
            return False

    # ========================================================================
    # SECTION 7: SEMANTIC SEARCH / RETRIEVAL
    # ========================================================================
    # Query the HNSW index and retrieve relevant chunks with citations
    
    def search(
        self,
        query: str,
        top_k: int = None,
        section_filter: Optional[str] = None
    ) -> List[RetrievalResult]:
        """
        Search for relevant chunks using semantic similarity.
        
        SECTION: RAG retrieval with HNSW
        - Embed query using Azure OpenAI
        - HNSW search → O(log n) approximate nearest neighbors
        - Each chunk has section metadata and citations
        - Optional section type filtering
        
        Args:
            query: User question or search query
            top_k: Number of results to return
            section_filter: Optional section type to filter results
            
        Returns:
            List[RetrievalResult]: Ranked results with citations
        """
        import faiss
        
        if self.index is None or not self.chunks:
            logger.error("RAG index not initialized")
            return []
        
        if top_k is None:
            top_k = processing_settings.RAG_TOP_K_RESULTS
        
        # ----------------------------------------------------------------
        # STEP 7.1: Generate query embedding
        # ----------------------------------------------------------------
        query_embedding = self.generate_embedding(query)
        query_embedding = query_embedding.reshape(1, -1).astype(np.float32)
        faiss.normalize_L2(query_embedding)
        
        # ----------------------------------------------------------------
        # STEP 7.2: Search HNSW index (O(log n) complexity)
        # ----------------------------------------------------------------
        # Request more results if filtering
        search_k = top_k * 3 if section_filter else top_k
        scores, indices = self.index.search(query_embedding, search_k)
        
        # ----------------------------------------------------------------
        # STEP 7.3: Build results with citations and section info
        # ----------------------------------------------------------------
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < len(self.chunks):
                chunk = self.chunks[idx]
                
                # Apply section filter if specified
                if section_filter and chunk.section_type != section_filter:
                    continue
                
                results.append(RetrievalResult(
                    chunk=chunk,
                    score=float(score)
                ))
                
                if len(results) >= top_k:
                    break
        
        logger.info(f"Retrieved {len(results)} chunks for query")
        return results
    
    def search_by_section(
        self,
        query: str,
        section_types: List[str],
        top_k: int = 5
    ) -> Dict[str, List[RetrievalResult]]:
        """
        Search within specific medical sections.
        
        Args:
            query: Search query
            section_types: List of section types to search in
            top_k: Results per section
            
        Returns:
            Dict mapping section type to results
        """
        results_by_section = {}
        
        for section_type in section_types:
            results = self.search(
                query=query,
                top_k=top_k,
                section_filter=section_type
            )
            results_by_section[section_type] = results
        
        return results_by_section

    # ========================================================================
    # SECTION 8: SEARCH FOR DISCREPANCY DETECTION
    # ========================================================================
    # Specialized search for finding evidence about specific conditions
    
    def search_for_condition(
        self,
        condition: str,
        top_k: int = 5
    ) -> List[RetrievalResult]:
        """
        Search for evidence about a specific medical condition.
        Used for discrepancy detection between application and records.
        
        Args:
            condition: Medical condition to search for
            top_k: Number of results
            
        Returns:
            List[RetrievalResult]: Evidence with citations
        """
        # Construct comprehensive search query
        query = f"medical records evidence of {condition}, diagnosis, treatment, medication, or mention of {condition}"
        
        return self.search(query, top_k)
    
    def search_for_field(
        self,
        field_name: str,
        field_value: str,
        top_k: int = 5
    ) -> List[RetrievalResult]:
        """
        Search for evidence about a specific application field.
        Used for verifying application form data.
        
        Args:
            field_name: Name of the field (e.g., "Date of Birth", "Diagnosis")
            field_value: Value to verify
            top_k: Number of results
            
        Returns:
            List[RetrievalResult]: Evidence with citations
        """
        query = f"{field_name}: {field_value}, medical record verification"
        
        return self.search(query, top_k)
    
    # ========================================================================
    # SECTION 9: INDEX STATISTICS
    # ========================================================================
    # Get statistics about the current index
    
    def get_index_stats(self) -> Dict[str, Any]:
        """
        Get statistics about the current RAG index.
        
        Returns:
            Dict with index statistics
        """
        if not self.index_built:
            return {"status": "not_built"}
        
        # Count chunks by section type
        section_counts = {}
        for chunk in self.chunks:
            section_type = chunk.section_type
            section_counts[section_type] = section_counts.get(section_type, 0) + 1
        
        return {
            "status": "ready",
            "session_id": self.session_id,
            "index_type": "HNSW",
            "total_chunks": self.chunk_count,
            "total_vectors": self.index.ntotal if self.index else 0,
            "dimension": self.dimension,
            "hnsw_M": self.hnsw_config.M,
            "hnsw_efSearch": self.hnsw_config.EF_SEARCH,
            "build_time_seconds": round(self.build_time, 2),
            "section_distribution": section_counts
        }


# ============================================================================
# SECTION 10: SINGLETON INSTANCE
# ============================================================================
# Global instance for easy import

rag_service = RAGService()
