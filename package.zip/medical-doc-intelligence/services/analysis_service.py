# ============================================================================
# ANALYSIS_SERVICE.PY - Application Analysis & Discrepancy Detection
# ============================================================================
# Purpose: Compare insurance application with medical records to detect
#          discrepancies. Uses RAG for evidence retrieval with citations.
#          
# Flow:
#   1. Upload application PDF
#   2. OCR extract application text
#   3. GPT-4o extracts structured fields
#   4. For each field: RAG search medical records
#   5. GPT compares application vs medical evidence
#   6. Generate discrepancy report with citations
#
# Author: Medical Doc Intelligence Team
# ============================================================================

import asyncio
import time
import json
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import logging

from openai import AzureOpenAI

from config.azure_config import openai_config
from config.settings import llm_settings, blob_paths
from services.blob_service import blob_service
from services.ocr_service import ocr_service
from services.rag_service import rag_service, RetrievalResult

# Setup logging
logger = logging.getLogger(__name__)


# ============================================================================
# SECTION 1: DISCREPANCY TYPES & MODELS
# ============================================================================
# Define discrepancy severity and data models

class DiscrepancySeverity(Enum):
    """Severity levels for discrepancies"""
    CRITICAL = "critical"      # Major contradiction (e.g., denies condition that exists)
    HIGH = "high"              # Significant mismatch (e.g., wrong dates, medications)
    MEDIUM = "medium"          # Partial mismatch (e.g., incomplete information)
    LOW = "low"                # Minor discrepancy (e.g., spelling differences)
    INFO = "info"              # Informational (e.g., additional info in records)
    MATCH = "match"            # No discrepancy found


class FieldCategory(Enum):
    """Categories of application fields"""
    PERSONAL = "personal"           # Name, DOB, SSN, Address
    MEDICAL_HISTORY = "medical_history"  # Diagnoses, conditions
    MEDICATIONS = "medications"     # Current/past medications
    PROCEDURES = "procedures"       # Surgeries, treatments
    LIFESTYLE = "lifestyle"         # Smoking, alcohol, drugs
    FAMILY_HISTORY = "family_history"
    INSURANCE = "insurance"


@dataclass
class ApplicationField:
    """
    Represents a field extracted from the insurance application.
    """
    field_name: str
    field_value: str
    category: FieldCategory
    page_number: int = 0
    confidence: float = 1.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "field_name": self.field_name,
            "field_value": self.field_value,
            "category": self.category.value,
            "page_number": self.page_number,
            "confidence": round(self.confidence, 2)
        }


@dataclass
class Discrepancy:
    """
    Represents a discrepancy between application and medical records.
    """
    field_name: str
    application_value: str
    medical_record_value: str
    severity: DiscrepancySeverity
    explanation: str
    
    # Citation from medical records
    citations: List[Dict[str, Any]] = field(default_factory=list)
    
    # Category
    category: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "field_name": self.field_name,
            "application_value": self.application_value,
            "medical_record_value": self.medical_record_value,
            "severity": self.severity.value,
            "explanation": self.explanation,
            "citations": self.citations,
            "category": self.category
        }
    
    def get_citation_string(self) -> str:
        """Get formatted citation string"""
        if not self.citations:
            return "No citation available"
        
        citation = self.citations[0]
        return f"{citation.get('pdf_name', 'Unknown')} | Page {citation.get('page_number', '?')} | Lines {citation.get('line_start', '?')}-{citation.get('line_end', '?')}"


@dataclass
class AnalysisResult:
    """
    Complete analysis result with all discrepancies.
    """
    session_id: str
    application_filename: str
    
    # Extracted fields
    extracted_fields: List[ApplicationField] = field(default_factory=list)
    
    # All discrepancies found
    discrepancies: List[Discrepancy] = field(default_factory=list)
    
    # Summary stats
    total_fields_analyzed: int = 0
    critical_count: int = 0
    high_count: int = 0
    medium_count: int = 0
    low_count: int = 0
    match_count: int = 0
    
    # Processing info
    processing_time_seconds: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "application_filename": self.application_filename,
            "extracted_fields": [f.to_dict() for f in self.extracted_fields],
            "discrepancies": [d.to_dict() for d in self.discrepancies],
            "summary": {
                "total_fields_analyzed": self.total_fields_analyzed,
                "critical_count": self.critical_count,
                "high_count": self.high_count,
                "medium_count": self.medium_count,
                "low_count": self.low_count,
                "match_count": self.match_count
            },
            "processing_time_seconds": round(self.processing_time_seconds, 2),
            "timestamp": self.timestamp
        }
    
    def update_counts(self):
        """Update severity counts from discrepancies"""
        self.critical_count = sum(1 for d in self.discrepancies if d.severity == DiscrepancySeverity.CRITICAL)
        self.high_count = sum(1 for d in self.discrepancies if d.severity == DiscrepancySeverity.HIGH)
        self.medium_count = sum(1 for d in self.discrepancies if d.severity == DiscrepancySeverity.MEDIUM)
        self.low_count = sum(1 for d in self.discrepancies if d.severity == DiscrepancySeverity.LOW)
        self.match_count = sum(1 for d in self.discrepancies if d.severity == DiscrepancySeverity.MATCH)


# ============================================================================
# SECTION 2: ANALYSIS SERVICE
# ============================================================================
# Main service for application analysis and discrepancy detection

class AnalysisService:
    """
    Service for analyzing insurance applications against medical records.
    
    Features:
    - Extract structured fields from application PDF
    - Search medical records for each field using RAG
    - Compare and detect discrepancies
    - Generate citations for each finding
    """
    
    def __init__(self):
        """Initialize analysis service"""
        self.endpoint = openai_config.ENDPOINT
        self.api_key = openai_config.API_KEY
        self.gpt4o_deployment = openai_config.GPT4O_DEPLOYMENT
        self.gpt5_deployment = openai_config.GPT5_DEPLOYMENT
        self.client: Optional[AzureOpenAI] = None
        
        if self.endpoint and self.api_key:
            self._initialize_client()
    
    def _initialize_client(self):
        """Initialize Azure OpenAI client"""
        try:
            self.client = AzureOpenAI(
                azure_endpoint=self.endpoint,
                api_key=self.api_key,
                api_version=openai_config.API_VERSION
            )
            logger.info("Analysis service initialized")
        except Exception as e:
            logger.error(f"Failed to initialize Analysis service: {e}")
            raise

    # ========================================================================
    # SECTION 3: EXTRACT APPLICATION FIELDS
    # ========================================================================
    # Use GPT-4o to extract structured fields from application
    
    def _get_extraction_prompt(self) -> str:
        """Get system prompt for field extraction"""
        return """You are an expert at extracting information from insurance application forms.

Extract all relevant fields from the application and return them as a JSON array.

## Fields to Extract:

### Personal Information:
- Full Name
- Date of Birth
- Social Security Number (last 4 digits only)
- Address
- Phone Number
- Email

### Medical History (CRITICAL - extract ALL):
- Current diagnoses/conditions
- Past diagnoses/conditions
- Chronic conditions
- Mental health conditions
- Any condition the applicant denies having

### Medications:
- Current medications
- Past medications
- Dosages if mentioned

### Procedures/Surgeries:
- Past surgeries
- Planned surgeries
- Medical procedures

### Lifestyle:
- Tobacco/smoking status
- Alcohol use
- Drug use
- Exercise habits

### Family History:
- Family medical conditions

## Output Format:
Return a JSON array of objects, each with:
{
  "field_name": "Name of the field",
  "field_value": "Value from application (exact as written)",
  "category": "personal|medical_history|medications|procedures|lifestyle|family_history|insurance",
  "page_number": 1
}

## Important:
- Extract EXACT values as written in the application
- For yes/no questions, note what was answered
- If applicant denies a condition, record as "Denied: [condition]"
- Include ALL medical history fields, especially denials"""

    def extract_application_fields(
        self,
        application_text: str,
        filename: str
    ) -> List[ApplicationField]:
        """
        Extract structured fields from application text.
        
        SECTION: GPT-4o extracts application fields
        - Uses structured extraction prompt
        - Returns list of field name/value pairs with categories
        
        Args:
            application_text: OCR text from application PDF
            filename: Application filename
            
        Returns:
            List[ApplicationField]: Extracted fields
        """
        logger.info(f"Extracting fields from application: {filename}")
        
        try:
            response = self.client.chat.completions.create(
                model=self.gpt4o_deployment,
                messages=[
                    {"role": "system", "content": self._get_extraction_prompt()},
                    {"role": "user", "content": f"Extract all fields from this insurance application:\n\n{application_text}"}
                ],
                temperature=llm_settings.EXTRACTION_TEMPERATURE,
                max_tokens=4096,
                response_format={"type": "json_object"}
            )
            
            # Parse response
            content = response.choices[0].message.content
            data = json.loads(content)
            
            # Handle different response formats
            fields_data = data.get("fields", data) if isinstance(data, dict) else data
            if isinstance(fields_data, dict):
                fields_data = [fields_data]
            
            # Convert to ApplicationField objects
            fields = []
            for item in fields_data:
                try:
                    category = FieldCategory(item.get("category", "personal"))
                except ValueError:
                    category = FieldCategory.PERSONAL
                
                field = ApplicationField(
                    field_name=item.get("field_name", ""),
                    field_value=item.get("field_value", ""),
                    category=category,
                    page_number=item.get("page_number", 0),
                    confidence=item.get("confidence", 1.0)
                )
                if field.field_name and field.field_value:
                    fields.append(field)
            
            logger.info(f"Extracted {len(fields)} fields from application")
            return fields
            
        except Exception as e:
            logger.error(f"Failed to extract fields: {e}")
            return []

    # ========================================================================
    # SECTION 4: COMPARE FIELD WITH MEDICAL RECORDS
    # ========================================================================
    # Use RAG to find evidence and compare
    
    def _get_comparison_prompt(self) -> str:
        """Get system prompt for comparison"""
        return """You are an expert medical underwriter comparing insurance applications against medical records.

Your task is to determine if the application field matches or contradicts the medical records.

## Analysis Process:
1. Review the application field and its value
2. Examine the medical record evidence provided
3. Determine if there is a match, discrepancy, or insufficient evidence

## Severity Levels:
- CRITICAL: Applicant denied a condition that clearly exists in records
- HIGH: Significant mismatch (wrong dates, missing major conditions/medications)
- MEDIUM: Partial mismatch (incomplete information, minor conditions omitted)
- LOW: Minor discrepancy (spelling, formatting differences)
- MATCH: No discrepancy found
- INFO: Additional information in records not asked in application

## Output Format (JSON):
{
  "severity": "critical|high|medium|low|match|info",
  "medical_record_value": "What the medical records actually show",
  "explanation": "Clear explanation of the finding",
  "confidence": 0.95
}

## Important:
- Be precise and factual
- Only flag discrepancies you can clearly support from the evidence
- If evidence is insufficient, mark as "match" with low confidence
- Consider that medical records may use different terminology"""

    def compare_field_with_records(
        self,
        field: ApplicationField,
        retrieval_results: List[RetrievalResult]
    ) -> Discrepancy:
        """
        Compare a single application field against medical record evidence.
        
        SECTION: GPT compares application values vs. medical record values
        
        Args:
            field: Application field to verify
            retrieval_results: RAG results from medical records
            
        Returns:
            Discrepancy: Comparison result with severity and citation
        """
        # Build evidence context from retrieval results
        evidence_parts = []
        for i, result in enumerate(retrieval_results):
            evidence_parts.append(
                f"[Evidence {i+1}]\n"
                f"Source: {result.chunk.get_citation()}\n"
                f"Section Type: {result.chunk.section_type}\n"
                f"Content: {result.chunk.text}\n"
            )
        
        evidence_context = "\n---\n".join(evidence_parts) if evidence_parts else "No relevant evidence found in medical records."
        
        # Create comparison prompt
        user_message = f"""Compare this application field against the medical record evidence:

## Application Field:
- Field Name: {field.field_name}
- Field Value: {field.field_value}
- Category: {field.category.value}

## Medical Record Evidence:
{evidence_context}

Analyze and return your finding as JSON."""

        try:
            response = self.client.chat.completions.create(
                model=self.gpt5_deployment,
                messages=[
                    {"role": "system", "content": self._get_comparison_prompt()},
                    {"role": "user", "content": user_message}
                ],
                temperature=0.1,
                max_tokens=1024,
                response_format={"type": "json_object"}
            )
            
            # Parse response
            content = response.choices[0].message.content
            result = json.loads(content)
            
            # Map severity
            severity_map = {
                "critical": DiscrepancySeverity.CRITICAL,
                "high": DiscrepancySeverity.HIGH,
                "medium": DiscrepancySeverity.MEDIUM,
                "low": DiscrepancySeverity.LOW,
                "match": DiscrepancySeverity.MATCH,
                "info": DiscrepancySeverity.INFO
            }
            severity = severity_map.get(
                result.get("severity", "match").lower(),
                DiscrepancySeverity.MATCH
            )
            
            # Build citations from retrieval results
            citations = [r.to_dict() for r in retrieval_results[:3]]
            
            return Discrepancy(
                field_name=field.field_name,
                application_value=field.field_value,
                medical_record_value=result.get("medical_record_value", "Not found"),
                severity=severity,
                explanation=result.get("explanation", ""),
                citations=citations,
                category=field.category.value
            )
            
        except Exception as e:
            logger.error(f"Failed to compare field {field.field_name}: {e}")
            return Discrepancy(
                field_name=field.field_name,
                application_value=field.field_value,
                medical_record_value="Error during comparison",
                severity=DiscrepancySeverity.INFO,
                explanation=f"Comparison failed: {str(e)}",
                citations=[],
                category=field.category.value
            )

    # ========================================================================
    # SECTION 5: FULL ANALYSIS PIPELINE
    # ========================================================================
    # Run complete analysis on application
    
    def analyze_application(
        self,
        session_id: str,
        application_file: Dict[str, Any],
        progress_callback: Optional[callable] = None
    ) -> AnalysisResult:
        """
        Run complete analysis pipeline on insurance application.
        
        SECTION: Application Analysis Pipeline
        1. Upload application PDF to Blob
        2. OCR extract application text
        3. Extract structured fields with GPT-4o
        4. For each field: RAG search + GPT comparison
        5. Generate discrepancy report with citations
        
        Args:
            session_id: Session identifier
            application_file: Dict with 'name' and 'content'
            progress_callback: Optional callback for progress updates
            
        Returns:
            AnalysisResult: Complete analysis with discrepancies
        """
        start_time = time.time()
        filename = application_file["name"]
        
        result = AnalysisResult(
            session_id=session_id,
            application_filename=filename
        )
        
        def update_progress(step: str, percent: float):
            if progress_callback:
                progress_callback({"step": step, "percent": percent})
        
        try:
            # ----------------------------------------------------------------
            # STEP 1: Upload application to Blob
            # ----------------------------------------------------------------
            update_progress("Uploading application PDF", 5)
            
            app_blob_path = f"{session_id}/application/{filename}"
            blob_service.container_client.get_blob_client(app_blob_path).upload_blob(
                application_file["content"],
                overwrite=True
            )
            logger.info(f"Uploaded application: {app_blob_path}")
            
            # ----------------------------------------------------------------
            # STEP 2: OCR extract application text
            # ----------------------------------------------------------------
            update_progress("Extracting text from application (OCR)", 15)
            
            ocr_result = ocr_service.process_single_pdf(
                pdf_content=application_file["content"],
                pdf_name=filename
            )
            
            application_text = ocr_result.get_full_text()
            logger.info(f"OCR extracted {len(application_text)} characters")
            
            # ----------------------------------------------------------------
            # STEP 3: Extract structured fields
            # ----------------------------------------------------------------
            update_progress("Extracting application fields (GPT-4o)", 30)
            
            fields = self.extract_application_fields(application_text, filename)
            result.extracted_fields = fields
            result.total_fields_analyzed = len(fields)
            
            logger.info(f"Extracted {len(fields)} fields to analyze")
            
            # ----------------------------------------------------------------
            # STEP 4: Ensure RAG index is loaded
            # ----------------------------------------------------------------
            update_progress("Loading medical records index", 40)
            
            if not rag_service.index_built:
                loaded = rag_service.load_index_from_blob(session_id)
                if not loaded:
                    logger.error("RAG index not available")
                    result.discrepancies.append(Discrepancy(
                        field_name="System Error",
                        application_value="",
                        medical_record_value="",
                        severity=DiscrepancySeverity.INFO,
                        explanation="Medical records not processed. Please process medical records first.",
                        citations=[]
                    ))
                    return result
            
            # ----------------------------------------------------------------
            # STEP 5: Compare each field with medical records
            # ----------------------------------------------------------------
            total_fields = len(fields)
            for i, field in enumerate(fields):
                progress_pct = 40 + (50 * (i + 1) / max(total_fields, 1))
                update_progress(f"Analyzing field: {field.field_name}", progress_pct)
                
                # RAG search for evidence
                search_query = f"{field.field_name}: {field.field_value}"
                retrieval_results = rag_service.search(search_query, top_k=5)
                
                # Compare with evidence
                discrepancy = self.compare_field_with_records(field, retrieval_results)
                result.discrepancies.append(discrepancy)
                
                logger.debug(
                    f"Field '{field.field_name}': {discrepancy.severity.value}"
                )
            
            # ----------------------------------------------------------------
            # STEP 6: Finalize results
            # ----------------------------------------------------------------
            update_progress("Generating report", 95)
            
            result.update_counts()
            result.processing_time_seconds = time.time() - start_time
            
            # Save results to Blob
            self._save_analysis_result(session_id, result)
            
            update_progress("Analysis complete", 100)
            
            logger.info(
                f"Analysis complete: "
                f"{result.total_fields_analyzed} fields, "
                f"{result.critical_count} critical, "
                f"{result.high_count} high severity"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Analysis failed: {e}")
            result.discrepancies.append(Discrepancy(
                field_name="System Error",
                application_value="",
                medical_record_value="",
                severity=DiscrepancySeverity.INFO,
                explanation=f"Analysis failed: {str(e)}",
                citations=[]
            ))
            result.processing_time_seconds = time.time() - start_time
            return result
    
    def _save_analysis_result(self, session_id: str, result: AnalysisResult):
        """Save analysis result to Blob Storage"""
        try:
            blob_path = f"{session_id}/analysis/discrepancy_report.json"
            blob_service.container_client.get_blob_client(blob_path).upload_blob(
                json.dumps(result.to_dict(), indent=2).encode('utf-8'),
                overwrite=True
            )
            logger.info(f"Saved analysis result: {blob_path}")
        except Exception as e:
            logger.warning(f"Failed to save analysis result: {e}")

    # ========================================================================
    # SECTION 6: LOAD PREVIOUS ANALYSIS
    # ========================================================================
    # Load previously saved analysis result
    
    def load_analysis_result(self, session_id: str) -> Optional[AnalysisResult]:
        """
        Load previously saved analysis result.
        
        Args:
            session_id: Session identifier
            
        Returns:
            AnalysisResult or None if not found
        """
        try:
            blob_path = f"{session_id}/analysis/discrepancy_report.json"
            blob_client = blob_service.container_client.get_blob_client(blob_path)
            
            if not blob_client.exists():
                return None
            
            data = json.loads(blob_client.download_blob().readall().decode('utf-8'))
            
            # Reconstruct result object
            result = AnalysisResult(
                session_id=data["session_id"],
                application_filename=data["application_filename"],
                total_fields_analyzed=data["summary"]["total_fields_analyzed"],
                critical_count=data["summary"]["critical_count"],
                high_count=data["summary"]["high_count"],
                medium_count=data["summary"]["medium_count"],
                low_count=data["summary"]["low_count"],
                match_count=data["summary"]["match_count"],
                processing_time_seconds=data["processing_time_seconds"],
                timestamp=data["timestamp"]
            )
            
            # Reconstruct discrepancies
            for d in data.get("discrepancies", []):
                severity = DiscrepancySeverity(d["severity"])
                result.discrepancies.append(Discrepancy(
                    field_name=d["field_name"],
                    application_value=d["application_value"],
                    medical_record_value=d["medical_record_value"],
                    severity=severity,
                    explanation=d["explanation"],
                    citations=d.get("citations", []),
                    category=d.get("category", "")
                ))
            
            return result
            
        except Exception as e:
            logger.warning(f"Failed to load analysis result: {e}")
            return None


# ============================================================================
# SECTION 7: SINGLETON INSTANCE
# ============================================================================
# Global instance for easy import

analysis_service = AnalysisService()
