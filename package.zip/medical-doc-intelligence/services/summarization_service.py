# ============================================================================
# SUMMARIZATION_SERVICE.PY - Medical Record Summarization Orchestrator
# ============================================================================
# Purpose: Orchestrate the complete PART 1 flow:
#          1. User uploads PDFs
#          2. Parallel OCR processing
#          3. Combine OCR outputs
#          4. Sliding window chunking
#          5. Parallel GPT-5 summarization with prompt caching
#          6. Final summary generation
#          7. RAG index creation
# Author: Medical Doc Intelligence Team
# ============================================================================

import asyncio
import time
from typing import List, Dict, Any, Optional, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime
import logging

from services.blob_service import blob_service
from services.ocr_service import ocr_service, OCRService
from services.llm_service import llm_service, ChunkProcessingResult, ChunkStats
from utils.text_chunker import text_chunker, TextChunk
from models.ocr_result import CombinedOCRResults, OCRStats

# Setup logging
logger = logging.getLogger(__name__)

# ============================================================================
# SECTION 1: PROCESSING STATUS MODEL
# ============================================================================
# Model for tracking processing status and progress

@dataclass
class ProcessingStatus:
    """
    Track status of the summarization pipeline.
    Used for real-time UI updates.
    """
    # Overall status
    status: str = "pending"  # pending, processing, completed, failed
    current_step: str = ""
    progress_percent: float = 0.0
    
    # Step-specific status
    upload_status: str = "pending"
    ocr_status: str = "pending"
    chunking_status: str = "pending"
    summarization_status: str = "pending"
    final_summary_status: str = "pending"
    rag_index_status: str = "pending"
    
    # Results
    uploaded_files: List[str] = field(default_factory=list)
    ocr_results: Optional[CombinedOCRResults] = None
    chunks: List[TextChunk] = field(default_factory=list)
    chunk_results: List[ChunkProcessingResult] = field(default_factory=list)
    chunk_stats: List[ChunkStats] = field(default_factory=list)
    final_summary: str = ""
    
    # Statistics
    total_processing_time: float = 0.0
    total_cost: float = 0.0
    
    # Errors
    errors: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "status": self.status,
            "current_step": self.current_step,
            "progress_percent": self.progress_percent,
            "upload_status": self.upload_status,
            "ocr_status": self.ocr_status,
            "chunking_status": self.chunking_status,
            "summarization_status": self.summarization_status,
            "final_summary_status": self.final_summary_status,
            "rag_index_status": self.rag_index_status,
            "uploaded_files": self.uploaded_files,
            "total_processing_time": round(self.total_processing_time, 2),
            "total_cost": round(self.total_cost, 4),
            "errors": self.errors
        }


# ============================================================================
# SECTION 2: SUMMARIZATION SERVICE
# ============================================================================
# Main orchestrator for Part 1: Medical Record Summarization

class SummarizationService:
    """
    Orchestrates the complete medical record summarization pipeline.
    
    Flow:
    1. Upload PDFs to Blob Storage
    2. OCR processing (PARALLEL)
    3. Combine OCR outputs
    4. Chunk text (50K sliding window)
    5. GPT-5 summarization (PARALLEL with PROMPT CACHING)
    6. Generate final summary
    7. Build RAG index (for Q&A and Discrepancy Detection)
    """
    
    def __init__(self):
        """Initialize summarization service"""
        self.blob_service = blob_service
        self.ocr_service = ocr_service
        self.llm_service = llm_service
        self.text_chunker = text_chunker

    # ========================================================================
    # SECTION 2.1: UPLOAD PDFs - User uploads medical PDF documents
    # ========================================================================
    
    def upload_pdfs(
        self,
        session_id: str,
        files: List[Dict[str, Any]],
        status: ProcessingStatus
    ) -> List[str]:
        """
        Upload multiple PDF files to Azure Blob Storage.
        
        SECTION: User uploads multiple medical PDF documents via Streamlit UI
        
        Args:
            session_id: Unique session identifier
            files: List of dicts with 'name' and 'content' keys
            status: ProcessingStatus object for tracking
            
        Returns:
            List[str]: List of uploaded blob paths
        """
        status.current_step = "Uploading PDFs to Azure Blob Storage"
        status.upload_status = "processing"
        
        try:
            # Upload all files
            uploaded_paths = self.blob_service.upload_multiple_pdfs(
                session_id=session_id,
                files=files
            )
            
            status.uploaded_files = [f["name"] for f in files]
            status.upload_status = "completed"
            status.progress_percent = 10.0
            
            logger.info(f"Uploaded {len(uploaded_paths)} PDFs")
            return uploaded_paths
            
        except Exception as e:
            status.upload_status = "failed"
            status.errors.append(f"Upload failed: {str(e)}")
            raise

    # ========================================================================
    # SECTION 2.2: OCR PROCESSING - Parallel processing of all PDFs
    # ========================================================================
    
    def process_ocr(
        self,
        session_id: str,
        files: List[Dict[str, Any]],
        status: ProcessingStatus
    ) -> CombinedOCRResults:
        """
        Process all PDFs through OCR in PARALLEL.
        
        SECTION: Azure Document Intelligence (Layout Model) OCR - PARALLEL
        - All PDFs processed in parallel (async/concurrent)
        - Each PDF: Extract text with metadata (page, line, bounding box)
        
        Args:
            session_id: Session identifier
            files: List of dicts with 'name' and 'content' keys
            status: ProcessingStatus object for tracking
            
        Returns:
            CombinedOCRResults: Combined OCR results from all PDFs
        """
        status.current_step = "Processing OCR (Parallel)"
        status.ocr_status = "processing"
        
        try:
            # Process all PDFs in parallel
            combined_results = self.ocr_service.process_pdfs(
                pdf_files=files,
                session_id=session_id
            )
            
            status.ocr_results = combined_results
            status.ocr_status = "completed"
            status.progress_percent = 30.0
            
            logger.info(
                f"OCR completed: {combined_results.total_pdfs} PDFs, "
                f"{combined_results.total_pages} pages"
            )
            return combined_results
            
        except Exception as e:
            status.ocr_status = "failed"
            status.errors.append(f"OCR failed: {str(e)}")
            raise

    # ========================================================================
    # SECTION 2.3: COMBINE OCR OUTPUTS - Merge all extracted text
    # ========================================================================
    
    def combine_ocr_outputs(
        self,
        ocr_results: CombinedOCRResults,
        status: ProcessingStatus
    ) -> List[Dict[str, Any]]:
        """
        Combine OCR outputs from all PDFs into a single text stream.
        Preserves metadata for citation tracking.
        
        SECTION: Combine all OCR outputs
        
        Args:
            ocr_results: Combined OCR results from all PDFs
            status: ProcessingStatus object for tracking
            
        Returns:
            List[Dict]: List of text items with metadata
        """
        status.current_step = "Combining OCR outputs"
        
        # Get all text with citation metadata
        combined_text = ocr_results.get_all_citations()
        
        logger.info(f"Combined {len(combined_text)} text items from OCR")
        return combined_text

    # ========================================================================
    # SECTION 2.4: CHUNKING - Split into 50K token chunks
    # ========================================================================
    
    def chunk_text(
        self,
        text_with_metadata: List[Dict[str, Any]],
        status: ProcessingStatus
    ) -> List[TextChunk]:
        """
        Split combined text into chunks for GPT processing.
        Uses 50K token sliding window with overlap.
        
        SECTION: Sliding window chunking (50K tokens per chunk)
        
        Args:
            text_with_metadata: Combined text from OCR
            status: ProcessingStatus object for tracking
            
        Returns:
            List[TextChunk]: List of text chunks with metadata
        """
        status.current_step = "Chunking text (50K sliding window)"
        status.chunking_status = "processing"
        
        try:
            chunks = self.text_chunker.chunk_text_with_metadata(text_with_metadata)
            
            status.chunks = chunks
            status.chunking_status = "completed"
            status.progress_percent = 40.0
            
            chunk_summary = self.text_chunker.get_chunk_summary(chunks)
            logger.info(
                f"Created {chunk_summary['total_chunks']} chunks, "
                f"{chunk_summary['total_tokens']} total tokens"
            )
            return chunks
            
        except Exception as e:
            status.chunking_status = "failed"
            status.errors.append(f"Chunking failed: {str(e)}")
            raise

    # ========================================================================
    # SECTION 2.5: PARALLEL SUMMARIZATION - GPT-5 with Prompt Caching
    # ========================================================================
    
    def summarize_chunks(
        self,
        chunks: List[TextChunk],
        status: ProcessingStatus
    ) -> Tuple[List[ChunkProcessingResult], List[ChunkStats]]:
        """
        Summarize all chunks in PARALLEL using GPT-5 with PROMPT CACHING.
        
        SECTION: GPT-5 summarization - PARALLEL with Prompt Caching
        - System prompt cached (sent once, reused for all chunks)
        - All chunks processed concurrently
        - Track cost and cache hit status
        
        Args:
            chunks: List of text chunks
            status: ProcessingStatus object for tracking
            
        Returns:
            Tuple: (List of results, List of stats)
        """
        status.current_step = "Summarizing chunks (Parallel + Prompt Caching)"
        status.summarization_status = "processing"
        
        try:
            # Process all chunks in parallel
            results, stats = asyncio.run(
                self.llm_service.summarize_chunks_parallel(chunks)
            )
            
            status.chunk_results = results
            status.chunk_stats = stats
            status.summarization_status = "completed"
            status.progress_percent = 70.0
            
            # Calculate totals
            total_cost = sum(r.cost for r in results)
            cache_hits = sum(1 for r in results if r.cache_hit)
            
            logger.info(
                f"Summarization completed: {len(results)} chunks, "
                f"${total_cost:.4f} cost, "
                f"{cache_hits}/{len(results)} cache hits"
            )
            
            return results, stats
            
        except Exception as e:
            status.summarization_status = "failed"
            status.errors.append(f"Summarization failed: {str(e)}")
            raise

    # ========================================================================
    # SECTION 2.6: FINAL SUMMARY CONSOLIDATION
    # ========================================================================
    
    def create_final_summary(
        self,
        chunk_results: List[ChunkProcessingResult],
        session_id: str,
        status: ProcessingStatus
    ) -> str:
        """
        Consolidate chunk summaries into final unified summary.
        
        SECTION: Final consolidation
        
        Args:
            chunk_results: Results from chunk summarization
            session_id: Session identifier
            status: ProcessingStatus object for tracking
            
        Returns:
            str: Final consolidated summary in markdown
        """
        status.current_step = "Creating final summary"
        status.final_summary_status = "processing"
        
        try:
            # Create consolidated summary
            final_summary = self.llm_service.create_final_summary(chunk_results)
            
            # Save to Blob Storage
            self.blob_service.save_summary(
                session_id=session_id,
                summary_content=final_summary
            )
            
            # Save chunk summaries
            chunk_summaries = [r.to_dict() for r in chunk_results]
            self.blob_service.save_chunk_summaries(session_id, chunk_summaries)
            
            status.final_summary = final_summary
            status.final_summary_status = "completed"
            status.progress_percent = 85.0
            
            logger.info("Final summary created and saved")
            return final_summary
            
        except Exception as e:
            status.final_summary_status = "failed"
            status.errors.append(f"Final summary failed: {str(e)}")
            raise

    # ========================================================================
    # SECTION 2.7: SAVE STATISTICS
    # ========================================================================
    
    def save_statistics(
        self,
        session_id: str,
        ocr_results: CombinedOCRResults,
        chunk_stats: List[ChunkStats],
        status: ProcessingStatus
    ):
        """
        Save OCR and chunk statistics to Blob Storage.
        
        SECTION: Output saved to Blob
        
        Args:
            session_id: Session identifier
            ocr_results: OCR results for Table 1
            chunk_stats: Chunk stats for Table 2
            status: ProcessingStatus object
        """
        # Save OCR stats (Table 1)
        ocr_stats = [s.to_dict() for s in ocr_results.stats]
        self.blob_service.save_ocr_stats(session_id, ocr_stats)
        
        # Save chunk stats (Table 2)
        chunk_stats_data = [s.to_dict() for s in chunk_stats]
        self.blob_service.save_chunk_stats(session_id, chunk_stats_data)
        
        logger.info("Statistics saved to Blob Storage")

    # ========================================================================
    # SECTION 3: COMPLETE PIPELINE EXECUTION
    # ========================================================================
    # Execute the entire Part 1 pipeline
    
    def run_pipeline(
        self,
        session_id: str,
        files: List[Dict[str, Any]],
        progress_callback: Optional[Callable] = None
    ) -> ProcessingStatus:
        """
        Run the complete medical record summarization pipeline.
        
        This is the main entry point that orchestrates all steps:
        1. Upload PDFs
        2. OCR (Parallel)
        3. Combine outputs
        4. Chunk text
        5. Summarize (Parallel + Prompt Caching)
        6. Create final summary
        7. Save statistics
        
        Args:
            session_id: Unique session identifier
            files: List of uploaded files with 'name' and 'content'
            progress_callback: Optional callback for progress updates
            
        Returns:
            ProcessingStatus: Complete status with all results
        """
        start_time = time.time()
        status = ProcessingStatus()
        status.status = "processing"
        
        def update_progress():
            if progress_callback:
                progress_callback(status)
        
        try:
            # ----------------------------------------------------------------
            # STEP 1: Upload PDFs
            # ----------------------------------------------------------------
            self.upload_pdfs(session_id, files, status)
            update_progress()
            
            # ----------------------------------------------------------------
            # STEP 2: OCR Processing (Parallel)
            # ----------------------------------------------------------------
            ocr_results = self.process_ocr(session_id, files, status)
            update_progress()
            
            # ----------------------------------------------------------------
            # STEP 3: Combine OCR Outputs
            # ----------------------------------------------------------------
            combined_text = self.combine_ocr_outputs(ocr_results, status)
            update_progress()
            
            # ----------------------------------------------------------------
            # STEP 4: Chunk Text (50K sliding window)
            # ----------------------------------------------------------------
            chunks = self.chunk_text(combined_text, status)
            update_progress()
            
            # ----------------------------------------------------------------
            # STEP 5: Summarize Chunks (Parallel + Prompt Caching)
            # ----------------------------------------------------------------
            chunk_results, chunk_stats = self.summarize_chunks(chunks, status)
            update_progress()
            
            # ----------------------------------------------------------------
            # STEP 6: Create Final Summary
            # ----------------------------------------------------------------
            final_summary = self.create_final_summary(
                chunk_results, session_id, status
            )
            update_progress()
            
            # ----------------------------------------------------------------
            # STEP 7: Save Statistics
            # ----------------------------------------------------------------
            self.save_statistics(session_id, ocr_results, chunk_stats, status)
            
            # ----------------------------------------------------------------
            # Complete
            # ----------------------------------------------------------------
            status.status = "completed"
            status.progress_percent = 100.0
            status.total_processing_time = time.time() - start_time
            status.total_cost = sum(r.cost for r in chunk_results)
            
            logger.info(
                f"Pipeline completed: "
                f"{status.total_processing_time:.2f}s, "
                f"${status.total_cost:.4f}"
            )
            
        except Exception as e:
            status.status = "failed"
            status.errors.append(str(e))
            logger.error(f"Pipeline failed: {e}")
        
        update_progress()
        return status


# ============================================================================
# SECTION 4: SINGLETON INSTANCE
# ============================================================================
# Global instance for easy import

summarization_service = SummarizationService()
