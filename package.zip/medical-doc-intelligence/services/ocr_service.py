# ============================================================================
# OCR_SERVICE.PY - Azure Document Intelligence OCR Service
# ============================================================================
# Purpose: Handle OCR processing using Azure Document Intelligence (Layout Model)
#          Supports PARALLEL processing of multiple PDFs
# Author: Medical Doc Intelligence Team
# ============================================================================

import asyncio
import time
from typing import List, Dict, Any, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor
import logging

from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential

from config.azure_config import doc_intelligence_config
from config.settings import processing_settings
from models.ocr_result import (
    OCRResult, 
    PageMetadata, 
    LineMetadata, 
    OCRStats,
    CombinedOCRResults
)
from services.blob_service import blob_service

# Setup logging
logger = logging.getLogger(__name__)

# ============================================================================
# SECTION 1: OCR SERVICE CLIENT INITIALIZATION
# ============================================================================
# Initialize Azure Document Intelligence client

class OCRService:
    """
    Azure Document Intelligence OCR service.
    Extracts text with metadata (page, line, bounding box) from PDF documents.
    Supports PARALLEL processing of multiple PDFs.
    """
    
    def __init__(self):
        """Initialize Document Intelligence client"""
        self.endpoint = doc_intelligence_config.ENDPOINT
        self.api_key = doc_intelligence_config.API_KEY
        self.model_id = doc_intelligence_config.MODEL_ID
        self.client: Optional[DocumentAnalysisClient] = None
        
        if self.endpoint and self.api_key:
            self._initialize_client()
    
    def _initialize_client(self):
        """Initialize the Document Analysis client"""
        try:
            self.client = DocumentAnalysisClient(
                endpoint=self.endpoint,
                credential=AzureKeyCredential(self.api_key)
            )
            logger.info("Document Intelligence client initialized")
        except Exception as e:
            logger.error(f"Failed to initialize Document Intelligence client: {e}")
            raise

    # ========================================================================
    # SECTION 2: SINGLE PDF OCR PROCESSING
    # ========================================================================
    # Process a single PDF document and extract text with metadata
    
    def process_single_pdf(
        self, 
        pdf_content: bytes, 
        pdf_name: str,
        session_id: str
    ) -> OCRResult:
        """
        Process a single PDF and extract text with metadata.
        
        Args:
            pdf_content: Binary content of the PDF
            pdf_name: Name of the PDF file
            session_id: Session identifier
            
        Returns:
            OCRResult: Complete OCR result with pages, lines, and metadata
        """
        start_time = time.time()
        
        # Initialize result object
        result = OCRResult(
            pdf_name=pdf_name,
            session_id=session_id,
            status="processing"
        )
        
        try:
            # ----------------------------------------------------------------
            # STEP 2.1: Call Azure Document Intelligence API
            # ----------------------------------------------------------------
            logger.info(f"Starting OCR for: {pdf_name}")
            
            poller = self.client.begin_analyze_document(
                model_id=self.model_id,
                document=pdf_content
            )
            
            # Wait for OCR to complete
            analyze_result = poller.result()
            
            # ----------------------------------------------------------------
            # STEP 2.2: Extract pages with metadata
            # ----------------------------------------------------------------
            total_words = 0
            total_lines = 0
            
            for page_idx, page in enumerate(analyze_result.pages):
                page_metadata = PageMetadata(
                    page_number=page_idx + 1,
                    width=page.width if page.width else 0,
                    height=page.height if page.height else 0
                )
                
                # --------------------------------------------------------
                # STEP 2.3: Extract lines with bounding boxes
                # --------------------------------------------------------
                line_number = 0
                page_word_count = 0
                
                for line in page.lines:
                    line_number += 1
                    
                    # Extract bounding box coordinates
                    bbox = []
                    if line.polygon:
                        bbox = [point for point in line.polygon]
                    
                    # Create line metadata
                    line_metadata = LineMetadata(
                        line_number=line_number,
                        text=line.content,
                        page_number=page_idx + 1,
                        bounding_box=bbox,
                        confidence=1.0  # Layout model doesn't provide line confidence
                    )
                    
                    page_metadata.lines.append(line_metadata)
                    page_word_count += len(line.content.split())
                
                page_metadata.word_count = page_word_count
                total_words += page_word_count
                total_lines += line_number
                
                result.pages.append(page_metadata)
            
            # ----------------------------------------------------------------
            # STEP 2.4: Update result statistics
            # ----------------------------------------------------------------
            processing_time = time.time() - start_time
            
            result.total_pages = len(result.pages)
            result.total_words = total_words
            result.total_lines = total_lines
            result.processing_time_seconds = processing_time
            result.status = "completed"
            
            logger.info(
                f"OCR completed for {pdf_name}: "
                f"{result.total_pages} pages, "
                f"{result.total_words} words, "
                f"{processing_time:.2f}s"
            )
            
            return result
            
        except Exception as e:
            result.status = "failed"
            result.error_message = str(e)
            result.processing_time_seconds = time.time() - start_time
            logger.error(f"OCR failed for {pdf_name}: {e}")
            return result

    # ========================================================================
    # SECTION 3: PARALLEL OCR PROCESSING - All PDFs processed concurrently
    # ========================================================================
    # Process multiple PDFs in parallel using asyncio and ThreadPoolExecutor
    
    async def process_pdfs_parallel(
        self,
        pdf_files: List[Dict[str, Any]],
        session_id: str,
        max_workers: int = None
    ) -> CombinedOCRResults:
        """
        Process multiple PDFs in PARALLEL using async/concurrent execution.
        
        Args:
            pdf_files: List of dicts with 'name' and 'content' keys
            session_id: Session identifier
            max_workers: Maximum concurrent OCR operations (default from settings)
            
        Returns:
            CombinedOCRResults: Combined results from all PDFs
        """
        if max_workers is None:
            max_workers = processing_settings.OCR_PARALLEL_MAX_WORKERS
        
        logger.info(
            f"Starting PARALLEL OCR for {len(pdf_files)} PDFs "
            f"with {max_workers} workers"
        )
        
        combined_results = CombinedOCRResults(session_id=session_id)
        
        # ----------------------------------------------------------------
        # STEP 3.1: Create async tasks for each PDF
        # ----------------------------------------------------------------
        loop = asyncio.get_event_loop()
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Create list of futures for parallel execution
            futures = []
            for pdf_file in pdf_files:
                future = loop.run_in_executor(
                    executor,
                    self.process_single_pdf,
                    pdf_file["content"],
                    pdf_file["name"],
                    session_id
                )
                futures.append(future)
            
            # ----------------------------------------------------------------
            # STEP 3.2: Wait for all OCR tasks to complete
            # ----------------------------------------------------------------
            results = await asyncio.gather(*futures, return_exceptions=True)
        
        # ----------------------------------------------------------------
        # STEP 3.3: Collect results and handle any errors
        # ----------------------------------------------------------------
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                # Create error result for failed PDF
                error_result = OCRResult(
                    pdf_name=pdf_files[i]["name"],
                    session_id=session_id,
                    status="failed",
                    error_message=str(result)
                )
                combined_results.add_result(error_result)
                logger.error(f"OCR failed for {pdf_files[i]['name']}: {result}")
            else:
                combined_results.add_result(result)
        
        # ----------------------------------------------------------------
        # STEP 3.4: Save results to Blob Storage
        # ----------------------------------------------------------------
        await self._save_results_to_blob(session_id, combined_results)
        
        logger.info(
            f"PARALLEL OCR completed: "
            f"{combined_results.total_pdfs} PDFs, "
            f"{combined_results.total_pages} pages, "
            f"{combined_results.total_words} words, "
            f"{combined_results.total_processing_time:.2f}s total time"
        )
        
        return combined_results
    
    async def _save_results_to_blob(
        self, 
        session_id: str, 
        combined_results: CombinedOCRResults
    ):
        """
        Save OCR results and statistics to Blob Storage.
        
        Args:
            session_id: Session identifier
            combined_results: Combined OCR results
        """
        # Save individual OCR results
        for result in combined_results.results:
            blob_service.save_ocr_result(
                session_id=session_id,
                pdf_name=result.pdf_name,
                ocr_result=result.to_dict()
            )
        
        # Save OCR statistics (Table 1 data)
        ocr_stats = [stat.to_dict() for stat in combined_results.stats]
        blob_service.save_ocr_stats(session_id, ocr_stats)

    # ========================================================================
    # SECTION 4: SYNCHRONOUS WRAPPER FOR PARALLEL PROCESSING
    # ========================================================================
    # Wrapper to call async parallel processing from sync code
    
    def process_pdfs(
        self,
        pdf_files: List[Dict[str, Any]],
        session_id: str
    ) -> CombinedOCRResults:
        """
        Synchronous wrapper for parallel PDF processing.
        Use this method from Streamlit or other sync code.
        
        Args:
            pdf_files: List of dicts with 'name' and 'content' keys
            session_id: Session identifier
            
        Returns:
            CombinedOCRResults: Combined results from all PDFs
        """
        return asyncio.run(
            self.process_pdfs_parallel(pdf_files, session_id)
        )

    # ========================================================================
    # SECTION 5: LOAD EXISTING OCR RESULTS FROM BLOB
    # ========================================================================
    # Load previously processed OCR results
    
    def load_existing_results(self, session_id: str) -> CombinedOCRResults:
        """
        Load existing OCR results from Blob Storage.
        Used when OCR was already done and we need to reuse results.
        
        Args:
            session_id: Session identifier
            
        Returns:
            CombinedOCRResults: Previously processed OCR results
        """
        combined_results = CombinedOCRResults(session_id=session_id)
        
        # List all OCR result files
        ocr_files = blob_service.list_ocr_results(session_id)
        
        for ocr_file in ocr_files:
            # Extract PDF name from path
            pdf_name = ocr_file.split('/')[-1].replace('_ocr.json', '.pdf')
            
            # Load OCR result
            ocr_data = blob_service.load_ocr_result(session_id, pdf_name)
            result = OCRResult.from_dict(ocr_data)
            combined_results.add_result(result)
        
        logger.info(f"Loaded {len(ocr_files)} existing OCR results for session {session_id}")
        return combined_results

    # ========================================================================
    # SECTION 6: UTILITY METHODS
    # ========================================================================
    # Helper methods for OCR operations
    
    def check_ocr_exists(self, session_id: str, pdf_name: str) -> bool:
        """
        Check if OCR result already exists for a PDF.
        
        Args:
            session_id: Session identifier
            pdf_name: Name of the PDF file
            
        Returns:
            bool: True if OCR result exists
        """
        try:
            blob_service.load_ocr_result(session_id, pdf_name)
            return True
        except:
            return False
    
    def get_ocr_stats_summary(
        self, 
        combined_results: CombinedOCRResults
    ) -> Dict[str, Any]:
        """
        Get summary statistics for OCR processing.
        
        Args:
            combined_results: Combined OCR results
            
        Returns:
            Dict: Summary statistics
        """
        return {
            "total_pdfs": combined_results.total_pdfs,
            "total_pages": combined_results.total_pages,
            "total_words": combined_results.total_words,
            "total_processing_time_seconds": round(
                combined_results.total_processing_time, 2
            ),
            "average_time_per_pdf": round(
                combined_results.total_processing_time / max(combined_results.total_pdfs, 1), 2
            ),
            "average_words_per_page": round(
                combined_results.total_words / max(combined_results.total_pages, 1), 2
            )
        }


# ============================================================================
# SECTION 7: SINGLETON INSTANCE
# ============================================================================
# Global instance for easy import

ocr_service = OCRService()
