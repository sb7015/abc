# ============================================================================
# QA_SERVICE.PY - Question & Answer Service
# ============================================================================
# Purpose: Handle Q&A interactions using RAG with citations
#          - Retrieve relevant context from medical records
#          - Generate answers using GPT-5
#          - Include citations (PDF, page, line)
# Author: Medical Doc Intelligence Team
# ============================================================================

import time
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime
import logging
import json

from openai import AzureOpenAI

from config.azure_config import openai_config
from config.settings import llm_settings
from services.rag_service import rag_service, RetrievalResult
from services.blob_service import blob_service

# Setup logging
logger = logging.getLogger(__name__)

# ============================================================================
# SECTION 1: Q&A RESULT MODEL
# ============================================================================
# Model for storing Q&A result with citations

@dataclass
class QAResult:
    """
    Result of a Q&A query with answer and citations.
    """
    question: str
    answer: str
    citations: List[Dict[str, Any]] = field(default_factory=list)
    confidence: float = 0.0
    processing_time_seconds: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "question": self.question,
            "answer": self.answer,
            "citations": self.citations,
            "confidence": round(self.confidence, 2),
            "processing_time_seconds": round(self.processing_time_seconds, 2),
            "timestamp": self.timestamp
        }


@dataclass
class ChatHistory:
    """
    Chat history for a session.
    """
    session_id: str
    messages: List[QAResult] = field(default_factory=list)
    
    def add_message(self, result: QAResult):
        """Add a Q&A result to history"""
        self.messages.append(result)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "messages": [m.to_dict() for m in self.messages]
        }
    
    def get_context_messages(self, last_n: int = 5) -> List[Dict[str, str]]:
        """Get last N messages for context"""
        context = []
        for msg in self.messages[-last_n:]:
            context.append({"role": "user", "content": msg.question})
            context.append({"role": "assistant", "content": msg.answer})
        return context


# ============================================================================
# SECTION 2: Q&A SERVICE INITIALIZATION
# ============================================================================
# Initialize Q&A service with GPT-5 and RAG

class QAService:
    """
    Q&A service for answering questions about medical records.
    
    Features:
    - RAG-powered retrieval from medical records
    - Answers with citations (PDF, page, line)
    - Chat history maintenance
    - Context-aware responses
    """
    
    def __init__(self):
        """Initialize Q&A service"""
        self.endpoint = openai_config.ENDPOINT
        self.api_key = openai_config.API_KEY
        self.gpt5_deployment = openai_config.GPT5_DEPLOYMENT
        self.client: Optional[AzureOpenAI] = None
        
        # Chat histories per session
        self.chat_histories: Dict[str, ChatHistory] = {}
        
        if self.endpoint and self.api_key:
            self._initialize_client()
    
    def _initialize_client(self):
        """Initialize Azure OpenAI client"""
        try:
            self.client = AzureOpenAI(
                azure_endpoint=self.endpoint,
                api_key=self.api_key,
                api_version=openai_config.API_VERSION
            )
            logger.info("Q&A service initialized")
        except Exception as e:
            logger.error(f"Failed to initialize Q&A service: {e}")
            raise

    # ========================================================================
    # SECTION 3: Q&A SYSTEM PROMPT
    # ========================================================================
    # System prompt for answering questions with citations
    
    def _get_system_prompt(self) -> str:
        """
        Get system prompt for Q&A with citations.
        
        Returns:
            str: System prompt
        """
        return """You are a medical records assistant. Your task is to answer questions about patient medical records accurately and provide citations for your answers.

## Instructions:
1. Answer questions based ONLY on the provided context from medical records
2. Always cite your sources using the format: [Source: filename | Page X | Lines Y-Z]
3. If information is not in the provided context, clearly state: "This information is not found in the provided medical records."
4. Be accurate and do not make assumptions beyond what's in the records
5. Use medical terminology appropriately but explain terms when needed

## Answer Format:
1. Provide a clear, direct answer to the question
2. Include relevant details from the medical records
3. Add citations at the end of relevant statements
4. If multiple sources support the answer, cite all of them

## Example:
Question: Does the patient have diabetes?

Answer: Yes, the patient has been diagnosed with Type 2 Diabetes Mellitus. 
The diagnosis was made in March 2019, and the patient is currently managed with Metformin 1000mg twice daily. 
[Source: medical_records.pdf | Page 5 | Lines 22-24]

The most recent HbA1c level was 7.2% recorded in January 2024, indicating fair glycemic control.
[Source: lab_results.pdf | Page 2 | Lines 8-10]

## Important:
- Never fabricate information not in the context
- Clearly distinguish between confirmed diagnoses and suspected conditions
- Note any conflicting information if present
- Be concise but thorough"""

    # ========================================================================
    # SECTION 4: ANSWER QUESTION WITH RAG
    # ========================================================================
    # Main method to answer questions using RAG retrieval
    
    def answer_question(
        self,
        session_id: str,
        question: str,
        include_history: bool = True
    ) -> QAResult:
        """
        Answer a question using RAG retrieval and GPT-5.
        
        SECTION: User asks question in Q&A tab
        - Query embedded using same embedding model
        - Vector similarity search → retrieve top-K chunks
        - Retrieved chunks + metadata sent to GPT-5
        
        SECTION: GPT-5 generates answer with citation
        - Answer based on retrieved context
        - Citation included: PDF name, page number, line range
        
        Args:
            session_id: Session identifier
            question: User's question
            include_history: Whether to include chat history for context
            
        Returns:
            QAResult: Answer with citations
        """
        start_time = time.time()
        
        # ----------------------------------------------------------------
        # STEP 4.1: Ensure RAG index is loaded from Blob Storage
        # ----------------------------------------------------------------
        if rag_service.index is None:
            loaded = rag_service.load_index_from_blob(session_id)
            if not loaded:
                return QAResult(
                    question=question,
                    answer="Error: RAG index not available. Please process medical records first.",
                    processing_time_seconds=time.time() - start_time
                )
        
        # ----------------------------------------------------------------
        # STEP 4.2: Retrieve relevant chunks using RAG
        # ----------------------------------------------------------------
        retrieval_results = rag_service.search(question)
        
        if not retrieval_results:
            return QAResult(
                question=question,
                answer="No relevant information found in the medical records for this question.",
                processing_time_seconds=time.time() - start_time
            )
        
        # ----------------------------------------------------------------
        # STEP 4.3: Build context from retrieved chunks
        # ----------------------------------------------------------------
        context_parts = []
        for i, result in enumerate(retrieval_results):
            context_parts.append(
                f"[Context {i+1}]\n"
                f"Source: {result.chunk.pdf_name} | Page {result.chunk.page_number} | "
                f"Lines {result.chunk.line_start}-{result.chunk.line_end}\n"
                f"Content: {result.chunk.text}\n"
            )
        
        context = "\n---\n".join(context_parts)
        
        # ----------------------------------------------------------------
        # STEP 4.4: Build messages for GPT-5
        # ----------------------------------------------------------------
        messages = [
            {"role": "system", "content": self._get_system_prompt()}
        ]
        
        # Add chat history for context if available
        if include_history and session_id in self.chat_histories:
            history_messages = self.chat_histories[session_id].get_context_messages(last_n=3)
            messages.extend(history_messages)
        
        # Add current question with context
        user_message = f"""Based on the following medical record excerpts, please answer the question.

## Retrieved Medical Record Context:
{context}

## Question:
{question}

Please provide a detailed answer with citations to the source documents."""
        
        messages.append({"role": "user", "content": user_message})
        
        # ----------------------------------------------------------------
        # STEP 4.5: Call GPT-5 for answer generation
        # ----------------------------------------------------------------
        try:
            response = self.client.chat.completions.create(
                model=self.gpt5_deployment,
                messages=messages,
                temperature=llm_settings.QA_TEMPERATURE,
                max_tokens=llm_settings.MAX_OUTPUT_TOKENS
            )
            
            answer = response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Failed to generate answer: {e}")
            return QAResult(
                question=question,
                answer=f"Error generating answer: {str(e)}",
                processing_time_seconds=time.time() - start_time
            )
        
        # ----------------------------------------------------------------
        # STEP 4.6: Build result with citations
        # ----------------------------------------------------------------
        citations = [result.to_dict() for result in retrieval_results]
        
        # Calculate confidence based on retrieval scores
        avg_score = sum(r.score for r in retrieval_results) / len(retrieval_results)
        confidence = min(avg_score * 100, 100)  # Convert to percentage
        
        result = QAResult(
            question=question,
            answer=answer,
            citations=citations,
            confidence=confidence,
            processing_time_seconds=time.time() - start_time
        )
        
        # ----------------------------------------------------------------
        # STEP 4.7: Update chat history
        # ----------------------------------------------------------------
        if session_id not in self.chat_histories:
            self.chat_histories[session_id] = ChatHistory(session_id=session_id)
        
        self.chat_histories[session_id].add_message(result)
        
        # Save chat history to Blob
        self._save_chat_history(session_id)
        
        logger.info(
            f"Q&A completed: {len(retrieval_results)} sources, "
            f"confidence={confidence:.1f}%, "
            f"time={result.processing_time_seconds:.2f}s"
        )
        
        return result
    
    def _save_chat_history(self, session_id: str):
        """Save chat history to Blob Storage"""
        if session_id not in self.chat_histories:
            return
        
        try:
            history_data = self.chat_histories[session_id].to_dict()
            blob_service.container_client.get_blob_client(
                f"{session_id}/qa/chat_history.json"
            ).upload_blob(
                json.dumps(history_data, indent=2).encode('utf-8'),
                overwrite=True
            )
        except Exception as e:
            logger.warning(f"Failed to save chat history: {e}")

    # ========================================================================
    # SECTION 5: LOAD CHAT HISTORY
    # ========================================================================
    # Load existing chat history from Blob Storage
    
    def load_chat_history(self, session_id: str) -> ChatHistory:
        """
        Load chat history from Blob Storage.
        
        Args:
            session_id: Session identifier
            
        Returns:
            ChatHistory: Loaded chat history
        """
        try:
            history_blob = blob_service.container_client.get_blob_client(
                f"{session_id}/qa/chat_history.json"
            )
            history_data = json.loads(
                history_blob.download_blob().readall().decode('utf-8')
            )
            
            history = ChatHistory(session_id=session_id)
            for msg_data in history_data.get("messages", []):
                history.messages.append(QAResult(
                    question=msg_data["question"],
                    answer=msg_data["answer"],
                    citations=msg_data.get("citations", []),
                    confidence=msg_data.get("confidence", 0),
                    processing_time_seconds=msg_data.get("processing_time_seconds", 0),
                    timestamp=msg_data.get("timestamp", "")
                ))
            
            self.chat_histories[session_id] = history
            return history
            
        except Exception as e:
            logger.info(f"No existing chat history for session {session_id}")
            return ChatHistory(session_id=session_id)

    # ========================================================================
    # SECTION 6: CLEAR CHAT HISTORY
    # ========================================================================
    # Clear chat history for a session
    
    def clear_history(self, session_id: str):
        """
        Clear chat history for a session.
        
        Args:
            session_id: Session identifier
        """
        if session_id in self.chat_histories:
            self.chat_histories[session_id] = ChatHistory(session_id=session_id)
        
        try:
            blob_service.container_client.get_blob_client(
                f"{session_id}/qa/chat_history.json"
            ).delete_blob()
        except:
            pass
        
        logger.info(f"Cleared chat history for session {session_id}")

    # ========================================================================
    # SECTION 7: GET SUGGESTED QUESTIONS
    # ========================================================================
    # Generate suggested questions based on medical summary
    
    def get_suggested_questions(self, summary: str) -> List[str]:
        """
        Generate suggested questions based on medical summary.
        
        Args:
            summary: Medical summary text
            
        Returns:
            List[str]: Suggested questions
        """
        default_questions = [
            "What are the patient's current diagnoses?",
            "What medications is the patient currently taking?",
            "Are there any abnormal lab results?",
            "What procedures has the patient undergone?",
            "Does the patient have any chronic conditions?"
        ]
        
        try:
            response = self.client.chat.completions.create(
                model=self.gpt5_deployment,
                messages=[
                    {
                        "role": "system",
                        "content": "Generate 5 relevant questions a user might ask about this medical summary. Return only the questions, one per line."
                    },
                    {
                        "role": "user",
                        "content": f"Medical Summary:\n{summary[:2000]}"
                    }
                ],
                temperature=0.7,
                max_tokens=500
            )
            
            questions = response.choices[0].message.content.strip().split('\n')
            questions = [q.strip().lstrip('0123456789.-) ') for q in questions if q.strip()]
            return questions[:5]
            
        except Exception as e:
            logger.warning(f"Failed to generate suggested questions: {e}")
            return default_questions


# ============================================================================
# SECTION 8: SINGLETON INSTANCE
# ============================================================================
# Global instance for easy import

qa_service = QAService()
