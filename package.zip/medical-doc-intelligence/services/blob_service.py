# ============================================================================
# BLOB_SERVICE.PY - Azure Blob Storage Service
# ============================================================================
# Purpose: Handle all Azure Blob Storage operations for medical documents
# Author: Medical Doc Intelligence Team
# ============================================================================

import os
import json
import asyncio
from typing import List, Dict, Any, Optional, BinaryIO
from datetime import datetime, timedelta
import logging

from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from azure.storage.blob import generate_blob_sas, BlobSasPermissions

from config.azure_config import blob_config
from config.settings import blob_paths

# Setup logging
logger = logging.getLogger(__name__)

# ============================================================================
# SECTION 1: BLOB SERVICE CLIENT INITIALIZATION
# ============================================================================
# Initialize Azure Blob Storage client

class BlobStorageService:
    """
    Azure Blob Storage service for medical document management.
    Handles upload, download, and management of all session files.
    """
    
    def __init__(self):
        """Initialize Blob Storage client"""
        self.connection_string = blob_config.CONNECTION_STRING
        self.container_name = blob_config.CONTAINER_NAME
        self.blob_service_client: Optional[BlobServiceClient] = None
        self.container_client: Optional[ContainerClient] = None
        
        if self.connection_string:
            self._initialize_client()
    
    def _initialize_client(self):
        """Initialize the blob service client"""
        try:
            self.blob_service_client = BlobServiceClient.from_connection_string(
                self.connection_string
            )
            self.container_client = self.blob_service_client.get_container_client(
                self.container_name
            )
            # Create container if not exists
            if not self.container_client.exists():
                self.container_client.create_container()
                logger.info(f"Created container: {self.container_name}")
        except Exception as e:
            logger.error(f"Failed to initialize Blob Storage client: {e}")
            raise

    # ========================================================================
    # SECTION 2: UPLOAD OPERATIONS - User uploads medical PDF documents
    # ========================================================================
    # Handle file uploads to Azure Blob Storage
    
    def upload_pdf(
        self, 
        session_id: str, 
        file_name: str, 
        file_content: bytes
    ) -> str:
        """
        Upload a single PDF file to blob storage.
        
        Args:
            session_id: Unique session identifier
            file_name: Name of the PDF file
            file_content: Binary content of the PDF
            
        Returns:
            str: Blob path where file was uploaded
        """
        # Construct blob path: {session_id}/medical_records/{file_name}
        blob_path = f"{session_id}/medical_records/{file_name}"
        
        try:
            blob_client = self.container_client.get_blob_client(blob_path)
            blob_client.upload_blob(
                file_content, 
                overwrite=True,
                content_settings={"content_type": "application/pdf"}
            )
            logger.info(f"Uploaded PDF: {blob_path}")
            return blob_path
        except Exception as e:
            logger.error(f"Failed to upload PDF {file_name}: {e}")
            raise
    
    def upload_multiple_pdfs(
        self, 
        session_id: str, 
        files: List[Dict[str, Any]]
    ) -> List[str]:
        """
        Upload multiple PDF files to blob storage.
        
        Args:
            session_id: Unique session identifier
            files: List of dicts with 'name' and 'content' keys
            
        Returns:
            List[str]: List of blob paths where files were uploaded
        """
        uploaded_paths = []
        for file_info in files:
            path = self.upload_pdf(
                session_id=session_id,
                file_name=file_info["name"],
                file_content=file_info["content"]
            )
            uploaded_paths.append(path)
        
        logger.info(f"Uploaded {len(uploaded_paths)} PDFs for session {session_id}")
        return uploaded_paths

    # ========================================================================
    # SECTION 3: DOWNLOAD OPERATIONS - Get files from Blob Storage
    # ========================================================================
    # Handle file downloads from Azure Blob Storage
    
    def download_pdf(self, blob_path: str) -> bytes:
        """
        Download a PDF file from blob storage.
        
        Args:
            blob_path: Full path to the blob
            
        Returns:
            bytes: Binary content of the PDF
        """
        try:
            blob_client = self.container_client.get_blob_client(blob_path)
            download_stream = blob_client.download_blob()
            content = download_stream.readall()
            logger.info(f"Downloaded PDF: {blob_path}")
            return content
        except Exception as e:
            logger.error(f"Failed to download PDF {blob_path}: {e}")
            raise
    
    def get_pdf_url(self, blob_path: str, expiry_hours: int = 24) -> str:
        """
        Generate a SAS URL for accessing a PDF.
        
        Args:
            blob_path: Full path to the blob
            expiry_hours: Hours until URL expires
            
        Returns:
            str: SAS URL for the blob
        """
        try:
            sas_token = generate_blob_sas(
                account_name=self.blob_service_client.account_name,
                container_name=self.container_name,
                blob_name=blob_path,
                account_key=self.blob_service_client.credential.account_key,
                permission=BlobSasPermissions(read=True),
                expiry=datetime.utcnow() + timedelta(hours=expiry_hours)
            )
            blob_url = f"{self.blob_service_client.url}{self.container_name}/{blob_path}?{sas_token}"
            return blob_url
        except Exception as e:
            logger.error(f"Failed to generate SAS URL for {blob_path}: {e}")
            raise

    # ========================================================================
    # SECTION 4: OCR OUTPUT OPERATIONS - Save/Load OCR results
    # ========================================================================
    # Handle OCR JSON output storage
    
    def save_ocr_result(
        self, 
        session_id: str, 
        pdf_name: str, 
        ocr_result: Dict[str, Any]
    ) -> str:
        """
        Save OCR result JSON to blob storage.
        
        Args:
            session_id: Unique session identifier
            pdf_name: Original PDF filename
            ocr_result: OCR result dictionary with metadata
            
        Returns:
            str: Blob path where OCR result was saved
        """
        # Create output filename: {pdf_name}_ocr.json
        ocr_filename = f"{os.path.splitext(pdf_name)[0]}_ocr.json"
        blob_path = f"{session_id}/ocr_output/{ocr_filename}"
        
        try:
            blob_client = self.container_client.get_blob_client(blob_path)
            json_content = json.dumps(ocr_result, indent=2, ensure_ascii=False)
            blob_client.upload_blob(
                json_content.encode('utf-8'),
                overwrite=True,
                content_settings={"content_type": "application/json"}
            )
            logger.info(f"Saved OCR result: {blob_path}")
            return blob_path
        except Exception as e:
            logger.error(f"Failed to save OCR result for {pdf_name}: {e}")
            raise
    
    def load_ocr_result(self, session_id: str, pdf_name: str) -> Dict[str, Any]:
        """
        Load OCR result JSON from blob storage.
        
        Args:
            session_id: Unique session identifier
            pdf_name: Original PDF filename
            
        Returns:
            Dict: OCR result with metadata
        """
        ocr_filename = f"{os.path.splitext(pdf_name)[0]}_ocr.json"
        blob_path = f"{session_id}/ocr_output/{ocr_filename}"
        
        try:
            blob_client = self.container_client.get_blob_client(blob_path)
            download_stream = blob_client.download_blob()
            content = download_stream.readall().decode('utf-8')
            return json.loads(content)
        except Exception as e:
            logger.error(f"Failed to load OCR result for {pdf_name}: {e}")
            raise
    
    def list_ocr_results(self, session_id: str) -> List[str]:
        """
        List all OCR result files for a session.
        
        Args:
            session_id: Unique session identifier
            
        Returns:
            List[str]: List of OCR result blob paths
        """
        prefix = f"{session_id}/ocr_output/"
        blobs = self.container_client.list_blobs(name_starts_with=prefix)
        return [blob.name for blob in blobs if blob.name.endswith('_ocr.json')]

    # ========================================================================
    # SECTION 5: SUMMARY OPERATIONS - Save/Load summaries
    # ========================================================================
    # Handle summary markdown and JSON storage
    
    def save_summary(
        self, 
        session_id: str, 
        summary_content: str, 
        filename: str = "final_summary.md"
    ) -> str:
        """
        Save summary markdown to blob storage.
        
        Args:
            session_id: Unique session identifier
            summary_content: Markdown content of summary
            filename: Output filename
            
        Returns:
            str: Blob path where summary was saved
        """
        blob_path = f"{session_id}/summaries/{filename}"
        
        try:
            blob_client = self.container_client.get_blob_client(blob_path)
            blob_client.upload_blob(
                summary_content.encode('utf-8'),
                overwrite=True,
                content_settings={"content_type": "text/markdown"}
            )
            logger.info(f"Saved summary: {blob_path}")
            return blob_path
        except Exception as e:
            logger.error(f"Failed to save summary: {e}")
            raise
    
    def save_chunk_summaries(
        self, 
        session_id: str, 
        chunk_summaries: List[Dict[str, Any]]
    ) -> str:
        """
        Save chunk summaries JSON to blob storage.
        
        Args:
            session_id: Unique session identifier
            chunk_summaries: List of chunk summary dictionaries
            
        Returns:
            str: Blob path where chunk summaries were saved
        """
        blob_path = f"{session_id}/summaries/chunk_summaries.json"
        
        try:
            blob_client = self.container_client.get_blob_client(blob_path)
            json_content = json.dumps(chunk_summaries, indent=2, ensure_ascii=False)
            blob_client.upload_blob(
                json_content.encode('utf-8'),
                overwrite=True,
                content_settings={"content_type": "application/json"}
            )
            logger.info(f"Saved chunk summaries: {blob_path}")
            return blob_path
        except Exception as e:
            logger.error(f"Failed to save chunk summaries: {e}")
            raise

    # ========================================================================
    # SECTION 6: STATISTICS OPERATIONS - Save/Load stats
    # ========================================================================
    # Handle statistics JSON storage
    
    def save_ocr_stats(
        self, 
        session_id: str, 
        stats: List[Dict[str, Any]]
    ) -> str:
        """
        Save OCR statistics to blob storage.
        
        Args:
            session_id: Unique session identifier
            stats: List of OCR statistics per PDF
            
        Returns:
            str: Blob path where stats were saved
        """
        blob_path = f"{session_id}/stats/ocr_stats.json"
        
        try:
            blob_client = self.container_client.get_blob_client(blob_path)
            json_content = json.dumps(stats, indent=2)
            blob_client.upload_blob(
                json_content.encode('utf-8'),
                overwrite=True,
                content_settings={"content_type": "application/json"}
            )
            logger.info(f"Saved OCR stats: {blob_path}")
            return blob_path
        except Exception as e:
            logger.error(f"Failed to save OCR stats: {e}")
            raise
    
    def save_chunk_stats(
        self, 
        session_id: str, 
        stats: List[Dict[str, Any]]
    ) -> str:
        """
        Save chunk processing statistics to blob storage.
        
        Args:
            session_id: Unique session identifier
            stats: List of chunk statistics
            
        Returns:
            str: Blob path where stats were saved
        """
        blob_path = f"{session_id}/stats/chunk_stats.json"
        
        try:
            blob_client = self.container_client.get_blob_client(blob_path)
            json_content = json.dumps(stats, indent=2)
            blob_client.upload_blob(
                json_content.encode('utf-8'),
                overwrite=True,
                content_settings={"content_type": "application/json"}
            )
            logger.info(f"Saved chunk stats: {blob_path}")
            return blob_path
        except Exception as e:
            logger.error(f"Failed to save chunk stats: {e}")
            raise

    # ========================================================================
    # SECTION 7: SESSION MANAGEMENT - List and cleanup
    # ========================================================================
    # Handle session file listing and cleanup
    
    def list_session_pdfs(self, session_id: str) -> List[str]:
        """
        List all PDF files for a session.
        
        Args:
            session_id: Unique session identifier
            
        Returns:
            List[str]: List of PDF blob paths
        """
        prefix = f"{session_id}/medical_records/"
        blobs = self.container_client.list_blobs(name_starts_with=prefix)
        return [blob.name for blob in blobs if blob.name.endswith('.pdf')]
    
    def delete_session(self, session_id: str) -> int:
        """
        Delete all files for a session.
        
        Args:
            session_id: Unique session identifier
            
        Returns:
            int: Number of files deleted
        """
        prefix = f"{session_id}/"
        blobs = list(self.container_client.list_blobs(name_starts_with=prefix))
        
        for blob in blobs:
            self.container_client.delete_blob(blob.name)
        
        logger.info(f"Deleted {len(blobs)} files for session {session_id}")
        return len(blobs)


# ============================================================================
# SECTION 8: SINGLETON INSTANCE
# ============================================================================
# Global instance for easy import

blob_service = BlobStorageService()
