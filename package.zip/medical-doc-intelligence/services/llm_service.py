# ============================================================================
# LLM_SERVICE.PY - Azure OpenAI LLM Service
# ============================================================================
# Purpose: Handle LLM operations (GPT-5) for summarization with:
#          - PARALLEL chunk processing
#          - PROMPT CACHING for efficiency
# Author: Medical Doc Intelligence Team
# ============================================================================

import asyncio
import time
from typing import List, Dict, Any, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
import logging
import json

from openai import AzureOpenAI

from config.azure_config import openai_config
from config.settings import llm_settings, stats_settings
from utils.text_chunker import TextChunk

# Setup logging
logger = logging.getLogger(__name__)

# ============================================================================
# SECTION 1: CHUNK PROCESSING RESULT MODEL
# ============================================================================
# Model for storing LLM processing results per chunk

@dataclass
class ChunkProcessingResult:
    """
    Result of processing a single chunk through LLM.
    """
    chunk_id: int
    summary: str
    
    # Token usage
    input_tokens: int = 0
    output_tokens: int = 0
    cached_tokens: int = 0  # Tokens served from cache
    
    # Performance
    processing_time_seconds: float = 0.0
    
    # Cost calculation
    cost: float = 0.0
    cache_hit: bool = False
    
    # Status
    status: str = "completed"  # completed, failed
    error_message: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "chunk_id": self.chunk_id,
            "summary": self.summary,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cached_tokens": self.cached_tokens,
            "processing_time_seconds": round(self.processing_time_seconds, 2),
            "cost": round(self.cost, 4),
            "cache_hit": self.cache_hit,
            "status": self.status,
            "error_message": self.error_message
        }


@dataclass
class ChunkStats:
    """
    Statistics for chunk processing (Table 2 data).
    """
    chunk_number: int
    token_count: int
    processing_time_seconds: float
    cost: float
    cache_hit: bool
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for Table 2"""
        return {
            "chunk_number": self.chunk_number,
            "token_count": self.token_count,
            "processing_time_seconds": round(self.processing_time_seconds, 2),
            "cost": round(self.cost, 4),
            "cache_hit": "Yes ✓" if self.cache_hit else "No"
        }


# ============================================================================
# SECTION 2: LLM SERVICE CLIENT INITIALIZATION
# ============================================================================
# Initialize Azure OpenAI client

class LLMService:
    """
    Azure OpenAI LLM service for medical document summarization.
    Supports PARALLEL processing with PROMPT CACHING.
    """
    
    def __init__(self):
        """Initialize Azure OpenAI client"""
        self.endpoint = openai_config.ENDPOINT
        self.api_key = openai_config.API_KEY
        self.api_version = openai_config.API_VERSION
        self.gpt5_deployment = openai_config.GPT5_DEPLOYMENT
        self.client: Optional[AzureOpenAI] = None
        
        # Cached system prompt (will be set on first use)
        self._cached_system_prompt: Optional[str] = None
        
        if self.endpoint and self.api_key:
            self._initialize_client()
    
    def _initialize_client(self):
        """Initialize the Azure OpenAI client"""
        try:
            self.client = AzureOpenAI(
                azure_endpoint=self.endpoint,
                api_key=self.api_key,
                api_version=self.api_version
            )
            logger.info("Azure OpenAI client initialized")
        except Exception as e:
            logger.error(f"Failed to initialize Azure OpenAI client: {e}")
            raise

    # ========================================================================
    # SECTION 3: SYSTEM PROMPT SETUP (CACHED)
    # ========================================================================
    # Load and cache the system prompt for summarization
    
    def _get_system_prompt(self) -> str:
        """
        Get the cached system prompt for summarization.
        This prompt is sent once and cached by Azure OpenAI.
        
        Returns:
            str: System prompt for medical summarization
        """
        if self._cached_system_prompt:
            return self._cached_system_prompt
        
        # ----------------------------------------------------------------
        # SYSTEM PROMPT - This is CACHED by Azure OpenAI
        # Contains instructions, guidelines, and examples
        # ----------------------------------------------------------------
        self._cached_system_prompt = """You are a medical document summarization expert. Your task is to summarize medical records accurately and comprehensively.

## Instructions:
1. Extract all relevant medical information from the provided text
2. Organize information by categories (diagnoses, medications, procedures, lab results)
3. Preserve exact dates, values, and medical terminology
4. Highlight critical findings and abnormal results
5. Maintain chronological order where applicable

## Output Format:
Use the following markdown structure:

### Patient Overview
- Brief summary of patient's overall health status

### Diagnoses & Conditions
- List all diagnoses with dates
- Include ICD codes if available

### Medications
- Current medications with dosages
- Historical medications if relevant

### Procedures & Surgeries
- List procedures with dates
- Include relevant findings

### Lab Results & Vitals
- Recent lab values with dates
- Highlight abnormal results

### Clinical Notes
- Key observations from physician notes
- Treatment plans and recommendations

### Condition Tags
List identified conditions as tags: [Diabetes], [Hypertension], [Cancer], etc.

## Important:
- Be thorough but concise
- Never fabricate information
- Clearly indicate if information is unclear or incomplete
- Preserve medical accuracy over readability"""

        return self._cached_system_prompt

    # ========================================================================
    # SECTION 4: SINGLE CHUNK SUMMARIZATION
    # ========================================================================
    # Process a single chunk through GPT-5
    
    def summarize_chunk(
        self,
        chunk: TextChunk,
        is_first_request: bool = False
    ) -> ChunkProcessingResult:
        """
        Summarize a single text chunk using GPT-5.
        
        Args:
            chunk: TextChunk to summarize
            is_first_request: True if this is the first request (no cache yet)
            
        Returns:
            ChunkProcessingResult: Summary and processing statistics
        """
        start_time = time.time()
        
        result = ChunkProcessingResult(
            chunk_id=chunk.chunk_id,
            summary=""
        )
        
        try:
            # ----------------------------------------------------------------
            # STEP 4.1: Prepare messages with cached system prompt
            # ----------------------------------------------------------------
            messages = [
                {
                    "role": "system",
                    "content": self._get_system_prompt()
                },
                {
                    "role": "user",
                    "content": f"""Please summarize the following medical record text:

---
{chunk.text}
---

Source Information:
- Files: {', '.join(chunk.source_files) if chunk.source_files else 'Unknown'}
- Pages: {chunk.start_page} to {chunk.end_page}
- This is chunk {chunk.chunk_id + 1}
{"- This is the FIRST chunk" if chunk.is_first_chunk else ""}
{"- This is the LAST chunk" if chunk.is_last_chunk else ""}

Provide a comprehensive summary following the specified format."""
                }
            ]
            
            # ----------------------------------------------------------------
            # STEP 4.2: Call Azure OpenAI with prompt caching
            # ----------------------------------------------------------------
            response = self.client.chat.completions.create(
                model=self.gpt5_deployment,
                messages=messages,
                temperature=llm_settings.SUMMARIZATION_TEMPERATURE,
                max_tokens=llm_settings.MAX_OUTPUT_TOKENS
            )
            
            # ----------------------------------------------------------------
            # STEP 4.3: Extract response and token usage
            # ----------------------------------------------------------------
            result.summary = response.choices[0].message.content
            
            # Token usage
            usage = response.usage
            result.input_tokens = usage.prompt_tokens
            result.output_tokens = usage.completion_tokens
            
            # Check for cached tokens (Azure OpenAI reports this)
            if hasattr(usage, 'prompt_tokens_details'):
                cached = getattr(usage.prompt_tokens_details, 'cached_tokens', 0)
                result.cached_tokens = cached
                result.cache_hit = cached > 0
            
            # ----------------------------------------------------------------
            # STEP 4.4: Calculate cost
            # ----------------------------------------------------------------
            result.cost = self._calculate_cost(
                input_tokens=result.input_tokens,
                output_tokens=result.output_tokens,
                cached_tokens=result.cached_tokens
            )
            
            result.processing_time_seconds = time.time() - start_time
            result.status = "completed"
            
            logger.info(
                f"Chunk {chunk.chunk_id} summarized: "
                f"{result.input_tokens} in, {result.output_tokens} out, "
                f"cache_hit={result.cache_hit}, "
                f"${result.cost:.4f}, "
                f"{result.processing_time_seconds:.2f}s"
            )
            
        except Exception as e:
            result.status = "failed"
            result.error_message = str(e)
            result.processing_time_seconds = time.time() - start_time
            logger.error(f"Failed to summarize chunk {chunk.chunk_id}: {e}")
        
        return result
    
    def _calculate_cost(
        self,
        input_tokens: int,
        output_tokens: int,
        cached_tokens: int
    ) -> float:
        """
        Calculate API cost based on token usage.
        
        Args:
            input_tokens: Total input tokens
            output_tokens: Output tokens
            cached_tokens: Tokens served from cache
            
        Returns:
            float: Estimated cost in USD
        """
        # Non-cached input tokens
        non_cached_tokens = input_tokens - cached_tokens
        
        # Calculate costs
        input_cost = (non_cached_tokens / 1000) * stats_settings.GPT5_INPUT_COST_PER_1K
        cached_cost = (cached_tokens / 1000) * stats_settings.GPT5_CACHED_INPUT_COST_PER_1K
        output_cost = (output_tokens / 1000) * stats_settings.GPT5_OUTPUT_COST_PER_1K
        
        return input_cost + cached_cost + output_cost

    # ========================================================================
    # SECTION 5: PARALLEL CHUNK SUMMARIZATION
    # ========================================================================
    # Process all chunks in PARALLEL with prompt caching
    
    async def summarize_chunks_parallel(
        self,
        chunks: List[TextChunk],
        max_workers: int = 5
    ) -> Tuple[List[ChunkProcessingResult], List[ChunkStats]]:
        """
        Summarize all chunks in PARALLEL using async execution.
        Uses PROMPT CACHING - system prompt is sent once and cached.
        
        Args:
            chunks: List of text chunks to summarize
            max_workers: Maximum concurrent LLM calls
            
        Returns:
            Tuple: (List of results, List of stats for Table 2)
        """
        logger.info(
            f"Starting PARALLEL summarization of {len(chunks)} chunks "
            f"with {max_workers} workers and PROMPT CACHING"
        )
        
        # ----------------------------------------------------------------
        # STEP 5.1: Process first chunk to warm up cache
        # ----------------------------------------------------------------
        # First request will cache the system prompt
        first_result = None
        remaining_chunks = chunks
        
        if chunks:
            logger.info("Processing first chunk to warm up prompt cache...")
            first_result = self.summarize_chunk(chunks[0], is_first_request=True)
            remaining_chunks = chunks[1:]
        
        # ----------------------------------------------------------------
        # STEP 5.2: Process remaining chunks in parallel (cache hit expected)
        # ----------------------------------------------------------------
        results = [first_result] if first_result else []
        
        if remaining_chunks:
            loop = asyncio.get_event_loop()
            
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [
                    loop.run_in_executor(
                        executor,
                        self.summarize_chunk,
                        chunk,
                        False  # Not first request, cache should be warm
                    )
                    for chunk in remaining_chunks
                ]
                
                parallel_results = await asyncio.gather(
                    *futures, 
                    return_exceptions=True
                )
            
            # ----------------------------------------------------------------
            # STEP 5.3: Collect results and handle errors
            # ----------------------------------------------------------------
            for i, result in enumerate(parallel_results):
                if isinstance(result, Exception):
                    error_result = ChunkProcessingResult(
                        chunk_id=remaining_chunks[i].chunk_id,
                        summary="",
                        status="failed",
                        error_message=str(result)
                    )
                    results.append(error_result)
                else:
                    results.append(result)
        
        # ----------------------------------------------------------------
        # STEP 5.4: Generate statistics for Table 2
        # ----------------------------------------------------------------
        stats = [
            ChunkStats(
                chunk_number=r.chunk_id + 1,
                token_count=r.input_tokens + r.output_tokens,
                processing_time_seconds=r.processing_time_seconds,
                cost=r.cost,
                cache_hit=r.cache_hit
            )
            for r in results
        ]
        
        # ----------------------------------------------------------------
        # STEP 5.5: Log summary
        # ----------------------------------------------------------------
        total_cost = sum(r.cost for r in results)
        total_time = sum(r.processing_time_seconds for r in results)
        cache_hits = sum(1 for r in results if r.cache_hit)
        
        logger.info(
            f"PARALLEL summarization completed: "
            f"{len(results)} chunks, "
            f"${total_cost:.4f} total cost, "
            f"{cache_hits}/{len(results)} cache hits, "
            f"{total_time:.2f}s total processing time"
        )
        
        return results, stats

    # ========================================================================
    # SECTION 6: FINAL SUMMARY CONSOLIDATION
    # ========================================================================
    # Combine chunk summaries into final unified summary
    
    def create_final_summary(
        self,
        chunk_results: List[ChunkProcessingResult]
    ) -> str:
        """
        Combine all chunk summaries into a final unified summary.
        
        Args:
            chunk_results: List of chunk processing results
            
        Returns:
            str: Final consolidated summary in markdown format
        """
        # Collect successful summaries
        summaries = [
            r.summary for r in chunk_results 
            if r.status == "completed" and r.summary
        ]
        
        if not summaries:
            return "# Error\nNo summaries were successfully generated."
        
        if len(summaries) == 1:
            return summaries[0]
        
        # ----------------------------------------------------------------
        # Combine multiple chunk summaries
        # ----------------------------------------------------------------
        combined_prompt = f"""You have received summaries from {len(summaries)} chunks of a patient's medical records. 
Please consolidate these into a single, comprehensive summary.

Remove any duplicates, merge related information, and ensure chronological ordering where applicable.

## Chunk Summaries:

"""
        for i, summary in enumerate(summaries):
            combined_prompt += f"### Chunk {i + 1}:\n{summary}\n\n---\n\n"
        
        combined_prompt += """
Please provide a final, consolidated summary following the standard format."""
        
        try:
            response = self.client.chat.completions.create(
                model=self.gpt5_deployment,
                messages=[
                    {"role": "system", "content": self._get_system_prompt()},
                    {"role": "user", "content": combined_prompt}
                ],
                temperature=llm_settings.SUMMARIZATION_TEMPERATURE,
                max_tokens=llm_settings.MAX_OUTPUT_TOKENS
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Failed to create final summary: {e}")
            # Fallback: just concatenate summaries
            return "\n\n---\n\n".join(summaries)

    # ========================================================================
    # SECTION 7: SYNCHRONOUS WRAPPER
    # ========================================================================
    # Wrapper for calling async methods from sync code
    
    def summarize_chunks(
        self,
        chunks: List[TextChunk]
    ) -> Tuple[List[ChunkProcessingResult], List[ChunkStats], str]:
        """
        Synchronous wrapper for parallel chunk summarization.
        
        Args:
            chunks: List of text chunks to summarize
            
        Returns:
            Tuple: (results, stats, final_summary)
        """
        results, stats = asyncio.run(
            self.summarize_chunks_parallel(chunks)
        )
        
        final_summary = self.create_final_summary(results)
        
        return results, stats, final_summary


# ============================================================================
# SECTION 8: SINGLETON INSTANCE
# ============================================================================
# Global instance for easy import

llm_service = LLMService()
