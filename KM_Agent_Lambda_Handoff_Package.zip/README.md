# Agentic KM Solution — AWS Backend

## Overview
This is the AWS Lambda backend for the Agentic Knowledge Management (KM) solution.
It receives natural language questions via API Gateway, processes them through a
3-tool Strands Agent pattern using Amazon Bedrock (Claude Sonnet), and returns
synthesized answers with citations.

## Architecture
```
User Question
     │
     ▼
API Gateway (HTTPS POST /chat)
     │
     ▼
AWS Lambda (km-agent-chat)
     │
     ├─► Tool 1: Intent Classification (Bedrock Claude)
     │   Classifies → SOP / Policy / Salesforce / SOR / General
     │
     ├─► Tool 2: Query Enhancement (Bedrock Claude)
     │   Generates 3 optimized search queries
     │
     ├─► Tool 3: Document Search (MOCK → replace with SharePoint Graph API)
     │   Returns relevant documents
     │
     └─► Answer Synthesis (Bedrock Claude)
         Generates answer with citations from retrieved documents
     │
     ▼
JSON Response (answer, citations, intent, sources, correlation_id)
```

## Current State (POC)
- ✅ Lambda functions deployed and working
- ✅ API Gateway live at: https://1puptxusdd.execute-api.us-east-1.amazonaws.com
- ✅ Bedrock Claude (3.5 Sonnet v2) — 3 real LLM calls per request
- ✅ Intent classification working
- ✅ Query enhancement working
- ✅ Feedback endpoint working
- ⚠️ Document search uses MOCK hardcoded data (see MOCK_DOCUMENTS in lambda_function.py)
- ❌ SharePoint OBO integration not yet implemented
- ❌ MemoryDB logging not yet implemented
- ❌ Kong API Gateway not yet configured (using AWS API Gateway for POC)

## API Endpoints

### POST /chat
**Request:**
```json
{
    "question": "What is the SOP for claims appeal?",
    "session_id": "optional-session-id"
}
```

**Response:**
```json
{
    "answer": "Based on the source documents...",
    "citations": "[1] SOP-Claims-Appeal-v3.2.pdf - https://...",
    "intent": "SOP",
    "correlation_id": "uuid",
    "session_id": "uuid",
    "sources": [
        {
            "title": "SOP-Claims-Appeal-v3.2.pdf",
            "url": "https://sharepoint.example.com/...",
            "snippet": "Claims Appeal Standard Operating..."
        }
    ],
    "metadata": {
        "enhanced_queries": ["query1", "query2", "query3"],
        "documents_found": 2,
        "timestamp": "2026-02-15T18:01:55.018355",
        "model": "claude-3-5-sonnet-v2"
    }
}
```

### POST /feedback
**Request:**
```json
{
    "correlation_id": "uuid-from-chat-response",
    "feedback_type": "thumbs_up",
    "comment": "Great answer!"
}
```

**Response:**
```json
{
    "feedback_id": "uuid",
    "status": "received",
    "correlation_id": "uuid",
    "feedback_type": "thumbs_up",
    "timestamp": "2026-02-15T18:02:00.000000"
}
```

## Files
| File | Purpose |
|------|---------|
| lambda_function.py | Main Lambda code with all tools and handlers |
| deploy-commands.ps1 | Step-by-step PowerShell deployment commands |
| README.md | This file |

## AWS Resources Created
| Resource | Name/ID | Region |
|----------|---------|--------|
| Lambda (Chat) | km-agent-chat | us-east-1 |
| Lambda (Feedback) | km-agent-feedback | us-east-1 |
| IAM Role | km-agent-lambda-role | global |
| API Gateway | 1puptxusdd | us-east-1 |
| Bedrock Model | us.anthropic.claude-3-5-sonnet-20241022-v2:0 | us-east-1 |

## What Needs to Change for Production
See the Word document (Developer_Handoff_Guide.docx) for full details.
