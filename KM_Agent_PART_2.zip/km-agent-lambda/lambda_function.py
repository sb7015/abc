import json
import boto3
import uuid
from datetime import datetime

# Initialize Bedrock client
bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")

# ============================================================
# MOCK KNOWLEDGE BASE (hardcoded Q&A for testing)
# In production, Tool 3 (SharePoint Search) replaces this
# ============================================================
MOCK_DOCUMENTS = {
    "sop": {
        "claims_appeal": {
            "title": "SOP-Claims-Appeal-v3.2.pdf",
            "url": "https://sharepoint.example.com/sites/sop/claims-appeal-v3.2.pdf",
            "content": """Claims Appeal Standard Operating Procedure:
1. Initial Review: All appeals must be reviewed within 5 business days of receipt.
2. Medical Director Escalation: If initial review results in denial, escalate to Medical Director within 2 business days.
3. Peer-to-Peer Review: Requesting physician may request peer-to-peer review within 10 business days.
4. Member Notification: Written notification must be sent to member within 30 calendar days.
5. External Review: Member has right to external review within 60 days of final internal decision.
6. Documentation: All appeal decisions must be documented in the claims management system with rationale."""
        },
        "claims_processing": {
            "title": "SOP-Claims-Processing-v5.1.pdf",
            "url": "https://sharepoint.example.com/sites/sop/claims-processing-v5.1.pdf",
            "content": """Claims Processing Standard Operating Procedure:
1. Receipt: Claims received via EDI 837 or paper submission are logged within 24 hours.
2. Eligibility Verification: Member eligibility verified against enrollment database.
3. Duplicate Check: System checks for duplicate claims within 90-day window.
4. Auto-Adjudication: Clean claims auto-adjudicated within 48 hours if all rules pass.
5. Manual Review: Claims failing auto-adjudication queued for examiner review within 5 business days.
6. Payment: Approved claims paid within 30 calendar days per state regulations.
7. Denial: Denied claims generate EOB with reason codes and appeal rights notice."""
        }
    },
    "policy": {
        "pre_authorization": {
            "title": "Policy-PreAuth-2024.pdf",
            "url": "https://sharepoint.example.com/sites/policies/preauth-2024.pdf",
            "content": """Pre-Authorization Policy (Effective January 2024):
Required for: Inpatient admissions, outpatient surgeries exceeding $5,000, specialty drugs (Tier 3+), advanced imaging (MRI, CT, PET), DME over $1,000.
Process: Submit via provider portal minimum 48 hours in advance. Emergency admissions require notification within 24 hours post-admission.
Turnaround: Standard requests - 5 business days. Urgent requests - 24 hours. Emergency - concurrent review.
Validity: Pre-authorization valid for 60 days from approval date. Extensions require new request."""
        },
        "member_grievance": {
            "title": "Policy-Member-Grievance-2024.pdf",
            "url": "https://sharepoint.example.com/sites/policies/member-grievance-2024.pdf",
            "content": """Member Grievance Policy:
Filing: Members may file grievances verbally or in writing within 180 days of the event.
Acknowledgment: Written acknowledgment sent within 5 business days of receipt.
Investigation: Completed within 30 calendar days. Complex cases may extend to 60 days with member notification.
Resolution: Written resolution letter with findings, actions taken, and appeal rights.
Tracking: All grievances tracked in GRM system with quarterly trend reporting to Quality Committee."""
        }
    },
    "salesforce": {
        "knowledge": {
            "title": "SF-Knowledge-Base-FAQ.pdf",
            "url": "https://sharepoint.example.com/sites/salesforce/kb-faq.pdf",
            "content": """Salesforce Knowledge Base - Frequently Asked Questions:
Q: How to update member contact information? A: Navigate to Member 360 > Contact tab > Edit. Changes sync to enrollment system within 4 hours.
Q: How to create a new case? A: Click New Case > Select category > Fill required fields > Submit. Auto-assignment rules route to appropriate queue.
Q: How to check claim status? A: Member 360 > Claims tab > Enter claim number or date range. Real-time status from adjudication engine.
Q: How to process a provider dispute? A: Cases > New > Category: Provider Dispute > Attach supporting docs > Route to Provider Relations team."""
        }
    }
}


# ============================================================
# TOOL 1: Intent Classification (calls Bedrock)
# ============================================================
def classify_intent(question):
    """Classify user question into intent categories using Bedrock Claude."""
    
    prompt = f"""Classify the following question into exactly ONE of these categories:
- SOP (Standard Operating Procedures - how to do something step by step)
- Policy (Company policies, rules, requirements, coverage)
- Salesforce (CRM system questions, case management, member records)
- SOR (System of Record - technical system queries)
- General (anything that doesn't fit above)

Question: {question}

Respond with ONLY the category name, nothing else."""

    response = bedrock.invoke_model(
        modelId="us.anthropic.claude-3-5-sonnet-20241022-v2:0",
        contentType="application/json",
        accept="application/json",
        body=json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 20,
            "messages": [{"role": "user", "content": prompt}]
        })
    )
    
    result = json.loads(response["body"].read())
    intent = result["content"][0]["text"].strip().upper()
    
    # Normalize
    valid_intents = ["SOP", "POLICY", "SALESFORCE", "SOR", "GENERAL"]
    if intent not in valid_intents:
        intent = "GENERAL"
    
    return intent


# ============================================================
# TOOL 2: Query Enhancement (calls Bedrock)
# ============================================================
def enhance_query(question, intent):
    """Enhance the user's query for better document retrieval."""
    
    prompt = f"""You are a search query optimizer for an insurance company knowledge base.
    
Original question: {question}
Classified intent: {intent}

Generate 3 enhanced search queries that would find the most relevant documents. 
Consider synonyms, related terms, and specific insurance terminology.

Respond as a JSON array of strings, nothing else. Example: ["query1", "query2", "query3"]"""

    response = bedrock.invoke_model(
        modelId="us.anthropic.claude-3-5-sonnet-20241022-v2:0",
        contentType="application/json",
        accept="application/json",
        body=json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 200,
            "messages": [{"role": "user", "content": prompt}]
        })
    )
    
    result = json.loads(response["body"].read())
    enhanced_text = result["content"][0]["text"].strip()
    
    try:
        enhanced_queries = json.loads(enhanced_text)
    except json.JSONDecodeError:
        enhanced_queries = [question]
    
    return enhanced_queries


# ============================================================
# TOOL 3: Document Search (MOCK - replaces SharePoint in production)
# ============================================================
def search_documents(question, intent, enhanced_queries):
    """Search mock document store. In production, this calls Microsoft Graph API with OBO token."""
    
    # Simple keyword matching against mock documents
    question_lower = question.lower()
    matched_docs = []
    
    # Search through all documents
    for category, docs in MOCK_DOCUMENTS.items():
        for doc_key, doc in docs.items():
            # Check if any keywords match
            search_text = f"{doc['title']} {doc['content']}".lower()
            relevance = 0
            
            for word in question_lower.split():
                if len(word) > 3 and word in search_text:
                    relevance += 1
            
            # Also check enhanced queries
            for eq in enhanced_queries:
                for word in eq.lower().split():
                    if len(word) > 3 and word in search_text:
                        relevance += 0.5
            
            if relevance > 0:
                matched_docs.append({
                    "title": doc["title"],
                    "url": doc["url"],
                    "content": doc["content"],
                    "relevance": relevance
                })
    
    # Sort by relevance, take top 2
    matched_docs.sort(key=lambda x: x["relevance"], reverse=True)
    
    # If no matches, return a default based on intent
    if not matched_docs:
        intent_lower = intent.lower()
        if intent_lower in MOCK_DOCUMENTS:
            first_key = list(MOCK_DOCUMENTS[intent_lower].keys())[0]
            doc = MOCK_DOCUMENTS[intent_lower][first_key]
            matched_docs = [{
                "title": doc["title"],
                "url": doc["url"],
                "content": doc["content"],
                "relevance": 0.1
            }]
    
    return matched_docs[:2]


# ============================================================
# SYNTHESIZE ANSWER (calls Bedrock)
# ============================================================
def synthesize_answer(question, intent, documents):
    """Use Bedrock Claude to synthesize a final answer with citations."""
    
    doc_context = ""
    for i, doc in enumerate(documents, 1):
        doc_context += f"\n\n--- Document {i}: {doc['title']} ---\n{doc['content']}"
    
    prompt = f"""You are a helpful knowledge management assistant for Elements Health insurance company.
    
User Question: {question}
Intent Category: {intent}

Source Documents:{doc_context}

Instructions:
1. Provide a clear, concise answer based ONLY on the source documents above.
2. Include specific details, numbers, and timelines from the documents.
3. At the end, list the source documents as citations.
4. If the documents don't fully answer the question, say what you found and note what's missing.
5. Keep your answer professional and under 300 words."""

    response = bedrock.invoke_model(
        modelId="us.anthropic.claude-3-5-sonnet-20241022-v2:0",
        contentType="application/json",
        accept="application/json",
        body=json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 500,
            "messages": [{"role": "user", "content": prompt}]
        })
    )
    
    result = json.loads(response["body"].read())
    return result["content"][0]["text"].strip()


# ============================================================
# LAMBDA HANDLER
# ============================================================
def lambda_handler(event, context):
    """Main Lambda entry point."""
    
    try:
        # Parse input
        if isinstance(event.get("body"), str):
            body = json.loads(event["body"])
        elif "body" in event:
            body = event["body"]
        else:
            body = event
        
        question = body.get("question", "")
        session_id = body.get("session_id", str(uuid.uuid4()))
        
        if not question:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
                "body": json.dumps({"error": "Missing 'question' field"})
            }
        
        # ---- STRANDS AGENT ORCHESTRATION ----
        
        # Tool 1: Classify Intent
        intent = classify_intent(question)
        
        # Tool 2: Enhance Query
        enhanced_queries = enhance_query(question, intent)
        
        # Tool 3: Search Documents (mock)
        documents = search_documents(question, intent, enhanced_queries)
        
        # Synthesize Final Answer
        answer = synthesize_answer(question, intent, documents)
        
        # Build citations
        sources = []
        citation_lines = []
        for i, doc in enumerate(documents, 1):
            sources.append({
                "title": doc["title"],
                "url": doc["url"],
                "snippet": doc["content"][:200] + "..."
            })
            citation_lines.append(f"[{i}] {doc['title']} - {doc['url']}")
        
        citations = "\n".join(citation_lines)
        correlation_id = str(uuid.uuid4())
        
        # Build response
        response_body = {
            "answer": answer,
            "citations": citations,
            "intent": intent,
            "correlation_id": correlation_id,
            "session_id": session_id,
            "sources": sources,
            "metadata": {
                "enhanced_queries": enhanced_queries,
                "documents_found": len(documents),
                "timestamp": datetime.utcnow().isoformat(),
                "model": "claude-3-5-sonnet-v2"
            }
        }
        
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization"
            },
            "body": json.dumps(response_body)
        }
    
    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
            "body": json.dumps({
                "error": str(e),
                "correlation_id": str(uuid.uuid4()),
                "timestamp": datetime.utcnow().isoformat()
            })
        }


# ============================================================
# FEEDBACK HANDLER
# ============================================================
def feedback_handler(event, context):
    """Handle feedback submissions. In production, stores to MemoryDB."""
    
    try:
        if isinstance(event.get("body"), str):
            body = json.loads(event["body"])
        elif "body" in event:
            body = event["body"]
        else:
            body = event
        
        correlation_id = body.get("correlation_id", "")
        feedback_type = body.get("feedback_type", "")
        comment = body.get("comment", "")
        
        if not correlation_id or not feedback_type:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
                "body": json.dumps({"error": "Missing 'correlation_id' or 'feedback_type'"})
            }
        
        # In production: store to MemoryDB
        # For now: just acknowledge
        feedback_id = str(uuid.uuid4())
        
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
            "body": json.dumps({
                "feedback_id": feedback_id,
                "status": "received",
                "correlation_id": correlation_id,
                "feedback_type": feedback_type,
                "timestamp": datetime.utcnow().isoformat()
            })
        }
    
    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
            "body": json.dumps({"error": str(e)})
        }
