# ============================================================
# KM Agent Lambda - Deployment Commands for PowerShell
# Run these commands ONE BY ONE in PowerShell
# ============================================================

# ---- STEP 1: Create IAM Role for Lambda ----
# This role lets Lambda call Bedrock

aws iam create-role --role-name km-agent-lambda-role --assume-role-policy-document '{\"Version\":\"2012-10-17\",\"Statement\":[{\"Effect\":\"Allow\",\"Principal\":{\"Service\":\"lambda.amazonaws.com\"},\"Action\":\"sts:AssumeRole\"}]}'

# ---- STEP 2: Attach permissions to the role ----

# Basic Lambda execution (CloudWatch logs)
aws iam attach-role-policy --role-name km-agent-lambda-role --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

# Bedrock full access (for invoking Claude)
aws iam attach-role-policy --role-name km-agent-lambda-role --policy-arn arn:aws:iam::aws:policy/AmazonBedrockFullAccess

# ---- STEP 3: Wait 10 seconds for role to propagate ----
Start-Sleep -Seconds 10

# ---- STEP 4: Get your account ID ----
aws sts get-caller-identity --query Account --output text
# COPY THIS NUMBER - you'll need it below

# ---- STEP 5: Zip the Lambda code ----
# (Run from the directory containing lambda_function.py)
Compress-Archive -Path lambda_function.py -DestinationPath km-agent.zip -Force

# ---- STEP 6: Create the Lambda function ----
# REPLACE 123456789012 with your actual account ID from Step 4
aws lambda create-function --function-name km-agent-chat --runtime python3.12 --role arn:aws:iam::123456789012:role/km-agent-lambda-role --handler lambda_function.lambda_handler --zip-file fileb://km-agent.zip --timeout 60 --memory-size 256 --region us-east-1

# ---- STEP 7: Create the Feedback Lambda function (same code, different handler) ----
# REPLACE 123456789012 with your actual account ID
aws lambda create-function --function-name km-agent-feedback --runtime python3.12 --role arn:aws:iam::123456789012:role/km-agent-lambda-role --handler lambda_function.feedback_handler --zip-file fileb://km-agent.zip --timeout 30 --memory-size 128 --region us-east-1

# ---- STEP 8: Test the Lambda directly ----
'{"question":"What is the SOP for claims appeal?"}' | Out-File -Encoding ascii test-event.json
aws lambda invoke --function-name km-agent-chat --payload fileb://test-event.json --region us-east-1 lambda-output.json
Get-Content lambda-output.json

# ---- STEP 9: Create API Gateway (HTTP API) ----
aws apigatewayv2 create-api --name km-agent-api --protocol-type HTTP --cors-configuration AllowOrigins="*",AllowMethods="POST,OPTIONS",AllowHeaders="Content-Type,Authorization" --region us-east-1

# COPY the "ApiId" from the output - you'll need it below

# ---- STEP 10: Create Lambda integration for chat ----
# REPLACE <API_ID> with the ApiId from Step 9
# REPLACE 123456789012 with your account ID
aws apigatewayv2 create-integration --api-id <API_ID> --integration-type AWS_PROXY --integration-uri arn:aws:lambda:us-east-1:123456789012:function:km-agent-chat --payload-format-version 2.0 --region us-east-1

# COPY the "IntegrationId" from output

# ---- STEP 11: Create route for POST /chat ----
# REPLACE <API_ID> and <INTEGRATION_ID>
aws apigatewayv2 create-route --api-id <API_ID> --route-key "POST /chat" --target integrations/<INTEGRATION_ID> --region us-east-1

# ---- STEP 12: Create Lambda integration for feedback ----
# REPLACE <API_ID> and 123456789012
aws apigatewayv2 create-integration --api-id <API_ID> --integration-type AWS_PROXY --integration-uri arn:aws:lambda:us-east-1:123456789012:function:km-agent-feedback --payload-format-version 2.0 --region us-east-1

# COPY the "IntegrationId" from output

# ---- STEP 13: Create route for POST /feedback ----
# REPLACE <API_ID> and <FEEDBACK_INTEGRATION_ID>
aws apigatewayv2 create-route --api-id <API_ID> --route-key "POST /feedback" --target integrations/<FEEDBACK_INTEGRATION_ID> --region us-east-1

# ---- STEP 14: Create default stage (auto-deploy) ----
# REPLACE <API_ID>
aws apigatewayv2 create-stage --api-id <API_ID> --stage-name '$default' --auto-deploy --region us-east-1

# ---- STEP 15: Grant API Gateway permission to invoke Lambda ----
# REPLACE 123456789012
aws lambda add-permission --function-name km-agent-chat --statement-id apigateway-chat --action lambda:InvokeFunction --principal apigateway.amazonaws.com --region us-east-1
aws lambda add-permission --function-name km-agent-feedback --statement-id apigateway-feedback --action lambda:InvokeFunction --principal apigateway.amazonaws.com --region us-east-1

# ---- STEP 16: Get your API URL ----
# REPLACE <API_ID>
aws apigatewayv2 get-api --api-id <API_ID> --query ApiEndpoint --output text --region us-east-1

# Your API URL will look like: https://xxxxxxxxxx.execute-api.us-east-1.amazonaws.com

# ---- STEP 17: TEST IT! ----
# REPLACE <YOUR_API_URL> with the URL from Step 16
# Using curl or Invoke-RestMethod in PowerShell:
Invoke-RestMethod -Method POST -Uri "<YOUR_API_URL>/chat" -ContentType "application/json" -Body '{"question":"What is the SOP for claims appeal?"}'
