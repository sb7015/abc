# Agentic KM Solution — Teams App Package Setup Guide

## What's in this Package

```
appPackage/
├── manifest.json                          ← Main app manifest (Teams/M365 entry point)
├── km-declarative-agent.json              ← Declarative agent definition (instructions, starters)
├── km-api-plugin.json                     ← API plugin manifest (maps functions to your API)
├── apiSpecificationFile/
│   └── km-openapi.json                    ← OpenAPI spec for your Kong → Lambda backend
├── color.png                              ← App icon 192x192 (color)
└── outline.png                            ← App icon 32x32 (outline)
```

**No code in this package.** It's purely configuration files + icons. All logic lives in your AWS backend.

---

## How It Works

```
User asks question in M365 Copilot
        ↓
Copilot reads manifest.json → finds declarativeAgent
        ↓
Declarative agent reads km-declarative-agent.json → has instructions + actions
        ↓
Action points to km-api-plugin.json → has function "askKMAgent"
        ↓
Plugin reads km-openapi.json → knows to POST to {{KONG_GATEWAY_URL}}/chat
        ↓
Kong → Lambda → Strands Agent → SharePoint (OBO) → Response
        ↓
Response comes back with answer + citations → displayed in Copilot
```

---

## Step-by-Step Setup

### Step 1: Prerequisites

- [ ] M365 Copilot license (you have this ✅)
- [ ] Admin access to Microsoft 365 admin center (for sideloading apps)
- [ ] Teams Toolkit extension in VS Code (recommended) OR manual upload
- [ ] Your backend API running (even a mock Lambda returning dummy JSON works for testing)

### Step 2: Replace Placeholders

Open each file and replace these placeholders:

| Placeholder | Replace With | Example |
|---|---|---|
| `{{APP_ID}}` | A new GUID (generate at https://guidgenerator.com) | `a1b2c3d4-e5f6-7890-abcd-ef1234567890` |
| `{{KONG_GATEWAY_DOMAIN}}` | Your Kong gateway domain (no https://) | `api.km-agent.example.com` |
| `{{KONG_GATEWAY_URL}}` | Full Kong gateway URL | `https://api.km-agent.example.com` |
| `{{OAUTH_REFERENCE_ID}}` | OAuth config ID from Teams Developer Portal | (see Step 3) |

### Step 3: Configure OAuth (for production with OBO)

For **testing without auth** (personal test), change the auth in `km-api-plugin.json`:
```json
"auth": {
  "type": "None"
}
```

For **production with OBO**, register OAuth in Teams Developer Portal:
1. Go to https://dev.teams.microsoft.com
2. Navigate to Tools → OAuth client registration
3. Register your Azure AD app credentials
4. Copy the reference_id back into `km-api-plugin.json`

### Step 4: Create the .zip Package

```bash
cd appPackage
zip -r ../km-agent-app.zip *
```

The zip should contain files at the ROOT level (not inside a subfolder):
```
km-agent-app.zip
├── manifest.json
├── km-declarative-agent.json
├── km-api-plugin.json
├── apiSpecificationFile/
│   └── km-openapi.json
├── color.png
└── outline.png
```

### Step 5: Upload to M365 Copilot

**Option A — Via Teams Toolkit (Recommended)**
1. Open the `appPackage` folder in VS Code
2. Install "Microsoft 365 Agents Toolkit" extension
3. Click Provision → it sideloads automatically

**Option B — Via Teams Admin Center**
1. Go to https://admin.teams.microsoft.com
2. Teams apps → Manage apps → Upload new app
3. Upload `km-agent-app.zip`
4. Approve the app for yourself/your org

**Option C — Via M365 Admin Center**
1. Go to https://admin.microsoft.com
2. Settings → Integrated Apps → Upload custom apps
3. Upload the zip

**Option D — Sideload directly in Teams**
1. Open Teams → Apps → Manage your apps
2. Click "Upload an app" → "Upload a custom app"
3. Select `km-agent-app.zip`

### Step 6: Test in M365 Copilot

1. Open M365 Copilot (the same UI you showed in your screenshot)
2. Go to Agents → you should see "KM Agent" listed
3. Click on it → start chatting!
4. Try: "What is the SOP for claim denial appeals?"

---

## For Personal Testing (Quick Mock)

If your AWS backend isn't ready yet, create a simple mock API:

```python
# mock_api.py — run with: python mock_api.py
from flask import Flask, request, jsonify
import uuid

app = Flask(__name__)

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    return jsonify({
        "answer": f"Here is a mock answer for: {data.get('question', 'N/A')}. In production, this would be a synthesized answer from SharePoint documents with real citations.",
        "citations": "[1] SOP-Claims-2024.docx (SharePoint)\n[2] Policy-PreAuth-v3.pdf (SharePoint)",
        "intent": "SOP",
        "correlation_id": str(uuid.uuid4()),
        "session_id": data.get('session_id', str(uuid.uuid4())),
        "sources": [
            {"title": "SOP-Claims-2024.docx", "url": "https://sharepoint.com/doc1", "snippet": "Mock excerpt..."},
            {"title": "Policy-PreAuth-v3.pdf", "url": "https://sharepoint.com/doc2", "snippet": "Mock excerpt..."}
        ]
    })

@app.route('/feedback', methods=['POST'])
def feedback():
    data = request.json
    return jsonify({
        "feedback_id": str(uuid.uuid4()),
        "status": f"Feedback '{data.get('feedback_type')}' received for {data.get('correlation_id')}"
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
```

Expose it publicly using ngrok:
```bash
ngrok http 5000
```

Then use the ngrok URL as your `{{KONG_GATEWAY_URL}}` in the OpenAPI spec.

---

## Switching to Client Environment

When handing off to the client, they only need to:

1. Replace `{{KONG_GATEWAY_URL}}` with their Kong endpoint
2. Replace `{{APP_ID}}` with their own GUID
3. Replace `{{OAUTH_REFERENCE_ID}}` with their OAuth registration
4. Update `developer` fields in manifest.json with their company info
5. Replace icons with their branded versions
6. Zip and upload

**The entire agent logic, plugin structure, and OpenAPI spec stay exactly the same.**

---

## File Reference

| File | Purpose | When to Change |
|---|---|---|
| `manifest.json` | Teams app entry point, registers the declarative agent | Change APP_ID, developer info, domain |
| `km-declarative-agent.json` | Agent instructions, conversation starters, action reference | Update instructions as agent behavior evolves |
| `km-api-plugin.json` | Maps Copilot functions to your API, response formatting | Update auth type, add new functions |
| `km-openapi.json` | Describes your REST API endpoints and schemas | Update when API contract changes |
| `color.png` | 192x192 app icon | Replace with branded icon |
| `outline.png` | 32x32 transparent outline icon | Replace with branded outline |
